from behave import given, when, then

@given('the service cost is {amount}')
def step_impl(context, amount):
    context.insurance_context.service_amount = float(amount)

@given('the individual deductible is {amount}')
def step_impl(context, amount):
    context.insurance_context.deductible_individual_calculated = float(amount)

@given('the family deductible is {amount}')
def step_impl(context, amount):
    context.insurance_context.deductible_family_calculated = float(amount) 

@given('the deductible is before co-pay {value}')
def step_impl(context, value):
    context.insurance_context.is_deductible_before_copay = value.lower() == 'true'

@given('a cost share co-pay is {amount}')
def step_impl(context, amount):
    context.insurance_context.cost_share_copay = float(amount)

@when('the handler processes the context')
def step_impl(context):
    context.result = context.handler.process(context.insurance_context)

@then('the result should indicate the service is covered')
def step_impl(context):
    assert context.result.is_service_covered is True
    assert context.result.message == "Service is covered"

@then('the result should indicate the service is not covered')
def step_impl(context):
    assert context.result.is_service_covered is False
    assert context.result.message == "Service is not covered"

@then('the calculation is not complete')
def step_impl(context):
    assert context.result.calculation_complete is False

@then('the calculation is complete')
def step_impl(context):
    assert context.result.calculation_complete is True

@then('the insurance pays {amount}')
def step_impl(context, amount):
    assert context.result.insurance_pays == float(amount) 

@then('the member pays {amount}')
def step_impl(context, amount):
    assert context.result.member_pays == float(amount)

@then('the individual OOPMax is updated to {amount}')
def step_impl(context, amount):
    assert context.result.oopmax_individual_calculated == float(amount)

@then('the family OOPMax is updated to {amount}')
def step_impl(context, amount):
    assert context.result.oopmax_family_calculated == float(amount)

@given('the member co-pay is {amount:d}')
def step_impl(context, amount):
    context.insurance_context.cost_share_copay = float(amount)

@then('the individual deductible is updated to {amount:d}')
def step_impl(context, amount):
    context.insurance_context.deductible_individual_calculated = float(amount)

@then('the family deductible is updated to {amount:d}')
def step_impl(context, amount):
    context.insurance_context.deductible_family_calculated = float(amount)

@then('the service amount is updated to {amount:d}')
def step_impl(context, amount):
    context.insurance_context.service_amount = float(amount)

@then('the co-insurance is checked')
def step_impl(context):
    context.mock_co_insurance_handler.assert_called_once_with(context.insurance_context)

@then('the co-pay is checked')
def step_impl(context):
    context.mock_cost_share_co_pay_handler.assert_called_once_with(context.insurance_context)