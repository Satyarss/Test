def check_service_coverage(service_covered, frequency_limit_not_reached, dollar_limit_not_reached):
    return service_covered and frequency_limit_not_reached and dollar_limit_not_reached

def check_out_of_pocket_max(family_oop_max_not_met, individual_oop_max_not_met):
    return family_oop_max_not_met and individual_oop_max_not_met

def calculate_payment(service_amount, copay, oop_max_left, deductible, has_deductible):
    if has_deductible:
        # Handle deductible logic here if needed
        pass
    else:
        if copay >= service_amount:
            if service_amount <= oop_max_left:
                return service_amount, service_amount
            else:
                return oop_max_left, oop_max_left
        else:
            if copay <= oop_max_left:
                return copay, copay
            else:
                return oop_max_left, oop_max_left

def process_claim(service_covered, frequency_limit_not_reached, dollar_limit_not_reached,
                  family_oop_max_not_met, individual_oop_max_not_met, service_amount, copay, oop_max_left, has_deductible):
    if not check_service_coverage(service_covered, frequency_limit_not_reached, dollar_limit_not_reached):
        return "Service not covered or limits reached"

    if not check_out_of_pocket_max(family_oop_max_not_met, individual_oop_max_not_met):
        return "Out of pocket max reached"

    payment, applied_to_oop_max = calculate_payment(service_amount, copay, oop_max_left, None, has_deductible)
    return f"Member pays: ${payment:.2f}, Applied to OOP max: ${applied_to_oop_max:.2f}"

# Example usage
service_covered = True
frequency_limit_not_reached = True
dollar_limit_not_reached = True
family_oop_max_not_met = True
individual_oop_max_not_met = True
service_amount = 50
copay = 30
oop_max_left = 20
has_deductible = False


result = process_claim(service_covered, frequency_limit_not_reached, dollar_limit_not_reached,
                       family_oop_max_not_met, individual_oop_max_not_met, service_amount, copay, oop_max_left, has_deductible)
print(result)
