

SERVER_ROOT_PATH = "/costestimator"
API_VERSION_V1 = "/v1"

INDEX_ROUTES_TAG = "Index route"
BENEFITS_URL = "https://qaapi10.int.cvshealth.com/hcb/qapath3/hcb/v3/servicesbenefits/retrieve"
ACCUMULATOR_URL = "https://qaapi10.int.cvshealth.com/healthcare/qapath3/hcb/v3/healthsparq_memberships/"
TOKEN_URL = "https://qaapi10.int.cvshealth.com/identitymanagement/qapath3/v3/auth/oauth2product/jwt/encryption/token"


# TOKEN_AUTHORIZATION = os.environ.get("TOKEN_AUTH")
TOKEN_AUTHORIZATION = "MjQwYTMyYjUtY2IxNC00Y2MxLTk4MGQtNjVjN2FkYTMxNjE0Om5RM2dLNXJPMXJPOHRSMnNHMWFRNGtLMHFLNmhQN3BONmtEM2ZVN3BRMmRCNG5NMWJF"
# ASSERTION = os.environ.get("ASSERTION")
ASSERTION = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI3MTMxMjcxMC04ODEwLTQ0OTAtYmQ5OC0wNzUyMDYyZTFlMDciLCJzdWIiOiJOV2s1S1h4bFVBPT0iLCJhY3IiOiJodHRwczovL2FldG5hLmhlYWx0aHNwYXJxLmNvbS9sb2EtMiIsImlzcyI6Imh0dHBzOi8vYWV0bmEuaGVhbHRoc3BhcnEuY29tLyIsImV4cCI6MTY4MTQ5Mjc2NywiaWF0IjoxNjcyODUyNzY3fQ.SCpq2y5RUlMO6tF0OlqKpDoWmTRwrVYlRAPZNvpe5GPKXy-p4EJbSEkLLBoeULrFS8AAMSAts57vSlUaz7u2Q9K02dDzU9HQ1FTe_eZZhpYLoyqAOBZkB4yckgmyPyNrA1Ao1nspyp5l-Qrs6IknBxGW8LpwzJZ1V5KCox1DhEQHDUi6G90codiAjFTvDePFLoQsekZKyOh-z5HbnSPkLWnpjxEoHn0G2YPKi_uFJcX-ZkkpWM2V_Fnbu23tn9Pz_-MWQoOS1CaR64ZjbW-g_M5HFdiB82yUvx---bJLPMXLbt-zMHpQxS8x_jS8ZzV_Y2u1Pw6BvNQdV4sBYYuZNQ"
