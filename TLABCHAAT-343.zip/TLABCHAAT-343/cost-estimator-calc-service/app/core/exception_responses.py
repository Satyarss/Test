responses = {
    200: {
        "description": "Success",
        "headers": {
            "x-clientrefid": {
                "description": "A reference ID provided by the client, used for tracking and debugging purposes."
            },
            "x-correlation-id": {
                "description": "A unique identifier for the request, used for tracking and debugging purposes."
            },
        },
    },
    400: {
        "correlationId": "069d197a-1e14-453f-8cf4-63f74eb626ff",
        "type": "https://www.rfc-editor.org/rfc/rfc7231#section-6.5.1",
        "title": "One or more validation errors occurred",
        "status": 400,
        "detail": "Malformed request",
        "errors": "{}",
        "message": "Additional details",
    },
}
