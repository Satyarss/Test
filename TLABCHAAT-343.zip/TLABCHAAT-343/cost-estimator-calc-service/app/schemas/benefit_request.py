

from typing import List

from pydantic import BaseModel


class ProviderType(BaseModel):
    code: str

class PlaceOfService(BaseModel):
    code: str

class ProviderSpecialty(BaseModel):
    code: str

class ServiceCodeInfo(BaseModel):
    providerType: List[ProviderType]
    placeOfService: List[PlaceOfService]
    providerSpecialty: List[ProviderSpecialty]
    code: str
    type: str

class ServiceInfo(BaseModel):
    serviceCodeInfo: ServiceCodeInfo

class BenefitRequest(BaseModel):
    """Model for benefit request data."""
    benefitProductType: str
    membershipID: str
    planIdentifier: str
    serviceInfo: List[ServiceInfo] 