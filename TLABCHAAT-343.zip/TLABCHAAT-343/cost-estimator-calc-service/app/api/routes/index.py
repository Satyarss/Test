from fastapi import APIRouter, status, Response
from fastapi.responses import JSONResponse

router = APIRouter()


@router.get(
    "/health",
    status_code=status.HTTP_200_OK
)
def health(response: Response):
    return JSONResponse(
        content={"health": "ok"},
    )