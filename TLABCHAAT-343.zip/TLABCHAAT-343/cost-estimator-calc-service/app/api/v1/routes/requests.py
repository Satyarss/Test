from fastapi import APIRouter, Depends
from app.core.exception_responses import responses
from app.schemas.cost_estimator_request import CostEstimatorRequest
from app.services.impl.cost_estimation_service_impl import CostEstimationServiceImpl

router = APIRouter()


@router.post(
    "/rate",
    responses=responses,
    summary="Retrieve cost estimate for member",
    tags=["Cost Estimation"],
)
async def estimate_cost(
    request: CostEstimatorRequest,
    service: CostEstimationServiceImpl = Depends(),
):
    rate = await service.estimate_cost(request)
    return {"message": "You will get a calculated rate soon!", "rate": rate}