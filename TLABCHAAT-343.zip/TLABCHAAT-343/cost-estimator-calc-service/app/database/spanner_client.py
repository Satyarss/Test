from google.cloud.spanner_v1 import SpannerAsyncClient
from google.cloud.spanner_v1 import PartitionOptions, PartitionReadRequest, PartitionQueryRequest
from typing import Optional, List, Dict, Any, Union
from app.core.logger import logger
import asyncio
from contextlib import asynccontextmanager
from concurrent.futures import ThreadPoolExecutor

class SpannerClient:
    def __init__(self, 
                 project_id: str,
                 instance_id: str,
                 database_id: str,
                 max_workers: int = 10,
                 pool_size: int = 5):
        """Initialize async Spanner client for read-only operations."""
        self.project_id = project_id
        self.instance_id = instance_id
        self.database_id = database_id
        self.max_workers = max_workers
        self.pool_size = pool_size
        
        # Create database path
        self.database_path = f"projects/{project_id}/instances/{instance_id}/databases/{database_id}"
        
        # Connection pool
        self._client_pool = asyncio.Queue(maxsize=pool_size)
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        
        # Simple in-memory cache for frequently accessed data
        self._cache = {}
        self._cache_ttl = 300  # 5 minutes
        
        logger.info(f"Async SpannerClient initialized for database: {self.database_path}")
        logger.info(f"Connection pool size: {pool_size}, Max workers: {max_workers}")

    @asynccontextmanager
    async def _get_client_and_session(self):
        """Context manager for Spanner client and session."""
        client = SpannerAsyncClient()
        try:
            session = await client.create_session(request={"database": self.database_path})
            try:
                yield client, session
            finally:
                await client.delete_session(request={"name": session.name})
        finally:
            # SpannerAsyncClient doesn't have a close method
            pass

    async def execute_query(self, 
                          query: str, 
                          params: Optional[Dict[str, Any]] = None) -> List[Dict]:
        """Execute a read-only query using async Cloud Spanner client."""
        try:
            logger.info(f"Executing async query: {query}")
            logger.info(f"Query params: {params}")
            
            async with self._get_client_and_session() as (client, session):
                # Execute query using session
                request_data = {
                    "session": session.name,
                    "sql": query,
                    "params": params or {}
                }
                
                response = await client.execute_sql(request=request_data)
                
                return response.rows;
                
        except Exception as e:
            logger.error(f"Error executing async read-only query: {str(e)}")
            logger.error(f"Query: {query}")
            logger.error(f"Params: {params}")
            logger.error(f"Exception type: {type(e)}")
            logger.error(f"Exception details: {e}")
            return []

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        logger.info("Async SpannerClient closed")

   