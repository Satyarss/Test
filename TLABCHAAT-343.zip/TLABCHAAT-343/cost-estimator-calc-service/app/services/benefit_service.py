from abc import ABC, abstractmethod

from app.schemas.benefit_reponse import BenefitApiResponse
from app.schemas.benefit_request import BenefitRequest


class BenefitServiceInterface(ABC):
    @abstractmethod
    async def get_benefit(self, request: BenefitRequest) -> BenefitApiResponse:
        """
        Abstract method to get benefit information using a BenefitRequest object.
        Returns a BenefitApiResponse object.
        """
        pass
