from app.core.base import Handler, InsuranceContext

class DeductibleCoPayHandler(Handler):
    """Handles the member co-pay"""

    def __init__(self):
        super().__init__()
        self._deductible_co_insurance_handler = None

    def set_deductible_co_insurance_handler(self, handler):
        self._deductible_co_insurance_handler = handler
        return handler

    def process(self, context):
        # If co-pay does not apply to OOP then member pays lesser of the remaining amount and cost share co-pay
        if not context.copay_applies_oop:
            context.trace_decision("Process", "Co-pay is not applied to OOP", False)
            if context.cost_share_copay > context.service_amount:
                context.trace_decision("Process", "The cost share co-pay is greater than the service amount", True)
                return self._apply_member_pays_remaining_service_amount(context)
            else:
                # Member pays cost share co-pay amount and its not applied to individual/family OOPMax
                # Co-insurance is applied on the difference between remaining service amount - cost share co-pay amount
                context.trace_decision("Process", "The cost share co-pay is greater than the service amount", False)
                context = self._apply_member_pays_co_pay_and_oopmax_not_updated(context)
                return self._deductible_co_insurance_handler(context) 
            
        if context.oopmax_family_calculated == 0:
            context.trace_decision("Process", "The family OOPMax is zero", True)
            return self._apply_member_pays_no_co_pay(context)
        
        if context.oopmax_individual_calculated == 0:
            context.trace_decision("Process", "The individual OOPMax is zero", True)
            return self._apply_member_pays_no_co_pay(context)

        # Member pays lessor between service amount and co-pay
        if context.cost_share_copay > context.service_amount:
            context.trace_decision("Process", "The cost share co-pay is greater than the service amount", True)
            return self._apply_member_pays_remaining_service_amount_and_oopmax_updated(context)
        else:
            context.trace_decision("Process", "The cost share co-pay is greater than the service amount", False)
            context = self._apply_member_pays_co_pay_and_oopmax_updated(context)
            return self._deductible_co_insurance_handler(context)  # go follow path B to calculate co-insurance
                

    def _apply_member_pays_remaining_service_amount(self, context: InsuranceContext) -> InsuranceContext:
        """Member pays remaining service amount and its not applied to individual/family OOPMax"""

        context.member_pays = context.service_amount
        context.insurance_pays = 0.0
        context.calculation_complete = True

        context.trace("_apply_member_pays_remaining_service_amount", "Logic applied")

        return context
    
    def _apply_member_pays_no_co_pay(self, context: InsuranceContext) -> InsuranceContext:
        """Member pays no co-pay. No other cost sharing"""

        context.member_pays = 0
        context.insurance_pays = context.service_amount
        context.calculation_complete = True

        context.trace("_apply_member_pays_no_co_pay", "Logic applied")

        return context
    
    def _apply_member_pays_remaining_service_amount_and_oopmax_updated(self, context: InsuranceContext) -> InsuranceContext:
        """Member pays remaining service amount and individual/family OOPMax updated"""

        context.member_pays = context.service_amount
        context.insurance_pays = context.service_amount - context.member_pays
        context.calculation_complete = True

        # Update OOPMax
        context.oopmax_individual_calculated -= context.member_pays
        context.oopmax_family_calculated -= context.member_pays

        context.trace("_apply_member_pays_remaining_service_amount_and_oopmax_updated", "Logic applied")

        return context
    
    def _apply_member_pays_co_pay_and_oopmax_updated(self, context: InsuranceContext) -> InsuranceContext:
        """Member pays co-pay amount and its applied to individual/family OOPMax updated"""

        context.member_pays = context.cost_share_copay
        context.insurance_pays = context.service_amount - context.member_pays

        # Update OOPMax
        context.oopmax_individual_calculated -= context.member_pays
        context.oopmax_family_calculated -= context.member_pays

        context.trace("_apply_member_pays_co_pay_and_oopmax_updated", "Logic applied")

        return context
    
    def _apply_member_pays_co_pay_and_oopmax_not_updated(self, context: InsuranceContext) -> InsuranceContext:
        """Member pays co-pay amount and its not applied to individual/family OOPMax updated"""
 
        context.member_pays = context.cost_share_copay
        context.insurance_pays = context.service_amount - context.member_pays

        # We need to subtract the co-pay amount from the service amount so co-insurance is calculated correctly
        context.service_amount = context.service_amount - context.cost_share_copay

        context.trace("_apply_member_pays_co_pay_and_oopmax_not_updated", "Logic applied")

        return context