from app.core.base import Handler, InsuranceContext

class BenefitLimitationHandler(Handler):
    """Handle the benefits limitation"""

    def __init__(self):
        super().__init__()
        self._deductible_cost_share_co_handler = None

    def set_deductible_cost_share_co_handler(self, handler):
        self._deductible_cost_share_co_handler = handler
        return handler

    def process(self, context: InsuranceContext) -> InsuranceContext:
        if not context.has_benefit_limitation:
            context.trace_decision("Process", "Context has no benefit limitation", True)
            return context
        
        # Now check if the limit has been reached
        if context.benefit_code.lower() == "limit" and context.limit_calculated == 0:
            context.trace_decision("Process", "The benefit code is 'limit' and the calculated limit is 0, applying benefit limitation", True)
            return self._apply_limitation(context)

        # Handle the scenario when the limit type is a dollar amount
        if context.limit_type.lower() == "dollar":
            if context.service_amount > context.limit_calculated:
                context.trace_decision("Process", "The service amount is greater than the benefit limit amount, applying partial limitation", True)
                context = self._apply_partial_limit(context)
                return self._deductible_cost_share_co_handler(context)
            else:
                # Service is within benefit limitation
                context.trace_decision("Process", "Service is within benefit limits", True)
                return self._apply_within_limit(context)
        # Handle the scenario when the limit type is a quantity
        elif context.limit_type.lower() == "counter":
            if context.limit_calculated >= 1: 
                return self._apply_within_limit(context)
            else:
                return self._apply_limitation(context)

        # We only know of 2 limit types. We have an unknown limit type, throw an exception
        raise Exception(f"Uknown benefit limit type. Unable to proceed. Limit type passed: {context.limit_type}")
        
    
    def _apply_limitation(self, context: InsuranceContext) -> InsuranceContext:
        """Apply logic when benefit limit has been reached"""

        context.member_pays = context.service_amount
        context.insurance_pays = 0
        context.calculation_complete = True

        context.trace("_apply_limitation", "Logic applied")

        return context
    
    def _apply_partial_limit(self, context: InsuranceContext) -> InsuranceContext:
        """Apply logic when service exceeds the remaining benefit limit"""
        
        context.insurance_pays = context.limit_calculated
        context.member_pays = context.service_amount - context.insurance_pays

        context.trace("_apply_partial_limit", "Logic applied")

        return context
    
    def _apply_within_limit(self, context: InsuranceContext) -> InsuranceContext:
        """Service is within the benefit limits"""

        context.member_pays = 0
        context.insurance_pays = context.service_amount
        context.calculation_complete = True

        context.trace("_apply_within_limit", "Logic applied")

        return context