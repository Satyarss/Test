from app.core.base import Handler, InsuranceContext

class ServiceCoverageHandler(Handler):
    """Check if service is covered"""

    def process(self, context: InsuranceContext) -> InsuranceContext:
        if not context.is_service_covered:
            context.trace_decision("Process", "The service is not covered", False)
            return self._apply_no_coverage(context)

        context.trace_decision("Process", "The service is covered", True)

        return context
    
    def _apply_no_coverage(self, context: InsuranceContext) -> InsuranceContext:
        """Apply logic when service isn't covered""" 

        context.member_pays = context.service_amount
        context.insurance_pays = 0.0
        context.calculation_complete = True

        context.trace("_apply_no_coverage", "Logic applied")
        
        return context