from app.core.base import Handler, InsuranceContext

class OOPMaxHandler(Handler):
    """Check if the out of pocket max are met or if an out of pocket max exists"""

    def __init__(self):
        super().__init__()
        self._deductible_handler = None
        self._oopmax_copay_handler = None

    def set_deductible_handler(self, handler):
        self._deductible_handler = handler
        return handler
    
    def set_oopmax_copay_handler(self, handler):
        self._oopmax_copay_handler = handler
        return handler
    
    def process(self, context: InsuranceContext) -> InsuranceContext:
        # Need to check if we have an OOPMax
        if not context.has_oopmax:
            context.trace_decision("Process", "A OOPMax was not provided", False)
            return self._deductible_handler(context)
        
        # Check family OOPMax
        if context.oopmax_family_calculated == 0:
            context.trace_decision("Process", "The family OOPMax is zero", True)
            return self._oopmax_copay_handler(context)
        
        # Check individual OOPMax
        if context.oopmax_individual_calculated == 0:
            context.trace_decision("Process", "The individual OOPMax is zero", True)
            return self._oopmax_copay_handler(context)
        
        # OOPMax exists but not met
        context.trace_decision("Process", "The plan benefit has an OOPMax and its met", True)

        return context