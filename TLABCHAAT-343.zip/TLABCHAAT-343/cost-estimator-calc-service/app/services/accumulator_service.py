from abc import ABC, abstractmethod

from app.schemas.accumulator_response import AccumulatorResponse
from app.schemas.cost_estimator_request import CostEstimatorRequest


class AccumulatorServiceInterface(ABC):
    @abstractmethod
    async def get_accumulator(self, request: CostEstimatorRequest) -> AccumulatorResponse:
        """
        Abstract method to get accumulator information using a AccumulatorRequest object.
        Returns a getAccumulatorResponse object.
        """
        pass
