"""
Tests for the main application functionality.
"""

import pytest
from fastapi.testclient import TestClient


def test_app_import():
    """Test that the app can be imported successfully."""
    from app.main import app
    assert app is not None


def test_app_has_routes(client):
    """Test that the app has the expected routes."""
    response = client.get("/docs")
    assert response.status_code == 200


def test_health_check(client):
    """Test health check endpoint if it exists."""
    try:
        response = client.get("/health")
        assert response.status_code == 200
    except:
        # Health endpoint might not exist, which is fine
        pass


def test_openapi_schema(client):
    """Test that OpenAPI schema is accessible."""
    response = client.get("/openapi.json")
    assert response.status_code == 200
    schema = response.json()
    assert "openapi" in schema
    assert "paths" in schema


@pytest.mark.api
def test_rate_endpoint_exists(client):
    """Test that the rate endpoint exists in the API."""
    response = client.get("/openapi.json")
    assert response.status_code == 200
    schema = response.json()
    
    # Check if the rate endpoint exists in the paths
    rate_paths = [path for path in schema["paths"].keys() if "rate" in path.lower()]
    assert len(rate_paths) > 0, "Rate endpoint not found in API schema" 