from behave import given, when, then
from unittest.mock import Mock, patch
from app.services.handlers.oopmax_handler import OOPMaxHandler
from app.core.base import InsuranceContext

@given('an OOPMaxHandler is created')
def step_impl(context):
    context.handler = OOPMaxHandler()
    context.insurance_context = InsuranceContext()
    
    # Create a mock for the deductible handler
    mock_deductible_handler = Mock()
    mock_deductible_handler.return_value = context.insurance_context
    
    context.handler.set_deductible_handler(mock_deductible_handler)
    context.mock_deductible_handler = mock_deductible_handler

    # Create a mock for the oopmax co-pay handler
    mock_oopmax_copay_handler = Mock()
    mock_oopmax_copay_handler.return_value = context.insurance_context
    
    context.handler.set_oopmax_copay_handler(mock_oopmax_copay_handler)
    context.mock_oopmax_copay_handler = mock_oopmax_copay_handler

@given('member has OOPMax {has_max}')
def step_impl(context, has_max):
    context.insurance_context.has_oopmax = has_max.lower() == 'true'

@given('the family OOPMax is {amount:d}')
def step_impl(context, amount):
    context.insurance_context.oopmax_family_calculated = float(amount)

@given('the individual OOPMax is {amount:d}')
def step_impl(context, amount):
    context.insurance_context.oopmax_individual_calculated = float(amount)

@then('the deductible is checked')
def step_impl(context):
    context.mock_deductible_handler.assert_called_once_with(context.insurance_context)

@then('the oopmax co-pay is checked')
def step_impl(context):
    context.mock_oopmax_copay_handler.assert_called_once_with(context.insurance_context)

@then('the oopmax calculation is passed to the next handler')
def step_impl(context):
    assert context.result is context.insurance_context
    # Verify no specific handlers were called
    context.mock_deductible_handler.assert_not_called()
    context.mock_oopmax_copay_handler.assert_not_called()