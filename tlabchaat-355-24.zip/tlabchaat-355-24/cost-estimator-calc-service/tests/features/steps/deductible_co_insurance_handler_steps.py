from behave import given, when, then
from app.services.handlers.deductible_co_insurance_handler import DeductibleCoInsuranceHandler
from app.core.base import InsuranceContext

@given('an DeductibleCoInsuranceHandler is created')
def step_impl(context):
    context.handler = DeductibleCoInsuranceHandler()
    context.insurance_context = InsuranceContext()

@given('the co-insurance percent is {amount}')
def step_impl(context, amount):
    context.insurance_context.cost_share_coinsurance = float(amount)

@given('co-insurance applies to OOPMax {value}')
def step_impl(context, value):
    context.insurance_context.coins_applies_oop = value.lower() == 'true'