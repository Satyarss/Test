from behave import given, when, then
from app.services.handlers.cost_share_co_pay_handler import CostShareCoPayHandler
from app.core.base import InsuranceContext

@given('an CopayHandler is created')
def step_impl(context):
    context.handler = CostShareCoPayHandler()
    context.insurance_context = InsuranceContext()