"""
Tests for the service functionality.
"""

import pytest
from unittest.mock import Mock, patch, AsyncMock


@pytest.mark.service
def test_service_interface_import():
    """Test that the service interface can be imported."""
    from app.services.cost_estimation_service import CostEstimationServiceInterface

    assert CostEstimationServiceInterface is not None


@pytest.mark.service
def test_service_implementation_import():
    """Test that the service implementation can be imported."""
    from app.services.impl.cost_estimation_service_impl import CostEstimationServiceImpl

    assert CostEstimationServiceImpl is not None


@pytest.mark.service
def test_benefit_service_import():
    """Test that the benefit service can be imported."""
    from app.services.impl.benefit_service_impl import BenefitServiceImpl

    assert BenefitServiceImpl is not None


@pytest.mark.service
def test_accumulator_service_import():
    """Test that the accumulator service can be imported."""
    from app.services.impl.accumulator_service_impl import AccumulatorServiceImpl

    assert AccumulatorServiceImpl is not None


@pytest.mark.service
def test_cost_estimator_mapper_import():
    """Test that the cost estimator mapper can be imported."""
    from app.mappers.cost_estimator_mapper import CostEstimatorMapper

    assert CostEstimatorMapper is not None


@pytest.mark.service
def test_service_initialization():
    """Test that the service can be initialized."""
    from app.services.impl.cost_estimation_service_impl import CostEstimationServiceImpl

    with patch(
        "app.services.impl.cost_estimation_service_impl.CostEstimatorRepositoryImpl"
    ):
        service = CostEstimationServiceImpl()
        assert service is not None
        assert hasattr(service, "repository")


@pytest.mark.service
def test_mapper_to_benefit_request(valid_request_data):
    """Test the mapper's to_benefit_request method."""
    from app.mappers.cost_estimator_mapper import CostEstimatorMapper
    from app.schemas.cost_estimator_request import CostEstimatorRequest

    # Create a request object from the data
    request = CostEstimatorRequest(**valid_request_data)

    # Test the mapper
    benefit_request = CostEstimatorMapper.to_benefit_request(request)
    assert benefit_request is not None


@pytest.mark.service
def test_mapper_to_rate_criteria(valid_request_data):
    """Test the mapper's to_rate_criteria method."""
    from app.mappers.cost_estimator_mapper import CostEstimatorMapper
    from app.schemas.cost_estimator_request import CostEstimatorRequest

    # Create a request object from the data
    request = CostEstimatorRequest(**valid_request_data)

    # Test the mapper
    rate_criteria = CostEstimatorMapper.to_rate_criteria(request)
    assert rate_criteria is not None
    assert rate_criteria.serviceCode == "99214"
    assert rate_criteria.providerIdentificationNumber == "0004000317"


@pytest.mark.service
@pytest.mark.asyncio
@patch("app.services.impl.cost_estimation_service_impl.BenefitServiceImpl")
@patch("app.services.impl.cost_estimation_service_impl.AccumulatorServiceImpl")
@patch("app.services.impl.cost_estimation_service_impl.CostEstimatorRepositoryImpl")
async def test_service_estimate_cost(
    mock_repo, mock_accumulator, mock_benefit, valid_request_data
):
    """Test the service's estimate_cost method."""
    from app.services.impl.cost_estimation_service_impl import CostEstimationServiceImpl
    from app.schemas.cost_estimator_request import CostEstimatorRequest

    # Setup mocks
    mock_repo_instance = Mock()
    mock_repo_instance.get_rate = AsyncMock(return_value=150.50)
    mock_repo.return_value = mock_repo_instance

    mock_benefit_instance = Mock()
    mock_benefit_instance.get_benefit = AsyncMock(return_value={"benefit": "data"})
    mock_benefit.return_value = mock_benefit_instance

    mock_accumulator_instance = Mock()
    mock_accumulator_instance.get_accumulator = AsyncMock(
        return_value={"accumulator": "data"}
    )
    mock_accumulator.return_value = mock_accumulator_instance

    # Create service and test
    service = CostEstimationServiceImpl()
    request = CostEstimatorRequest(**valid_request_data)

    result = await service.estimate_cost(request)

    assert result["status"] == "success"
    assert result["rate"] == 150.50
    assert "benefit_response" in result
    assert "accumulator_response" in result
