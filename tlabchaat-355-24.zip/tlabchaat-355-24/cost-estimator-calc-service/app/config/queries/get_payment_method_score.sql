select payment_method_cd, score
from payment_method_hirerarchy
where payment_method_cd IN UNNEST(@payment_method_cd_list)
order by score asc
limit 1;