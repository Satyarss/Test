SELECT MAX(RATE) AS RATE
FROM CET_OON
WHERE
    SERVICE_CD = @servicecd
    AND SERVICE_TYPE_CD = @servicetype
    AND PLACE_OF_SERVICE_CD = @placeofservice
    AND ZIP_CODE_UN = @zipcode