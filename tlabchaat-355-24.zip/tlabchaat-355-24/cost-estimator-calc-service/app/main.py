from fastapi import FastAPI
from app.api.router import router
from app.core.exception_handler import include_exceptions
from app.core.exception_responses import responses
from app.config.database_config import spanner_config
from contextlib import asynccontextmanager
from app.repository.impl.cost_estimator_repository_impl import CostEstimatorRepositoryImpl


app = FastAPI(
    title="Cost Estimator API",
    description="Handles input validation and formats structured error responses.",
    version="1.0.0",
    responses=responses,
)

app = include_exceptions(app)

app.include_router(router)

repository = CostEstimatorRepositoryImpl()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan event to preload cache."""
    await repository.load_payment_method_hierarchy()
    yield
