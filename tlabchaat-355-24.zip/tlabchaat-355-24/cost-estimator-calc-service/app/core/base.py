from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime


@dataclass
class TraceEntry:
    """Single trace entry for debugging"""

    timestamp: datetime = field(default_factory=datetime.now)
    step: str = ""
    description: str = ""
    values: Dict[str, Any] = field(default_factory=dict)

    def __str__(self):
        return f"[{self.timestamp.strftime('%H:%M:%S.%f')[:-3]}] {self.step}: {self.description}"


@dataclass
class InsuranceContext:
    """Context containing all data needed for insurance calculations"""

    # Input data
    service_amount: float = 0.0
    is_service_covered: bool = False
    has_benefit_limitation: bool = False
    has_oopmax: bool = False

    # Values come from Benefits API
    cost_share_copay: float = 0.0
    cost_share_coinsurance: float = 0.0  # percentage (e.g., 20.0 for 20%)
    copay_applies_oop: bool = False
    coins_applies_oop: bool = False
    deductible_applies_oop: bool = False
    copay_continue_when_oop_met: bool = False
    is_deductible_before_copay: bool = False
    benefit_code: Optional[str] = None

    # Values come from Accum API
    oopmax_family_calculated: float = 0.0
    oopmax_individual_calculated: float = 0.0
    deductible_individual_calculated: float = 0.0  # can be None
    deductible_family_calculated: float = 0.0  # can be None
    limit_calculated: float = 0.0
    limit_type: Optional[str] = None  # counter, dollar

    # Results that will be populated
    member_pays: float = 0.0  # Can be a None type because of benefit limits
    insurance_pays: float = 0.0  # Can be a None type because of benefit limits

    # Tracking for calculation flow
    calculation_complete: bool = False

    # Tracing functionality
    trace_entries: List[TraceEntry] = field(default_factory=list)
    trace_enabled: bool = True

    def trace(self, step: str, description: str = "", **kwargs):
        """Add a trace entry with current context values"""
        if not self.trace_enabled:
            return

        # Take a snapshot of all context fields (excluding trace-related fields)
        trace_values = {}

        # Get all fields from the dataclass
        import dataclasses

        for field in dataclasses.fields(self):
            field_name = field.name
            # Skip trace-related fields to avoid circular references
            if field_name not in ["trace_entries", "trace_enabled"]:
                trace_values[field_name] = getattr(self, field_name)

        # Add any additional values passed as kwargs
        trace_values.update(kwargs)

        entry = TraceEntry(step=step, description=description, values=trace_values)

        self.trace_entries.append(entry)

    def trace_decision(self, step: str, condition: str, decision: bool, **kwargs):
        """Specialized trace for boolean decisions"""
        description = f"Decision: {condition} -> {decision}"
        self.trace(step, description, condition=condition, decision=decision, **kwargs)

    def get_trace_summary(self) -> str:
        """Get a formatted summary of all trace entries"""
        if not self.trace_entries:
            return "No trace entries"

        summary = "=== Calculation Trace ===\n"
        for i, entry in enumerate(self.trace_entries):
            summary += f"{entry}\n"

            # Show changes from previous entry
            if i > 0:
                prev_values = self.trace_entries[i - 1].values
                curr_values = entry.values
                changes = {}

                for key, curr_val in curr_values.items():
                    if key in prev_values:
                        prev_val = prev_values[key]
                        if prev_val != curr_val:
                            changes[key] = f"{prev_val} -> {curr_val}"
                    elif curr_val is not None and curr_val != 0 and curr_val != "":
                        changes[key] = f"None -> {curr_val}"

                if changes:
                    summary += f"    Changes: {changes}\n"
            else:
                # For first entry, show non-default values
                non_defaults = {
                    k: v
                    for k, v in entry.values.items()
                    if v is not None and v != 0 and v != "" and v != False
                }
                if non_defaults:
                    summary += f"    Initial state: {non_defaults}\n"

            summary += "\n"

        return summary


class Handler(ABC):
    """Base handler in the chain of responsibility"""

    def __init__(self):
        self._next_handler = None

    def set_next(self, handler: "Handler") -> "Handler":
        """Set the next handler in the chain"""
        self._next_handler = handler
        return handler  # Return handler to allow chaining

    def handle(self, context: InsuranceContext) -> InsuranceContext:
        """Process this handler and pass to the next if needed"""

        # Add trace entry for new handler
        context.trace(
            self.__class__.__name__, f"Starting {self.__class__.__name__} processing"
        )

        # Process this handler's logic
        context = self.process(context)

        # If calculation is complete or there's no next handler, return
        if context.calculation_complete or self._next_handler is None:
            return context

        # Otherwise, pass to next handler
        return self._next_handler.handle(context)

    @abstractmethod
    def process(self, context: InsuranceContext) -> InsuranceContext:
        """Each concrete handler will implement this method"""
        pass
