class BadRequestException(Exception):
    pass
