from app.core.base import InsuranceContext
from handlers.service_coverage_handler import ServiceCoverageHandler
from handlers.benefit_limitation_handler import BenefitLimitationHandler
from handlers.oopmax_handler import OOPMaxHandler
from app.services.handlers.oopmax_co_pay_handler import OOPMaxCopayHandler
from handlers.deductible_handler import DeductibleHandler
from app.services.handlers.cost_share_co_pay_handler import CostShareCoPayHandler
from handlers.deductible_cost_share_co_pay import DeductibleCostShareCoPayHandler
from handlers.deductible_oopmax_handler import DeductibleOOPMaxHandler
from handlers.deductible_co_pay_handler import DeductibleCoPayHandler
from handlers.deductible_co_insurance_handler import DeductibleCoInsuranceHandler


def create_calculation_chain():
    """Create and connect the chain of handlers with branches based on logic tree"""

    # Create handlers
    coverage_handler = ServiceCoverageHandler()
    benefit_limitation_handler = BenefitLimitationHandler()
    oopmax_handler = OOPMaxHandler()
    oopmax_co_pay_handler = OOPMaxCopayHandler()
    deductible_handler = DeductibleHandler()
    cost_share_co_pay_handler = CostShareCoPayHandler()
    deductible_cost_share_co_pay_handler = DeductibleCostShareCoPayHandler()
    deductible_oopmax_handler = DeductibleOOPMaxHandler()
    deductible_co_pay_handler = DeductibleCoPayHandler()
    deductible_co_insurance_handler = DeductibleCoInsuranceHandler()

    # Setup chain
    coverage_handler.set_next(benefit_limitation_handler)
    benefit_limitation_handler.set_deductible_cost_share_co_handler(
        deductible_cost_share_co_pay_handler
    )
    benefit_limitation_handler.set_next(oopmax_handler)  # default path

    # Setup branch path for OOPMax Handler
    oopmax_handler.set_deductible_handler(deductible_handler)
    oopmax_handler.set_oopmax_copay_handler(oopmax_co_pay_handler)
    oopmax_handler.set_next(deductible_handler)

    # Setup branch path for Deductible Handler
    deductible_handler.set_deductible_oopmax_handler(deductible_oopmax_handler)
    deductible_handler.set_cost_share_co_pay_handler(cost_share_co_pay_handler)
    deductible_handler.set_next(cost_share_co_pay_handler)

    # Setup branch path for Deductible OOPMax Handler
    deductible_oopmax_handler.set_deductible_co_pay_handler(deductible_co_pay_handler)
    deductible_oopmax_handler.set_deductible_co_insurance_handler(
        deductible_co_insurance_handler
    )

    # Setup branch path for Deductible Cost Share Co-pay Handler
    deductible_cost_share_co_pay_handler.set_deductible_co_pay_handler(
        deductible_co_pay_handler
    )
    deductible_cost_share_co_pay_handler.set_deductible_co_insurance_handler(
        deductible_co_insurance_handler
    )
    # deductible_cost_share_co_pay_handler.set_next(None)

    # Continue to add the rest of our handlers
    deductible_co_insurance_handler.set_next(deductible_co_insurance_handler)

    return coverage_handler  # Return first handler


# Running a scenario
chain = create_calculation_chain()

# Scenario 1: Service not covered
print("\n=== Scenario 1: Service Not Covered ===")
context1 = InsuranceContext(
    service_amount=500.0,
    is_service_covered=False,
    cost_share_copay=20.0,
    cost_share_coinsurance=20.0,
    oopmax_family_calculated=2000.0,
    oopmax_individual_calculated=1000.0,
    deductible_individual_calculated=250.0,
    is_deductible_before_copay=True,
)
result1 = chain.handle(context1)
print(
    f"Final result: Member pays ${result1.member_pays:.2f}, Insurance pays ${result1.insurance_pays:.2f}"
)
print(f"Trace: {result1.get_trace_summary()}")
