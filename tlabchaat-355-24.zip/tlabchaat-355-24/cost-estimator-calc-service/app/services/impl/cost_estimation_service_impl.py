import json
import asyncio
from app.services.cost_estimation_service import CostEstimationServiceInterface
from app.services.impl.benefit_service_impl import BenefitServiceImpl
from app.services.impl.accumulator_service_impl import AccumulatorServiceImpl
from app.schemas.cost_estimator_request import CostEstimatorRequest
from app.repository.impl.cost_estimator_repository_impl import (
    CostEstimatorRepositoryImpl,
)
from app.mappers.cost_estimator_mapper import CostEstimatorMapper
from app.core.logger import logger
from app.schemas.benefit_request import BenefitRequest


benefits_headers = {
    "Content-Type": "application/json",
}


class CostEstimationServiceImpl(CostEstimationServiceInterface):
    def __init__(self):
        self.repository = CostEstimatorRepositoryImpl()

    async def estimate_cost(self, request: CostEstimatorRequest):
        # BENEFICIAL TO DO THE FOLLOWING IN PARALLEL?
        # Map the incoming request to a BenefitRequest using the mapper
        benefit_request = CostEstimatorMapper.to_benefit_request(request)
        print("benefit_request", benefit_request)
        rate_criteria = CostEstimatorMapper.to_rate_criteria(request)
        print("rate_criteria", rate_criteria)

        try:
            benefit_service = BenefitServiceImpl()
            accumulator_service = AccumulatorServiceImpl()

            # Call all three operations in parallel
            benefit_response, accumulator_response, rate = await asyncio.gather(
                benefit_service.get_benefit(benefit_request),
                accumulator_service.get_accumulator(request),
                self.repository.get_rate(rate_criteria=rate_criteria),
            )
            if rate != "NA":
                rate = float(rate)

            return {
                "status": "success",
                "rate": rate,
                "benefit_response": benefit_response,
                "accumulator_response": accumulator_response,
            }

        except Exception as e:
            logger.error(f"Error in get_rate: {str(e)}")
            return {"status": "error", "message": str(e), "rate": None}
