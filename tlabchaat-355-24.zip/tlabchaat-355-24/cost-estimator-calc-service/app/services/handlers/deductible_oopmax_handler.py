from app.core.base import Handler, InsuranceContext


class DeductibleOOPMaxHandler(Handler):
    """Handles logic for OOPMax calculations for deductibles"""

    def set_deductible_co_pay_handler(self, handler):
        self._deductible_co_pay_handler = handler
        return handler

    def set_deductible_co_insurance_handler(self, handler):
        self._deductible_co_insurance_handler = handler
        return handler

    def process(self, context):
        if context.service_amount < context.deductible_individual_calculated:
            context.trace_decision(
                "Process",
                "The service amount is less than the individual deductible",
                True,
            )
            return self._apply_member_pays_full_and_deductible_and_oopmax_updated(
                context
            )

        # Update deductible and OOPMax
        context = self._apply_deductible_met_and_oopmax_updated(context)

        if context.is_deductible_before_copay:
            context.trace_decision("Process", "The deductible is before co-pay", True)
            return self._deductible_co_pay_handler(context)
        else:
            context.trace_decision("Process", "The deductible is before co-pay", False)
            return self._deductible_co_insurance_handler(context)

    def _apply_member_pays_full_and_deductible_and_oopmax_updated(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays full service cost. It will get counted towards individual and family OOPMax. It will also update individual/family deductibles"""

        context.member_pays = context.service_amount
        context.insurance_pays = 0.0
        context.deductible_individual_calculated -= context.member_pays
        context.deductible_family_calculated -= context.member_pays
        context.oopmax_individual_calculated -= context.member_pays
        context.oopmax_family_calculated -= context.member_pays
        context.calculation_complete = True

        context.trace(
            "_apply_member_pays_full_and_deductible_and_oopmax_updated", "Logic applied"
        )

        return context

    def _apply_deductible_met_and_oopmax_updated(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays the individual deductible and now the deductible is met. Member pays co-insurance on the remaining amount."""
        """Acount the deductible and co-insurance paid by member to individual/family OOPmax"""

        context.member_pays = context.deductible_individual_calculated
        context.insurance_pays = (
            context.service_amount - context.deductible_individual_calculated
        )
        context.deductible_individual_calculated -= context.member_pays
        context.deductible_family_calculated -= context.member_pays
        context.oopmax_individual_calculated -= context.member_pays
        context.oopmax_family_calculated -= context.member_pays

        context.trace("_apply_deductible_met_and_oopmax_updated", "Logic applied")

        return context
