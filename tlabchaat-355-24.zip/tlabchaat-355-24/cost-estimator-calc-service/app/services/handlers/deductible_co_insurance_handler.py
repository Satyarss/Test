from app.core.base import Handler, InsuranceContext


class DeductibleCoInsuranceHandler(Handler):
    """Determines any member co-insurance"""

    def process(self, context):
        if not context.cost_share_coinsurance > 0:
            context.trace_decision("Process", "The co-insurance is zero", True)
            return self._apply_member_pays_no_co_insurance(context)

        if not context.coins_applies_oop:
            context.trace_decision("Process", "The co-insurance applies to OOP", False)
            return self._apply_member_no_coverage_if_limited_exceeded(context)

        # TODO: Add the Code and Level checks
        if context.oopmax_family_calculated == 0:
            context.trace_decision("Process", "The family OOPMax is zero", True)
            return self._apply_member_family_oopmax_met(context)

        if context.oopmax_individual_calculated == 0:
            context.trace_decision("Process", "The individual OOPMax is zero", True)
            return self._apply_member_individual_oopmax_met(context)

        # co insurance is a percentage. 20.0 is 20%
        co_insurance_amount = (
            int(context.cost_share_coinsurance) / 100
        ) * context.service_amount

        if (
            co_insurance_amount < context.oopmax_individual_calculated
            and context.cost_share_coinsurance < context.oopmax_family_calculated
        ):
            context.trace_decision(
                "Process",
                "The co-insurance amount is less than the individual and family OOPMax",
                True,
            )
            return self._apply_member_pays_co_insurance_and_applied_to_oopmax(
                context, co_insurance_amount
            )
        else:
            context.trace_decision(
                "Process",
                "The co-insurance amount is less than the individual and family OOPMax",
                False,
            )
            return self._apply_member_pays_oopmax_difference(context)

    def _apply_member_pays_no_co_insurance(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays no co-insurance. No other cost sharing"""

        # Nothing to update
        context.calculation_complete = True

        context.trace("_apply_member_pays_no_co_insurance", "Logic applied")

        return context

    def _apply_member_no_coverage_if_limited_exceeded(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """This is an OON service for this plan. There is no co-insurance on out of network, there is no OOPMax. If limit is exceeded, then coverage not available and does not count to OOPMax"""

        context.member_pays = context.service_amount
        context.insurance_pays = 0.0
        context.calculation_complete = True

        context.trace("_apply_member_no_coverage_if_limited_exceeded", "Logic applied")

        return context

    def _apply_member_family_oopmax_met(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Since OOPMax has been reached for family. No co-insurance applied"""

        context.member_pays = 0.0
        context.insurance_pays = context.service_amount
        context.calculation_complete = True

        context.trace("_apply_member_family_oopmax_met", "Logic applied")

        return context

    def _apply_member_individual_oopmax_met(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Since OOPMax has been reached for individual. No co-insurance applied"""

        context.member_pays = 0.0
        context.insurance_pays = context.service_amount
        context.calculation_complete = True

        context.trace("_apply_member_individual_oopmax_met", "Logic applied")

        return context

    def _apply_member_pays_co_insurance_and_applied_to_oopmax(
        self, context: InsuranceContext, co_insurance_amount
    ) -> InsuranceContext:
        """Member pays co-insurance amount. OOPMax will be updated"""

        context.member_pays = co_insurance_amount
        context.insurance_pays = context.service_amount - context.member_pays
        context.calculation_complete = True
        context.oopmax_individual_calculated -= context.member_pays
        context.oopmax_family_calculated -= context.member_pays

        context.trace(
            "_apply_member_pays_co_insurance_and_applied_to_oopmax", "Logic applied"
        )

        return context

    def _apply_member_pays_oopmax_difference(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays oopmax difference"""

        context.member_pays = (
            context.oopmax_individual_calculated
            if context.oopmax_individual_calculated < context.oopmax_family_calculated
            else context.oopmax_family_calculated
        )
        context.insurance_pays = context.service_amount - context.member_pays
        context.calculation_complete = True
        context.oopmax_individual_calculated -= context.member_pays
        context.oopmax_family_calculated -= context.member_pays

        context.trace("_apply_member_pays_oopmax_difference", "Logic applied")

        return context
