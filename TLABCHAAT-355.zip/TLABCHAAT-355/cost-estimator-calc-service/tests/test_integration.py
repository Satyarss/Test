"""
Integration tests for the cost estimator service.
These tests verify the full flow from API request to response.
"""

import pytest
import asyncio
from fastapi.testclient import TestClient
from unittest.mock import patch, AsyncMock
from app.main import app
from app.schemas.cost_estimator_request import CostEstimatorRequest


@pytest.mark.integration
def test_full_api_integration(client):
    """Test the complete API integration flow."""
    # Test data
    request_data = {
        "membershipId": "5~186103331+10+7+20240101+793854+8A+829",
        "zipCode": "85305",
        "benefitProductType": "Medical",
        "languageCode": "11",
        "service": {
            "code": "99214",
            "type": "CPT4",
            "description": "Adult Office visit Age 30-39",
            "supportingService": {"code": "470", "type": "DRG"},
            "modifier": {"modifierCode": "E1"},
            "diagnosisCode": "F33 40",
            "placeOfService": {"code": "11"}
        },
        "providerInfo": [
            {
                "serviceLocation": "000761071",
                "providerType": "HO",
                "speciality": {"code": "91017"},
                "taxIdentificationNumber": "0000431173518",
                "taxIdQualifier": "SN",
                "providerNetworks": {"networkID": "58921"},
                "providerIdentificationNumber": "0004000317",
                "nationalProviderId": "1386660504",
                "providerNetworkParticipation": {"providerTier": "1"}
            }
        ]
    }

    # Mock external services to avoid actual API calls
    with patch("app.services.impl.benefit_service_impl.BenefitServiceImpl.get_benefit") as mock_benefit, \
         patch("app.services.impl.accumulator_service_impl.AccumulatorServiceImpl.get_accumulator") as mock_accumulator, \
         patch("app.repository.impl.cost_estimator_repository_impl.CostEstimatorRepositoryImpl.get_rate") as mock_rate:
        
        # Setup mock responses
        mock_benefit.return_value = {"benefit": "test_benefit_data"}
        mock_accumulator.return_value = {"accumulator": "test_accumulator_data"}
        mock_rate.return_value = 150.50

        # Make API request
        response = client.post("/costestimator/v1/rate", json=request_data)
        
        # Verify response
        assert response.status_code == 200
        result = response.json()
        assert "message" in result
        assert "rate" in result
        
        # The rate field contains the service response
        rate_data = result["rate"]
        assert rate_data["status"] == "success"
        assert rate_data["rate"] == 150.50
        assert "benefit_response" in rate_data
        assert "accumulator_response" in rate_data


@pytest.mark.integration
def test_api_with_invalid_data(client):
    """Test API behavior with invalid request data."""
    # Test with missing required fields
    invalid_request = {
        "membershipId": "test"
        # Missing other required fields
    }

    response = client.post("/costestimator/v1/rate", json=invalid_request)
    assert response.status_code == 400  # Validation error


@pytest.mark.integration
def test_api_error_handling(client):
    """Test API error handling when external services fail."""
    request_data = {
        "membershipId": "5~186103331+10+7+20240101+793854+8A+829",
        "zipCode": "85305",
        "benefitProductType": "Medical",
        "languageCode": "11",
        "service": {
            "code": "99214",
            "type": "CPT4",
            "description": "Adult Office visit Age 30-39",
            "supportingService": {"code": "470", "type": "DRG"},
            "modifier": {"modifierCode": "E1"},
            "diagnosisCode": "F33 40",
            "placeOfService": {"code": "11"}
        },
        "providerInfo": [
            {
                "serviceLocation": "000761071",
                "providerType": "HO",
                "speciality": {"code": "91017"},
                "taxIdentificationNumber": "0000431173518",
                "taxIdQualifier": "SN",
                "providerNetworks": {"networkID": "58921"},
                "providerIdentificationNumber": "0004000317",
                "nationalProviderId": "1386660504",
                "providerNetworkParticipation": {"providerTier": "1"}
            }
        ]
    }

    # Mock external service to raise an exception
    with patch("app.services.impl.benefit_service_impl.BenefitServiceImpl.get_benefit") as mock_benefit:
        mock_benefit.side_effect = Exception("Benefit service unavailable")

        response = client.post("/costestimator/v1/rate", json=request_data)
        assert response.status_code in [200, 400]  # Service handles errors gracefully
        result = response.json()
        assert "message" in result
        assert "rate" in result
        
        # The rate field contains the service response
        rate_data = result["rate"]
        assert rate_data["status"] == "error"
        assert "message" in rate_data


@pytest.mark.integration
@pytest.mark.asyncio
async def test_service_integration_with_real_data():
    """Test service integration with real data structures."""
    from app.services.impl.cost_estimation_service_impl import CostEstimationServiceImpl
    from app.schemas.cost_estimator_request import CostEstimatorRequest

    # Create real request object
    request_data = {
        "membershipId": "5~186103331+10+7+20240101+793854+8A+829",
        "zipCode": "85305",
        "benefitProductType": "Medical",
        "languageCode": "11",
        "service": {
            "code": "99214",
            "type": "CPT4",
            "description": "Adult Office visit Age 30-39",
            "supportingService": {"code": "470", "type": "DRG"},
            "modifier": {"modifierCode": "E1"},
            "diagnosisCode": "F33 40",
            "placeOfService": {"code": "11"}
        },
        "providerInfo": [
            {
                "serviceLocation": "000761071",
                "providerType": "HO",
                "speciality": {"code": "91017"},
                "taxIdentificationNumber": "0000431173518",
                "taxIdQualifier": "SN",
                "providerNetworks": {"networkID": "58921"},
                "providerIdentificationNumber": "0004000317",
                "nationalProviderId": "1386660504",
                "providerNetworkParticipation": {"providerTier": "1"}
            }
        ]
    }

    request = CostEstimatorRequest(**request_data)

    # Mock external dependencies
    with patch("app.services.impl.benefit_service_impl.BenefitServiceImpl.get_benefit") as mock_benefit, \
         patch("app.services.impl.accumulator_service_impl.AccumulatorServiceImpl.get_accumulator") as mock_accumulator, \
         patch("app.repository.impl.cost_estimator_repository_impl.CostEstimatorRepositoryImpl.get_rate") as mock_rate:
        
        # Setup mock responses
        mock_benefit.return_value = {"benefit": "test_benefit_data"}
        mock_accumulator.return_value = {"accumulator": "test_accumulator_data"}
        mock_rate.return_value = 150.50

        # Test service
        service = CostEstimationServiceImpl()
        result = await service.estimate_cost(request)

        # Verify result
        assert result["status"] == "success"
        assert result["rate"] == 150.50
        assert "benefit_response" in result
        assert "accumulator_response" in result


@pytest.mark.integration
def test_mapper_integration():
    """Test the complete mapper integration."""
    from app.mappers.cost_estimator_mapper import CostEstimatorMapper
    from app.schemas.cost_estimator_request import CostEstimatorRequest

    # Test data
    request_data = {
        "membershipId": "5~186103331+10+7+20240101+793854+8A+829",
        "zipCode": "85305",
        "benefitProductType": "Medical",
        "languageCode": "11",
        "service": {
            "code": "99214",
            "type": "CPT4",
            "description": "Adult Office visit Age 30-39",
            "supportingService": {"code": "470", "type": "DRG"},
            "modifier": {"modifierCode": "E1"},
            "diagnosisCode": "F33 40",
            "placeOfService": {"code": "11"}
        },
        "providerInfo": [
            {
                "serviceLocation": "000761071",
                "providerType": "HO",
                "speciality": {"code": "91017"},
                "taxIdentificationNumber": "0000431173518",
                "taxIdQualifier": "SN",
                "providerNetworks": {"networkID": "58921"},
                "providerIdentificationNumber": "0004000317",
                "nationalProviderId": "1386660504",
                "providerNetworkParticipation": {"providerTier": "1"}
            }
        ]
    }

    request = CostEstimatorRequest(**request_data)

    # Test benefit request mapping
    benefit_request = CostEstimatorMapper.to_benefit_request(request)
    assert benefit_request.benefitProductType == "Medical"
    assert benefit_request.membershipID == "5~186103331+10+7+20240101+793854+8A+829"
    assert len(benefit_request.serviceInfo) == 1
    assert benefit_request.serviceInfo[0].serviceCodeInfo.code == "99214"

    # Test rate criteria mapping
    rate_criteria = CostEstimatorMapper.to_rate_criteria(request)
    assert rate_criteria.serviceCode == "99214"
    assert rate_criteria.providerIdentificationNumber == "0004000317"
    assert rate_criteria.zipCode == "85305"
    assert rate_criteria.isOutofNetwork is False


@pytest.mark.integration
def test_end_to_end_flow():
    """Test the complete end-to-end flow from request to response."""
    from app.services.impl.cost_estimation_service_impl import CostEstimationServiceImpl
    from app.schemas.cost_estimator_request import CostEstimatorRequest
    from app.mappers.cost_estimator_mapper import CostEstimatorMapper

    # Test data
    request_data = {
        "membershipId": "5~186103331+10+7+20240101+793854+8A+829",
        "zipCode": "85305",
        "benefitProductType": "Medical",
        "languageCode": "11",
        "service": {
            "code": "99214",
            "type": "CPT4",
            "description": "Adult Office visit Age 30-39",
            "supportingService": {"code": "470", "type": "DRG"},
            "modifier": {"modifierCode": "E1"},
            "diagnosisCode": "F33 40",
            "placeOfService": {"code": "11"}
        },
        "providerInfo": [
            {
                "serviceLocation": "000761071",
                "providerType": "HO",
                "speciality": {"code": "91017"},
                "taxIdentificationNumber": "0000431173518",
                "taxIdQualifier": "SN",
                "providerNetworks": {"networkID": "58921"},
                "providerIdentificationNumber": "0004000317",
                "nationalProviderId": "1386660504",
                "providerNetworkParticipation": {"providerTier": "1"}
            }
        ]
    }

    # Create request object
    request = CostEstimatorRequest(**request_data)

    # Test mapping
    benefit_request = CostEstimatorMapper.to_benefit_request(request)
    rate_criteria = CostEstimatorMapper.to_rate_criteria(request)

    assert benefit_request is not None
    assert rate_criteria is not None

    # Test service with mocks
    async def test_service():
        with patch("app.services.impl.benefit_service_impl.BenefitServiceImpl.get_benefit") as mock_benefit, \
             patch("app.services.impl.accumulator_service_impl.AccumulatorServiceImpl.get_accumulator") as mock_accumulator, \
             patch("app.repository.impl.cost_estimator_repository_impl.CostEstimatorRepositoryImpl.get_rate") as mock_rate:
            
            mock_benefit.return_value = {"benefit": "test_data"}
            mock_accumulator.return_value = {"accumulator": "test_data"}
            mock_rate.return_value = 150.50

            service = CostEstimationServiceImpl()
            result = await service.estimate_cost(request)

            assert result["status"] == "success"
            assert result["rate"] == 150.50
            return result

    # Run async test
    result = asyncio.run(test_service())
    assert result is not None 