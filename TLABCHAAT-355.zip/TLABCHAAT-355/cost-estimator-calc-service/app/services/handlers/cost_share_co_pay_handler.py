from app.core.base import Handler, InsuranceContext


class CostShareCoPayHandler(Handler):
    """Check cost share when there is no accumlated deductible"""

    def process(self, context):
        if (
            context.cost_share_copay > 0
            and context.cost_share_copay > context.service_amount
        ):
            # Member pays lesser of service amount and remaining OOPMax individual.
            # The value is applied to OOPMax individual and family calculated value
            if (
                context.service_amount < context.oopmax_individual_calculated
                and context.service_amount < context.oopmax_family_calculated
            ):
                context.trace_decision(
                    "Process",
                    "The service amount is less than the individual and family OOPMax",
                    True,
                )
                return self._apply_member_pays_service_amount(context)
            else:
                context.trace_decision(
                    "Process",
                    "The service amount is less than the individual and family OOPMax",
                    False,
                )
                return self._apply_member_pays_oopmax_difference(context)
        else:
            # Member pays lesser of the cost share copay amount and remaining
            # OOPMax individual calculated. The value is applied to OOPMax individual and family calculated value
            if (
                context.cost_share_copay < context.oopmax_individual_calculated
                and context.cost_share_copay < context.oopmax_family_calculated
            ):
                context.trace_decision(
                    "Process",
                    "The cost share co-pay is less than the individual and family OOPMax",
                    True,
                )
                return self._apply_member_pays_cost_share_copay(context)
            else:
                context.trace_decision(
                    "Process",
                    "The cost share co-pay is less than the individual and family OOPMax",
                    False,
                )
                return self._apply_member_pays_oopmax_difference(context)

    def _apply_member_pays_cost_share_copay(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """The member pays cost share copay and its applied to OOPMax"""

        context.member_pays = context.cost_share_copay
        context.insurance_pays = context.service_amount - context.member_pays
        context.oopmax_individual_calculated -= context.member_pays
        context.oopmax_family_calculated -= context.member_pays
        context.calculation_complete = True

        context.trace("_apply_member_pays_cost_share_copay", "Logic applied")

        return context

    def _apply_member_pays_oopmax_difference(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays lesser of the OOPMax and its applied to OOPMax. OOPMax is now met"""

        context.member_pays = (
            context.oopmax_individual_calculated
            if context.oopmax_individual_calculated < context.oopmax_family_calculated
            else context.oopmax_family_calculated
        )
        context.insurance_pays = context.service_amount - context.member_pays
        context.oopmax_individual_calculated -= context.member_pays
        context.oopmax_family_calculated -= context.member_pays
        context.calculation_complete = True

        context.trace("_apply_member_pays_oopmax_difference", "Logic applied")

        return context

    def _apply_member_pays_service_amount(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays service amount and OOPMax is updated"""

        context.member_pays = context.service_amount
        context.insurance_pays = 0
        context.oopmax_individual_calculated -= context.service_amount
        context.oopmax_family_calculated -= context.service_amount
        context.calculation_complete = True

        context.trace("_apply_member_pays_service_amount", "Logic applied")

        return context
