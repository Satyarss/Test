
from behave import given, when, then
from app.services.handlers.benefit_limitation_handler import BenefitLimitationHandler

@given('a BenefitLimitationHandler is created')
def step_create_handler(context):
    context.handler = BenefitLimitationHandler()

@given('does not have a benefit limitation')
def step_does_not_have_benefit_limit(context):
    context.insurance_context.has_benefit_limitation = False

@given('a benefit dollar limit of {limit_amount}')
def step_has_a_benefit_limit_of_zero(context, limit_amount):
    context.insurance_context.limit_calculated = float(limit_amount)
    context.insurance_context.benefit_code = 'limit'
    context.insurance_context.limit_type = 'dollar'
    context.insurance_context.has_benefit_limitation = True

@given('a benefit quantity limit of {limit_amount}')
def step_impl(context, limit_amount):
    context.insurance_context.limit_calculated = float(limit_amount)
    context.insurance_context.benefit_code = 'limit'
    context.insurance_context.limit_type = 'counter'
    context.insurance_context.has_benefit_limitation = True

@then('now has a benefit dollar limit of {limit_amount}')
def step_has_a_benefit_limit_of_zero(context, limit_amount):
    context.insurance_context.limit_calculated = float(limit_amount)