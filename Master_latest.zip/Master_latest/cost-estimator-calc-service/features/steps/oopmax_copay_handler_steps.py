from behave import given, when, then
from app.services.handlers.oopmax_co_pay_handler import OOPMaxCopayHandler
from app.core.base import InsuranceContext

@given('an OOPMaxCopayHandler is created')
def step_impl(context):
    context.handler = OOPMaxCopayHandler()
    context.insurance_context = InsuranceContext()

@given('the co-pay continues with OOPMax {cont}')
def step_impl(context, cont):
    context.insurance_context.copay_continue_when_oop_met = cont.lower() == 'true'