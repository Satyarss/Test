from abc import ABC, abstractmethod

from app.models.rate_criteria import CostEstimatorRateCriteria


class CostEstimatorRepositoryInterface(ABC):
    @abstractmethod
    async def get_rate(
        self,
        is_out_of_network: bool,
        rate_criteria: CostEstimatorRateCriteria,
        *args,
        **kwargs
    ) -> float:
        """
        Retrieve the rate based on the network status and criteria.
        """
        pass
