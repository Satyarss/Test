from app.repository.cost_estimator_repository import CostEstimatorRepositoryInterface
from app.database.spanner_client import SpannerClient
from app.config.database_config import spanner_config
from app.config.queries import RATE_QUERIES
from app.core.logger import logger
from app.models.rate_criteria import CostEstimatorRateCriteria
from typing import Any


class CostEstimatorRepositoryImpl(CostEstimatorRepositoryInterface):
    def __init__(self):
        """Initialize repository with Spanner client."""
        if not spanner_config.is_valid():
            raise ValueError(
                "Invalid Spanner configuration. Please check environment variables."
            )

        self.db = SpannerClient(
            project_id=spanner_config.project_id,
            instance_id=spanner_config.instance_id,
            database_id=spanner_config.database_id,
            max_workers=20,  # Increase for better parallelism
            pool_size=10,  # More connections for concurrent requests
        )

    async def get_rate(
        self, rate_criteria: CostEstimatorRateCriteria, *args, **kwargs
    ) -> float:
        """
        Retrieve the rate based on network status and criteria.

        Args:
            is_out_of_network: Whether to get out-of-network rate
            rate_criteria: Criteria for rate lookup
            *args: Variable length argument list
            **kwargs: Arbitrary keyword arguments

        Returns:
            float: The calculated rate
        """

        # Try claim-based rate first - provide default values for missing parameters
        params = self._build_rate_params(rate_criteria)

        # Try claim-based rate first
        claim_result = await self._get_claim_based_rate(params)
        logger.info(f"Claim-based rate result: {claim_result}")

        # Check if claim-based rate was found
        rate = self._extract_single_value(
            claim_result, column_index=0, default_value=0.0
        )
        if isinstance(rate, (int, float)) and rate > 0:
            logger.info(f"Successfully extracted claim-based rate: {rate}")
            return rate
        else:
            logger.info("No claim-based rate found, proceeding to get provider info")

        provider_info_result = await self._get_provider_info(params)
        logger.info(f"Provider info result: {provider_info_result}")

        # Extract provider information and update params
        updated_params = self._extract_provider_info_and_update_params(
            provider_info_result, params
        )

        # ADD OON logic here

        if updated_params and "contracttype" in updated_params:
            if updated_params["contracttype"] == "S":
                del updated_params["providerbusinessgroupnbr"]
                get_standard_rate = await self._get_standard_rate(updated_params)
                rate = self._extract_single_value(
                    get_standard_rate, column_index=0, default_value=0.0
                )
                return float(rate)
            else:
                # You need to get the rate from somewhere - this might need adjustment
                del updated_params["contracttype"]
                get_non_standard_rate = await self._get_non_standard_rate(
                    updated_params
                )
                rate = self._extract_single_value(
                    get_non_standard_rate, column_index=0, default_value=0.0
                )
                return float(rate)

            # ADD DEFAULT CONTRACT LOGIC AROUND HERE

        return 0.0

    async def _get_provider_info(self, params):
        try:
            provider_info_query = RATE_QUERIES.get("get_provider_info")
            if not provider_info_query:
                logger.error("get_provider_info not found in RATE_QUERIES")
                return []
            result = await self.db.execute_query(provider_info_query, params)
            return result
        except Exception as e:
            logger.error(f"Error in _get_provider_info: {str(e)}")
            return []

    async def _get_claim_based_rate(self, params):
        try:

            claim_query = RATE_QUERIES.get("get_claim_based_rate")
            if not claim_query:
                logger.error("get_claim_based_rate not found in RATE_QUERIES")
                return []
            # Execute the actual query with parameters
            result = await self.db.execute_query(claim_query, params)

            return result
        except Exception as e:
            logger.error(f"Error in _get_claim_based_rate: {str(e)}")
            return []

    async def _get_non_standard_rate(self, params):
        try:
            non_standard_query = RATE_QUERIES.get("get_non_standard_rate")
            if not non_standard_query:
                logger.error("get_non_standard_rate not found in RATE_QUERIES")
                return []
            result = await self.db.execute_query(non_standard_query, params)
            return result
        except Exception as e:
            logger.error(f"Error in _get_non_standard_rate: {str(e)}")
            return []

    async def _get_standard_rate(self, params):
        try:
            standard_query = RATE_QUERIES.get("get_standard_rate")
            if not standard_query:
                logger.error("get_standard_rate not found in RATE_QUERIES")
                return []
            print("standard_query-->", standard_query)
            print("params-->", params)
            result = await self.db.execute_query(standard_query, params)
            return result
        except Exception as e:
            logger.error(f"Error in _get_standard_rate: {str(e)}")
            return []

    def _extract_single_value(self, result, column_index=0, default_value: Any = "NA"):
        """
        Extract a single value from query result.

        Args:
            result: Query result (list of lists)
            column_index: Index of the column to extract (default 0)
            default_value: Value to return if extraction fails

        Returns:
            Extracted value converted to the same type as default_value
        """
        if not result or len(result) == 0:
            logger.info("No results found")
            return default_value

        first_row = result[0]
        if column_index >= len(first_row):
            logger.warning(
                f"Column index {column_index} out of range for row {first_row}"
            )
            return default_value

        value = first_row[column_index]
        logger.info(f"Extracted value: {value}")

        if value is None:
            logger.info("Value is None, returning default")
            return default_value

        # Convert to the same type as default_value
        if isinstance(default_value, (int, float)):
            try:
                return float(value)
            except (ValueError, TypeError):
                return default_value
        else:
            return str(value)

    def _extract_provider_info_and_update_params(self, result, params):
        """
        Extract provider information and update query parameters.

        Args:
            result: Query result with format [['PBG_NUMBER', 'PRODUCT_CD', 'RATING_SYSTEM_CD', 'GEOGRAPHIC_AREA_CD'], ...]
            params: Original query parameters

        Returns:
            Updated parameters dictionary with provider data, or None if no provider data found
        """
        if not result or len(result) == 0:
            logger.info("No provider info results found")
            return None

        updated_params = params.copy()

        # Remove keys from dictionary using del
        if "provideridentificationnumber" in updated_params:
            del updated_params["provideridentificationnumber"]
        if "networkid" in updated_params:
            del updated_params["networkid"]
        if "servicelocationnumber" in updated_params:
            del updated_params["servicelocationnumber"]

        # Get first row of provider data
        first_row = result[0]
        if len(first_row) >= 4:
            # Determine contract type based on provider_business_group_nbr
            if first_row[0] == "None" or first_row[0] == "" or not first_row[0]:
                contract_type = "S"
            else:
                contract_type = "N"

            # Add provider data to parameters
            updated_params.update(
                {
                    "providerbusinessgroupnbr": first_row[
                        0
                    ],  # Provider Business Group Number
                    "productcd": first_row[1],  # Product Code
                    "ratesystemcd": first_row[2],  # Rating System Code
                    "geographicareacd": first_row[3],  # Geographic Area Code
                    "contracttype": contract_type,
                }
            )

            return updated_params
        else:
            logger.warning(f"Row has insufficient columns: {first_row}")
            return None

    def _build_rate_params(self, rate_criteria: CostEstimatorRateCriteria) -> dict:
        """
        Build rate parameters from rate criteria.

        Args:
            rate_criteria: Rate criteria object

        Returns:
            Dictionary of rate parameters
        """
        return {
            "servicecd": rate_criteria.serviceCode,
            "provideridentificationnumber": rate_criteria.providerIdentificationNumber,
            "placeofservice": rate_criteria.placeOfService,
            "servicetype": rate_criteria.serviceType,
            "networkid": rate_criteria.networkId,
            "servicelocationnumber": rate_criteria.serviceLocationNumber,
        }
