from dataclasses import dataclass


@dataclass
class CostEstimatorRateCriteria:
    """
    A data class representing the criteria used for cost estimation calculations.

    Attributes:
        providerIdentificationNumber: The provider identification number
        serviceCode: The service code identifier
        serviceType: The type of service being provided
        serviceLocationNumber: The location number where service is provided
        zipCode: The ZIP code of the service location
    """

    providerIdentificationNumber: str
    serviceCode: str
    serviceType: str
    serviceLocationNumber: str
    networkId: str
    placeOfService: str
    zipCode: str
    isOutofNetwork: bool
