import pytest
from app.schemas.benefit_request import BenefitRequest, ServiceInfo, ServiceCodeInfo, ProviderType, PlaceOfService, ProviderSpecialty

def test_benefit_request():
    request = BenefitRequest(
        benefitProductType="medical",
        membershipID="5~265642286+34+44+20250101+784461+AM+39",
        planIdentifier="Plan123",
        serviceInfo=[
            ServiceInfo(
                serviceCodeInfo=ServiceCodeInfo(
                    code="99214",
                    type="CPT4",
                    providerType=[ProviderType(code="PT1")],
                    placeOfService=[PlaceOfService(code="POS1")],
                    providerSpecialty=[ProviderSpecialty(code="PS1")]
                )
            )
        ]
    )

    assert request.benefitProductType == "medical"
    assert request.membershipID == "5~265642286+34+44+20250101+784461+AM+39"
    assert request.planIdentifier == "Plan123"
    assert len(request.serviceInfo) == 1
    assert request.serviceInfo[0].serviceCodeInfo.code == "99214"
    assert request.serviceInfo[0].serviceCodeInfo.type == "CPT4"
