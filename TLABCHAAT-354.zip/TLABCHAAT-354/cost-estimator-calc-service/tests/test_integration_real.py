"""
Real integration tests for the cost estimator service.
These tests can run against real external services when configured.
"""

import pytest
import os
import asyncio
from fastapi.testclient import TestClient
from app.main import app


@pytest.mark.integration
@pytest.mark.real_services
def test_real_api_integration():
    """Test the complete API integration with real services (if configured)."""
    # Skip if real services are not configured
    if not os.getenv("ENABLE_REAL_INTEGRATION_TESTS"):
        pytest.skip("Real integration tests not enabled. Set ENABLE_REAL_INTEGRATION_TESTS=1 to run.")
    
    client = TestClient(app)
    
    # Test data
    request_data = {
        "membershipId": "5~186103331+10+7+20240101+793854+8A+829",
        "zipCode": "85305",
        "benefitProductType": "Medical",
        "languageCode": "11",
        "service": {
            "code": "99214",
            "type": "CPT4",
            "description": "Adult Office visit Age 30-39",
            "supportingService": {"code": "470", "type": "DRG"},
            "modifier": {"modifierCode": "E1"},
            "diagnosisCode": "F33 40",
            "placeOfService": {"code": "11"}
        },
        "providerInfo": [
            {
                "serviceLocation": "000761071",
                "providerType": "HO",
                "specialty": {"code": "91017"},
                "taxIdentificationNumber": "0000431173518",
                "taxIdQualifier": "SN",
                "providerNetworks": {"networkID": "58921"},
                "providerIdentificationNumber": "0004000317",
                "nationalProviderIdentifier": {"nationalProviderId": "1386660504"},
                "providerNetworkParticipation": {"providerTier": "1"}
            }
        ]
    }

    # Make API request to real services
    response = client.post("/costestimator/v1/rate", json=request_data)
    
    # Verify response
    assert response.status_code == 200
    result = response.json()
    assert "message" in result
    assert "rate" in result
    
    # The rate field contains the service response
    rate_data = result["rate"]
    assert rate_data["status"] in ["success", "error"]  # Could be either depending on service availability


@pytest.mark.integration
@pytest.mark.real_services
@pytest.mark.asyncio
async def test_real_service_integration():
    """Test service integration with real external services."""
    # Skip if real services are not configured
    if not os.getenv("ENABLE_REAL_INTEGRATION_TESTS"):
        pytest.skip("Real integration tests not enabled. Set ENABLE_REAL_INTEGRATION_TESTS=1 to run.")
    
    from app.services.impl.cost_estimation_service_impl import CostEstimationServiceImpl
    from app.schemas.cost_estimator_request import CostEstimatorRequest

    # Create real request object
    request_data = {
        "membershipId": "5~186103331+10+7+20240101+793854+8A+829",
        "zipCode": "85305",
        "benefitProductType": "Medical",
        "languageCode": "11",
        "service": {
            "code": "99214",
            "type": "CPT4",
            "description": "Adult Office visit Age 30-39",
            "placeOfService": {"code": "11"}
        },
        "providerInfo": [
            {
                "serviceLocation": "000761071",
                "providerType": "HO",
                "specialty": {"code": "91017"},
                "taxIdentificationNumber": "0000431173518",
                "taxIdQualifier": "SN",
                "providerNetworks": {"networkID": "58921"},
                "providerIdentificationNumber": "0004000317",
                "nationalProviderIdentifier": {"nationalProviderId": "1386660504"},
                "providerNetworkParticipation": {"providerTier": "1"}
            }
        ]
    }

    request = CostEstimatorRequest(**request_data)

    # Test service with real external calls
    service = CostEstimationServiceImpl()
    result = await service.estimate_cost(request)

    # Verify result structure (actual values depend on external services)
    assert "status" in result
    assert result["status"] in ["success", "error"]


@pytest.mark.integration
@pytest.mark.real_services
def test_real_benefit_service():
    """Test real benefit service integration."""
    if not os.getenv("ENABLE_REAL_INTEGRATION_TESTS"):
        pytest.skip("Real integration tests not enabled. Set ENABLE_REAL_INTEGRATION_TESTS=1 to run.")
    
    from app.services.impl.benefit_service_impl import BenefitServiceImpl
    from app.schemas.benefit_request import BenefitRequest

    async def test_benefit_service():
        service = BenefitServiceImpl()
        
        # Create a real benefit request
        benefit_request = BenefitRequest(
            benefitProductType="Medical",
            membershipID="5~186103331+10+7+20240101+793854+8A+829",
            planIdentifier="3~",
            serviceInfo=[{
                "serviceCodeInfo": {
                    "code": "99214",
                    "type": "CPT4",
                    "providerType": [{"code": "HO"}],
                    "placeOfService": [{"code": "11"}],
                    "providerSpecialty": [{"code": "91017"}]
                }
            }]
        )

        try:
            result = await service.get_benefit(benefit_request)
            assert result is not None
        except Exception as e:
            # Service might be unavailable, which is acceptable for integration tests
            assert "error" in str(e).lower() or "unavailable" in str(e).lower()


@pytest.mark.integration
@pytest.mark.real_services
def test_real_accumulator_service():
    """Test real accumulator service integration."""
    if not os.getenv("ENABLE_REAL_INTEGRATION_TESTS"):
        pytest.skip("Real integration tests not enabled. Set ENABLE_REAL_INTEGRATION_TESTS=1 to run.")
    
    from app.services.impl.accumulator_service_impl import AccumulatorServiceImpl
    from app.schemas.cost_estimator_request import CostEstimatorRequest

    async def test_accumulator_service():
        service = AccumulatorServiceImpl()
        
        # Create a real request
        request_data = {
            "membershipId": "5~186103331+10+7+20240101+793854+8A+829",
            "zipCode": "85305",
            "benefitProductType": "Medical",
            "languageCode": "11",
            "service": {
                "code": "99214",
                "type": "CPT4",
                "description": "Adult Office visit Age 30-39",
                "placeOfService": {"code": "11"}
            },
            "providerInfo": [
                {
                    "serviceLocation": "000761071",
                    "providerType": "HO",
                    "specialty": {"code": "91017"},
                    "taxIdentificationNumber": "0000431173518",
                    "taxIdQualifier": "SN",
                    "providerNetworks": {"networkID": "58921"},
                    "providerIdentificationNumber": "0004000317",
                    "nationalProviderIdentifier": {"nationalProviderId": "1386660504"},
                    "providerNetworkParticipation": {"providerTier": "1"}
                }
            ]
        }

        request = CostEstimatorRequest(**request_data)

        try:
            result = await service.get_accumulator(request)
            assert result is not None
        except Exception as e:
            # Service might be unavailable, which is acceptable for integration tests
            assert "error" in str(e).lower() or "unavailable" in str(e).lower()

    asyncio.run(test_accumulator_service())


@pytest.mark.integration
@pytest.mark.real_services
def test_real_database_integration():
    """Test real database integration."""
    if not os.getenv("ENABLE_REAL_INTEGRATION_TESTS"):
        pytest.skip("Real integration tests not enabled. Set ENABLE_REAL_INTEGRATION_TESTS=1 to run.")
    
    from app.repository.impl.cost_estimator_repository_impl import CostEstimatorRepositoryImpl
    from app.models.rate_criteria import CostEstimatorRateCriteria

    async def test_database():
        repository = CostEstimatorRepositoryImpl()
        
        # Create real rate criteria
        rate_criteria = CostEstimatorRateCriteria(
            serviceCode="99214",
            providerIdentificationNumber="0004000317",
            placeOfService="11",
            serviceType="CPT4",
            networkId="58921",
            serviceLocationNumber="000761071",
            zipCode="85305",
            isOutofNetwork=False
        )

        try:
            result = await repository.get_rate(rate_criteria=rate_criteria)
            assert result is not None
            assert isinstance(result, (int, float))
        except Exception as e:
            # Database might be unavailable, which is acceptable for integration tests
            assert "error" in str(e).lower() or "unavailable" in str(e).lower()

    asyncio.run(test_database()) 