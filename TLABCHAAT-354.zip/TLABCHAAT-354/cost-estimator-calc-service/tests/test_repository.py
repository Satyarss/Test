"""
Tests for the repository functionality.
"""

import pytest
from unittest.mock import Mock, patch, AsyncMock


@pytest.mark.repository
def test_repository_interface_import():
    """Test that the repository interface can be imported."""
    from app.repository.cost_estimator_repository import (
        CostEstimatorRepositoryInterface,
    )

    assert CostEstimatorRepositoryInterface is not None


@pytest.mark.repository
def test_repository_implementation_import():
    """Test that the repository implementation can be imported."""
    from app.repository.impl.cost_estimator_repository_impl import (
        CostEstimatorRepositoryImpl,
    )

    assert CostEstimatorRepositoryImpl is not None


@pytest.mark.repository
def test_rate_criteria_import():
    """Test that the rate criteria model can be imported."""
    from app.models.rate_criteria import CostEstimatorRateCriteria

    assert CostEstimatorRateCriteria is not None


@pytest.mark.repository
def test_rate_criteria_creation(rate_criteria):
    """Test that rate criteria can be created with valid data."""
    assert rate_criteria.serviceCode == "99213"
    assert rate_criteria.providerIdentificationNumber == "1234567890"
    assert rate_criteria.placeOfService == "11"
    assert rate_criteria.serviceType == "1"
    assert rate_criteria.networkId == "NET001"
    assert rate_criteria.serviceLocationNumber == "LOC001"
    assert rate_criteria.zipCode == "85305"


@pytest.mark.repository
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
def test_repository_initialization(mock_config, rate_criteria):
    """Test repository initialization with mocked config."""
    mock_config.is_valid.return_value = True
    mock_config.project_id = "test-project"
    mock_config.instance_id = "test-instance"
    mock_config.database_id = "test-database"

    from app.repository.impl.cost_estimator_repository_impl import (
        CostEstimatorRepositoryImpl,
    )

    with patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient"):
        repository = CostEstimatorRepositoryImpl()
        assert repository is not None


@pytest.mark.repository
def test_build_rate_params(rate_criteria):
    """Test the _build_rate_params method."""
    from app.repository.impl.cost_estimator_repository_impl import (
        CostEstimatorRepositoryImpl,
    )

    with patch(
        "app.repository.impl.cost_estimator_repository_impl.spanner_config"
    ) as mock_config:
        mock_config.is_valid.return_value = True
        mock_config.project_id = "test-project"
        mock_config.instance_id = "test-instance"
        mock_config.database_id = "test-database"

        with patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient"):
            repository = CostEstimatorRepositoryImpl()
            params = repository._build_rate_params(rate_criteria)

            assert params["servicecd"] == "99213"
            assert params["provideridentificationnumber"] == "1234567890"
            assert params["placeofservice"] == "11"
            assert params["servicetype"] == "1"
            assert params["networkid"] == "NET001"
            assert params["servicelocationnumber"] == "LOC001"


@pytest.mark.repository
def test_extract_single_value():
    """Test the _extract_single_value method."""
    from app.repository.impl.cost_estimator_repository_impl import (
        CostEstimatorRepositoryImpl,
    )

    with patch(
        "app.repository.impl.cost_estimator_repository_impl.spanner_config"
    ) as mock_config:
        mock_config.is_valid.return_value = True
        mock_config.project_id = "test-project"
        mock_config.instance_id = "test-instance"
        mock_config.database_id = "test-database"

        with patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient"):
            repository = CostEstimatorRepositoryImpl()

            # Test with numeric result
            result = [[150.75]]
            value = repository._extract_single_value(result) or 0.0
            assert float(value) == 150.75
            assert isinstance(float(value), float)

            # Test with empty result
            empty_result = []
            value = repository._extract_single_value(empty_result)
            if isinstance(value, str) and not value.replace('.', '', 1).isdigit():
                value = 0.0
            elif value is None:
                value = 0.0
            assert value == 0.0

            # Test with None result
            none_result = [[None]]
            value = repository._extract_single_value(none_result)
            if isinstance(value, str) and not value.replace('.', '', 1).isdigit():
                value = 0.0
            elif value is None:
                value = 0.0 
            assert value == 0.0
