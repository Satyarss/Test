from app.core.base import Handler, InsuranceContext


class DeductibleHandler(Handler):
    """Calculates member costs based on accumulated deductible"""

    def set_deductible_oopmax_handler(self, handler):
        self._deductible_oopmax_handler = handler
        return handler

    def set_cost_share_co_pay_handler(self, handler):
        self._cost_share_co_pay_handler = handler
        return handler

    def set_deductible_cost_share_co_pay_handler(self, handler):
        self._deductible_cost_share_co_pay_handler = handler
        return handler

    def process(self, context):
        # If we do not have an accumulated deductible, go to cost share
        # This is path "C"
        if (
            context.deductible_individual_calculated is None
            and context.deductible_family_calculated is None
        ):
            context.trace_decision(
                "Process",
                "The individual and family deductible are not provided",
                False,
            )
            return self._cost_share_co_pay_handler(context)

        if context.deductible_family_calculated == 0:
            context.trace_decision("Process", "The family deductible is zero", True)
            return self._deductible_cost_share_co_pay_handler(context)

        if context.deductible_individual_calculated == 0:
            context.trace_decision("Process", "The individual deductible is zero", True)
            return self._deductible_cost_share_co_pay_handler(context)

        if not context.is_deductible_before_copay:
            context.trace_decision("Process", "The deductible is before co-pay", False)
            # TODO: Jyoti Says Apply costShareCopay before deductible. Not sure what this means
            return context

        if not context.deductible_applies_oop:
            context.trace_decision(
                "Process", "The deductible does not apply to OOP", False
            )
            return self._apply_member_pays_service_or_individual_deductible_not_applied_to_oopmax(
                context
            )
        else:
            context.trace_decision("Process", "The deductible applies to OOP", True)
            return self._apply_member_pays_service_or_individual_deductible_is_applied_to_oopmax(
                context
            )

    def _apply_member_pays_service_or_individual_deductible_not_applied_to_oopmax(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays lesser of the service or Individual Deductible and it will not count towards OOPMax"""

        context.member_pays = (
            context.deductible_individual_calculated
            if context.deductible_individual_calculated < context.service_amount
            else context.service_amount
        )
        context.insurance_pays = context.service_amount - context.member_pays

        # If the individual deductible is the less, then we need to updated deductible as met
        if context.deductible_individual_calculated < context.service_amount:
            context.deductible_individual_calculated = 0

        context.calculation_complete = True

        context.trace(
            "_apply_member_pays_service_or_individual_deductible_not_applied_to_oopmax",
            "Logic applied",
        )

        return context

    def _apply_member_pays_service_or_individual_deductible_is_applied_to_oopmax(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays lesser of the service or individual deductible and it will get counted towards individual and family OOPMax"""

        context.member_pays = (
            context.deductible_individual_calculated
            if context.deductible_individual_calculated < context.service_amount
            else context.service_amount
        )
        context.insurance_pays = context.service_amount - context.member_pays
        context.oopmax_individual_calculated -= context.member_pays
        context.oopmax_family_calculated -= context.member_pays
        context.deductible_individual_calculated -= context.member_pays
        context.deductible_family_calculated -= context.member_pays

        context.trace(
            "_apply_member_pays_service_or_individual_deductible_is_applied_to_oopmax",
            "Logic applied",
        )

        return context
