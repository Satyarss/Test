from fastapi import FastAPI, Request
from fastapi.exception_handlers import request_validation_exception_handler
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from typing import Any

from app.core.exception_responses import responses


async def validation_exception_handler(request: Request, exc: Any) -> JSONResponse:

    # Check if ALL errors are missing field errors
    missing_fields = []
    has_non_missing_errors = False

    # exc is RequestValidationError but will fail linting if declared as such
    for error in exc.errors():
        if error["type"] == "missing":
            field_name = ".".join(
                str(loc) for loc in error["loc"][1:]
            )  # Skip 'body' from location
            if not field_name:
                field_name = "root"
            if field_name not in missing_fields:
                missing_fields.append(field_name)
        else:
            has_non_missing_errors = True
            break

    default_validation_error_response = await request_validation_exception_handler(
        request, exc
    )
    # If only missing field errors, return custom response
    if missing_fields and not has_non_missing_errors:
        response_content = responses[400].copy()
        response_content["errors"] = {"Missing fields": missing_fields}
        return JSONResponse(content=response_content, status_code=400)
    else:
        return default_validation_error_response


def include_exceptions(app: FastAPI):
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
    return app
