from dataclasses import dataclass
import os


@dataclass
class SpannerConfig:
    project_id: str = os.getenv("SPANNER_PROJECT_ID", "anbc-hcb-dev")
    env_name: str = os.getenv("ENV_NAME", "DEV")
    instance_id: str = os.getenv("SPANNER_INSTANCE_ID", "provider-de")
    database_id: str = os.getenv("SPANNER_DATABASE_ID", "cost-estimator-secure")

    def is_valid(self) -> bool:
        """Check if all required configuration values are present."""
        return bool(self.project_id and self.instance_id and self.database_id)


# Create default config instance
spanner_config = SpannerConfig()
