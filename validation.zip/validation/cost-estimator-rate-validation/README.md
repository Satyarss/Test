# Rate validation
This program is used for validating the rates for the Cost Estimator service by comparing its rates to the allowed amount extracted from claims data. There are three modules: (1) `validation`, (2) `analysis` and (3) `metrics`. Each module can run individually, or some combination of them can run consecutively.

## Prerequisites
- Install the [gcloud CLI](https://cloud.google.com/sdk/docs/install) and configure for your personal GCP account
- Install `requirements.txt`
- [OPTIONAL] If using CSV input data, obtain a CSV of claims information and move to the folder `test_cases/working`

## Run Instructions
1. Update `config/config.json` as required (see details below)
1. Run the following command to authenticate with GCP: `gcloud auth application-default login`
1. Run `python py/main.py`

## Config Settings
### `validation`
|Key   |Value  |Description|
| -------- | ------- | ------- |
|run   |`true` or `false`  | Determines if `validation` module is executed. |
|input_source   |"bq" or "csv"  | Only used if "run" = `true`. Determines source of input data. If bq, will use "input_bq_row_num_range" parameter for data in "validation_input_table". If csv, will use "input_csv_file" and go through "csv_input_parameters".
|input_csv_file   | Filename of the validation input file, ending in .csv  | Only used if "run" = `true` and "input_source" = "csv". File is assumed to be located in the `test_cases/working` folder.
|csv_input_parameters.run_zero_indexed_row | `int` value or `false`   | Only used if "run" = `true` and "input_source" = "csv". If an `int` value is given, only the specified row from the claims input CSV will be used. If set to `false`, all rows from the input CSV are used.
|csv_input_parameters.run_rows_from_top | `int` value or `false`   | Only used if "run" = `true` and "input_source" = "csv". If an `int` value is given, only the first specified number of rows from the claims input CSV will be used. If set to `false`, all rows from the input CSV are used.
|csv_input_parameters.skip_rows | `int` value or `false`   | Only used if "run" = `true` and "input_source" = "csv". If an `int` value is given,  the specified number of rows from the top of the claims input CSV will be skipped. If set to `false`, all rows from the input CSV are used.   |
input_bq_row_num_range | list of two `int`s  | Only used if "run" = `true` and "input_source" = "bq". Range of rows (first row inclusive, last row exclusive) that will be extracted from "validation_input_table" to be used as input.

### `analysis`
|Key   |Value  |Description|
| -------- | ------- | ------- |
|run_missing_rates   |`true` or `false`  |Determines if `analysis` module is executed for missing rates. |
|run_rates_outside_min_pct   |`true` or `false`  |Determines if `analysis` module is executed for  rates outside the minumum threshold set in "flag_rates_outside_pct". |
|input_source   |"bq" or "csv"  | Only used if "run_missing_rates" = `true` or "run_rates_outside_min_pct" = `true`. Determines source of input data. If bq, will use "input_bq_dt_str" parameter for data in "validation_output_table". If csv, will use "input_csv_file".
|input_csv_file   | Filename of the analysis input file, ending in .csv  | Only used if ("run_missing_rates" = `true` or "run_rates_outside_min_pct" = `true`) and "input_source" = "csv". File is assumed to be located in the corresponding `test_cases/output/<timestamp>` folder.
|input_bq_dt_str    |`str` representing a datetime in the format "%Y%m%d_%H%M%S"    | Only used if ("run_missing_rates" = `true` or "run_rates_outside_min_pct" = `true`) and "input_source" = "bq". Used for extracting rows for input from "validation_output_table" where `validation_run_dt` = input_bq_dt_st.

### `metrics`
|Key   |Value  |Description|
| -------- | ------- | ------- |
|`run`   |`true` or `false`  |Determines if `metrics` module is executed.
|input_source   |"bq" or "csv"  | Only used if "run" = `true`. Determines source of input data. If bq, will use "input_bq_dt_str" parameter for data in "analysis_output_table". If csv, will use "input_csv_file".
|input_csv_file   |Filename of the metrics file, ending in .csv  | Only used if "run" = `true` and "input_source" = "csv". File is assumed to be located in the corresponding `test_cases/output/<timestamp>` folder.
|input_bq_dt_str    |`str` representing a datetime in the format "%Y%m%d_%H%M%S"    |  Only used if "run" = `true` and "input_source" = "bq". Used for extracting rows for input from "analysis_output_table" (or from "validation_output_table" if data is present here and not in analysis table), where `validation_run_dt` = input_bq_dt_str.

### `validation_analysis_parameters`
|Key   |Value  |Description|
| -------- | ------- | ------- |
|processes  |   `int` value | Number of processes used when executing `validation` and `analysis` modules. |
|flag_rates_outside_pct | list of `int` values   | Indicates how distant retrieved rate may be from allowed amount before being flagged.
|to_csv | `int` value or `true` or `false`   | If set to an `int`, it is the frequency of writing to CSV output while iterating through rows. If set to `true`, it will write to csv after iterating through all rows. If set to `false`, it will not write to csv at all. 
|to_bq | `int` value or `true` or `false`   | If set to an `int`, it is the frequency of writing to a BigQuery table output while iterating through rows. If set to `true`, it will write to BigQuery after iterating through all rows. If set to `false`, it will not write to BigQuery at all. 
|log_time_every | `int` value or `false`   | Frequency of logging running time for last series of tests and overall run time.


### Additional settings
|Key   |Value  |Description|
| -------- | ------- | ------- |
|query_files    |Dict of SQL query files and metadata   | SQL query files used for reading data from BigQuery. Should not have to modify these values.   |
|data_locations |Dict of GCP project, dataset, and table names    | Data sources used in the SQL queries.   |
|sql_col_info   |SQL column names and metadata   |The names of the columns in the rate queries. Metadata includes the name of the parameter, its type (empty string if it varies), whether it is required or optional, and whether it should be an empty string or skipped entirely if the value is missing for a query. Should not have to modify these values. |
|input_to_sql_map |Input column names mapped to output column names used in SQL queries   |All  column names that may be expected in the input, each mapped to its corresponding column name for the SQL rate queries. If multiple columns mapping to the same SQL column name are found, an error will be raised. Additionally, if any input columns corresponding to the mandatory output columns are missing, an error will be raised. If there is a new input column that maps to a SQL column listed in "sql_col_info", it can be added to this map.

### Final notes regarding the config
- At least one module must be set to `true` (for `analysis`, setting at least one of "run_missing_rates" and "run_rates_outside_min_pct" to `true` counts as setting the module to `true`).
- Cannot have both of the output options, "to_csv" and "to_bq", set to `false`.
- Only one of "run_zero_indexed_test_row", "run_test_rows_from_top", and "skip_test_rows" can be set to an `int` value; the others must be set to `false`.

## Module Details
### `validation`
- **Input:** Either a CSV file of claims data or records from "validation_input_table" in BigQuery. Either source must at least contain columns that map to the required columns as seen in the "sql_col_info" dict in the config.
- **During execution:** This module will run some basic checks on the data input, check if the claim is contained in the Cost Estimator claims table, perform some preliminary queries to validate the POS code, PBGs, and TINs, and then execute a rate query.
- **Output:** Either a CSV file or rows appended to the "validation_output_table" (or both). The output data contains the same info as the input as well as prepended columns containing the retrieved rate and several additional columns providing more information on the claim and enabling more metric calculations.

### `analysis`
- **Input:** If the `validation` module is running and at least one submodule of the `analysis` module is running, the output from the `validation` module will be used directly as input for `analysis`. Else, the input for this module must be specified in the config as either a CSV file or as a selection from the "validation_output_table". If using a CSV input, it should be in the same directory and in the same format as the output from a previous run of the `validation` module (containing the same required columns as well as the columns added by the module). If using BigQuery input, the "input_bq_dt_str" will be used to filter the rows from the "validation_output_table". 
- **During execution:** This module will iterate through the test cases for which no rate was retrieved and/or for which the rate is outside the minumum threshold set in `flag_rates_outside_pct`. For each missing rate, it first checks whether or not there are any PBGs for the given test case (in the "returned_pbgs" column). If none, it proceeds to step 0, else step 1. Then it steps through a sequence of queries depending on whether or not any records were returned from the previous query until the end of the `analysis` logic (e.g., step 1.0.0 indicates PBGs are present, but no records were returned for the next two queries). For incorrect rates, it checks if the correct rate actually exists in the rates or claims data but the wrong one is retrieved when taking the max rate.
- **Output:** Either a CSV file or rows appended to the "analysis_output_table" (or both). The output data contains the same info as the output file for `validation`, a new "analysis" column populated with the analysis querying logic, and several additional columns providing more information on the claim and enabling more metric calculations.

### `metrics`
- **Input:** If the `analysis` module is running, its output will be used directly as input for `metrics`. If `validation` is running and `analysis` is not, its output will be used directly as input for `metrics`. If only `metrics` is running, the input for this module must be specified in the config as either a CSV file or as a selection from the "validation_output_table" or "analysis_output_table".  If using a CSV input, it should be in the same directory and in the same format as the output from a previous run of the `validation` module or the `analysis` module. Note that the input CSV must also have a column called "allowed_amt" for "`metrics`" to run.  If using BigQuery input, the "input_bq_dt_str" will be used to filter the rows from the "analysis_output_table". If no rows are found, it will use this input to extract rows from the "validation_output_table", and raise an error if no rows are found again.
- **During execution:** Various metrics will be calculated. No queries will be made to GCP except for the input/output (if specified).
- **Output:** A text file containing the calculated metrics.

## Logging
Logs can be found in the `test_cases/output/<timestamp>/logs` folder. Each run will generate logs that are appended to the `*_main.log`. If "`validation`" is executed, `*_validation.log` will also be written. If "`analysis`" is executed, `*_analysis.log` will also be written. Note that, since no new folder is created when running the `analysis` module, the existing `analysis` log in the given folder will be overwritten.

In order to find the queries made for a given test case for `validation` or `analysis`, the "validation_log_id" (or "analysis_log_id") can be used to locate the queries for a given test case. The output for each test case will start by indicating the [`validation`|`analysis`\]_log_id.


## Multiprocessing
By specifying an `int` value greater than 1 for "processes" in the config, multiprocessing will be used for the `validation` and `analysis` modules. Multiprocessing can significantly speed up execution time. However, if there are very few test cases to be executed (e.g., less than 10) or if the number of processes specified puts too much strain on your machine's CPU, it may have the opposite effect.

With multiprocessing, when outputting to csv, each individual process will write to its own process-level CSV during execution, but they will be combined (and the process-level CSVs removed) at the very end. Therefore, the output from a multiprocess run is identical to that of running a single process. Likewise, each individual process will write to its own process-level log, but the logs will be concatenated into one at the very end of the module's execution, clearly stating within the log where each process begins.


## TODO
- Maintain backward compatibility to read from / output to CSV for each module

-DONE

    - Put sample file into BQ (or ask Ryan to do it)
        - Read from sample file / `validation` input in BQ
    - Output `validation` file into BQ table
        - Read `validation` output table for `analysis`/`metrics`
    - Output `analysis` file into BQ table
        - Read `analysis` output from BQ for `metrics`
    - send data to BQ in configurable chunk sizes periodically (just for saving work, not for limiting size-- that it what the read chunk size limit is for)
    - Refactor
    - Update readme

- Merge `metrics` updates
- Go over changes with others
- Update rate queries without joins

- NOT DONE
    - Output `metrics` into BQ -- calculate them with SQL?
    - Output `validation`/`analysis` logs into BQ?
    - Output code change summary between runs somewhere

    Must do this once scale is large enough 10s of 1000s of test cases per run
    - Read from BQ table in chunks rather than pass around df locally
    - Calculate `metrics` on BQ table directly

    - Run code in cloud

    - change logic on timestamps/file/folder names (or don't waste time on this if moving away from csvs):
        - don't only use the timestamp from `validation` run
        - regardless of which module is run, generate a new file with the current timestamp in the filename
        - use that timestamp in the new timestamp column of `validation`/`analysis`
        - if running both v+a in one run, use the timestamp from v run for folder name but still use new timestamp for a filename and col
        - use letters v/a/m in folder name to indicate what has been run
    - use dt instead of dt str for BQ
    - remove all csv stuff?
    
    - Replace ""/0 with Nones everywhere? Probably better not to, and acknowledge that 0 is none, "" is none, and null is only for bool vals (since no third option for bools in python)