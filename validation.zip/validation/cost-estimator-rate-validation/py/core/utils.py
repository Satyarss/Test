import os
import re
import time
import logging
import pandas_gbq
import pandas as pd
from typing import Tuple
from google.cloud import bigquery as bq
from core.bq import insert_bq_output, query_metrics_input
from core.constants import (
    PY_DIR,
    QUERY_DIR,
    CFG,
    INPUT_SQL_MAP,
    SQL_COL_INFO,
    VA_PARAMS,
    VALIDATION,
    ANALYSIS,
    METRICS,
)


def get_dt_and_dir(start_time: float):
    if VALIDATION:
        datetime_str = time.strftime("%Y%m%d_%H%M%S", time.localtime(start_time))
    elif ANALYSIS:
        if CFG["analysis"]["input_source"] == "csv":
            match = re.search(r"^(\d{8})_(\d{6})", CFG["analysis"]["input_csv_file"])
        else:
            match = re.search(r"^(\d{8})_(\d{6})", CFG["analysis"]["input_bq_dt_str"])
        if match is None:
            raise ValueError(
                "No datetime pattern found at start of analysis input file"
            )
        datetime_str = match.group(0)
    elif METRICS:
        if CFG["metrics"]["input_source"] == "csv":
            match = re.search(r"^(\d{8})_(\d{6})", CFG["metrics"]["input_csv_file"])
        else:
            match = re.search(r"^(\d{8})_(\d{6})", CFG["metrics"]["input_bq_dt_str"])
        if match is None:
            raise ValueError("No datetime pattern found a start of metrics input file")
        datetime_str = match.group(0)
    else:
        raise ValueError("Select a run mode")

    output_dir = os.path.join(PY_DIR, "..", "test_cases", "output", datetime_str)
    if not os.path.exists(os.path.join(output_dir, "logs")):
        os.makedirs(os.path.join(output_dir, "logs"))

    return output_dir, datetime_str


def initialize_column_maps(test_data: pd.DataFrame):
    csv_to_sql_info_relevant = {}  # sql info for relevant input csv cols
    sql_to_csv_relevant = {}  # only relevant sql and csv col names
    for csv_col in test_data.columns:
        if csv_col in INPUT_SQL_MAP.keys():  # check relevance
            sql_col = INPUT_SQL_MAP[csv_col]
            if csv_col not in csv_to_sql_info_relevant.keys():  # ensure no dupes
                # map cols
                csv_to_sql_info_relevant[csv_col] = SQL_COL_INFO[sql_col]
                sql_to_csv_relevant[sql_col] = csv_col
            else:
                raise ValueError(
                    f"Duplicate possible CSV columns found for following SQL col: {sql_col}."
                )
    return csv_to_sql_info_relevant, sql_to_csv_relevant


def replace_data_loc_params(query_filepath: str) -> str:
    query_str = open(query_filepath, "r").read()
    data_loc_params = CFG["data_locations"]
    for param, value in data_loc_params.items():
        query_str = query_str.replace(f"@{param}", value)
    return query_str


def prep_rate_queries():
    query_str_map = {}
    # map each contract type to its query
    for query in CFG["query_files"]["rate_queries"]:
        query_filepath = os.path.join(QUERY_DIR, "rates_queries", query["query_file"])
        query_str = replace_data_loc_params(query_filepath)
        query_str_map[query["query_type"]] = query_str

    return query_str_map


def read_data_from_csv(mode: str) -> Tuple[pd.DataFrame, str]:
    # extract datetimestr which is 8 ints _ 6 ints at prefix of filename
    match = re.search(r"(\d{8})_(\d{6})", CFG[mode]["input_csv_file"])
    if match is None:
        raise ValueError(f"No datetime pattern found in {mode} input file")
    existing_datetime_str = match.group(0)
    test_data = pd.read_csv(
        os.path.join(
            PY_DIR,
            "..",
            "test_cases",
            "output",
            existing_datetime_str,
            CFG[mode]["input_csv_file"],
        )
    )
    return test_data, existing_datetime_str


def read_data_from_bq_metrics(logger: logging.Logger) -> pd.DataFrame:
    query_filepath_ma = os.path.join(
        QUERY_DIR,
        "input_queries",
        CFG["query_files"]["input_queries"]["metrics_analysis_input"],
    )
    query_str_ma = replace_data_loc_params(query_filepath_ma)
    query_filepath_mv = os.path.join(
        QUERY_DIR,
        "input_queries",
        CFG["query_files"]["input_queries"]["metrics_validation_input"],
    )
    query_str_mv = replace_data_loc_params(query_filepath_mv)
    query_result = query_metrics_input(query_str_ma, query_str_mv, logger)
    return query_result


def get_file_prefix(fname: str) -> str:
    fname = fname[:-4]
    if fname.endswith("_validation"):
        return fname[:-11]
    elif fname.endswith("_analysis"):
        return fname[:-9]
    else:
        return fname


def obtain_output_filename(mode: str, datetime_str: str) -> str:
    if VALIDATION:
        if CFG["validation"]["input_source"] == "csv":
            # use datetime_str from this run
            file_prefix = (
                f"{datetime_str}_{get_file_prefix(CFG['validation']['input_csv_file'])}"
            )
        else:
            file_prefix = f"{datetime_str}_bq"
    elif ANALYSIS:
        if CFG["analysis"]["input_source"] == "csv":
            # use datetime_str from analysis input file
            file_prefix = get_file_prefix(CFG["analysis"]["input_csv_file"])
        else:
            file_prefix = f"{datetime_str}_bq"
    else:  # metrics only
        if CFG["metrics"]["input_source"] == "csv":
            file_prefix = get_file_prefix(CFG["metrics"]["input_csv_file"])
        else:
            file_prefix = f"{datetime_str}_bq"

    if mode == "analysis":
        output_filename = file_prefix + "_analysis.csv"
    elif mode == "metrics":
        output_filename = file_prefix + "_metrics.txt"
    else:
        raise ValueError(f"Invalid mode: {mode}")

    return output_filename


def get_run_id(mode: str, table_id: str, logger_m: logging.Logger) -> int:
    last_run_id = pandas_gbq.read_gbq(
        f"SELECT MAX({mode}_run_id) FROM {table_id}",
        project_id=CFG["data_locations"]["project"],
    )

    # Handle case where table is empty (last_run_id will be None)
    if last_run_id is None or last_run_id.empty or pd.isna(last_run_id.iloc[0, 0]):
        run_id = 1
        logger_m.warning("No run id found, setting run_id to 1")
    else:
        run_id = int(last_run_id.iloc[0, 0]) + 1
        logger_m.warning(f"Using {mode}_run_id {run_id}")

    return run_id


def add_output_col(
    pos: int, test_data: pd.DataFrame, col_name: str, col_value, col_type: str | None
):
    test_data.insert(pos, col_name, col_value)
    if col_type is not None:
        test_data[col_name] = test_data[col_name].astype(col_type)
    return test_data


def cast_dtypes(test_data: pd.DataFrame, logger_m: logging.Logger):
    # Cast dtypes to ensure consistency between CSV and BigQuery sources
    dtype_casting_map = {
        "allowed_amt": "float64",
        "unit_cnt": "int64",
        "src_specialty_cd": "int64",
        "provider_identification_nbr": "int64",
        "srv_location_nbr": "int64",
        "network_id": "int64",
        "hcfa_plc_srv_cd": "int64",
        "srv_prvdr_zip_cd": "int64",
        "tax_id_qlfr_nbr": "int64",
        "claim_line_id": "int64",
        "revenue_cd": "float64",
        "type_srv_cd": "int64",
        "paid_prvdr_id": "int64",
        "paid_prvdr_nsa_id": "int64",
        "srv_prvdr_npi_nbr": "int64",
        "tax_id_qlfr_nbr_1": "int64",
        "pri_clm_ln_msg_cd": "float64",
        "pricing_mthd_cd": "float64",
        "rmbrsmnt_type_cd": "int64",
        "prv_ctrct_lnitm_id": "int64",
        "prv_ctrct_qlfr_id": "int64",
        "billed_amt": "float64",
        "negot_savings_amt": "float64",
        "precert_pnlty_amt": "float64",
        "prvdr_rmbrsmnt_amt": "float64",
        "r_c_amt": "int64",
        "src_fee_schdl_amt": "float64",
        "withhold_amt": "int64",
        "file_id": "int64",
        "drg_cd": "float64",
        "row_num": "int64",
    }

    for col, dtype in dtype_casting_map.items():
        if col in test_data.columns:
            try:
                if dtype == "int64" or dtype == "float64":
                    test_data[col] = pd.to_numeric(test_data[col], errors="coerce")
                    test_data[col] = test_data[col].astype(dtype)
                else:
                    test_data[col] = test_data[col].astype(dtype)
            except Exception as e:
                logger_m.warning(f"Failed to cast column {col} to {dtype}: {e}")
    return test_data


def get_bq_param(
    sql_to_csv_relevant, row: pd.Series, csv_col: str
) -> bq.ScalarQueryParameter | bq.ArrayQueryParameter:
    if csv_col == "retrieved_pbgs":
        pbg_nbr_vals = str(row[csv_col])
        pbg_nbr_vals = [int(x) for x in pbg_nbr_vals[1:-1].split(",")]
        return bq.ArrayQueryParameter(
            "pbg_nbrs",
            "INT64",
            pbg_nbr_vals,
        )
    else:
        param_type = SQL_COL_INFO[csv_col][1]
        if param_type == "INT64":
            val = int(row[sql_to_csv_relevant[csv_col]])
        elif param_type == "STRING":
            val = str(row[sql_to_csv_relevant[csv_col]])
        else:  # == ""
            val = int(row[sql_to_csv_relevant[csv_col]])
            param_type = "INT64"
        return bq.ScalarQueryParameter(
            SQL_COL_INFO[csv_col][0],
            param_type,
            val,
        )


def checkpoint_conditions(int_or_bool: int | bool, i: int) -> bool:
    return (
        int_or_bool is not False
        and int_or_bool is not True
        and i != 0
        and (i + 1) % int_or_bool == 0
    )


def checkpoint_conditions_last(int_or_bool: int | bool, len_data: int) -> bool:
    return (
        int_or_bool is not False
        and int_or_bool is not True
        and len_data % int_or_bool > 0
    )


def save_to_csv(
    test_data_slice: pd.DataFrame,
    output_filepath: str,
    logger: logging.Logger,
    i: int,
    last: bool = False,
):
    test_data_slice.to_csv(output_filepath, mode="a", index=False, header=False)
    if not last:
        logger.info(f"Saved test indices {i+1-VA_PARAMS['to_csv']} to {i} inclusive")
    else:
        logger.info(f"Saved test indices from {i} to end")


def write_slice_to_bq(
    test_data_slice: pd.DataFrame,
    table_id: str,
    logger: logging.Logger,
    i: int,
    last: bool = False,
):
    insert_bq_output(test_data_slice, table_id)
    if not last:
        logger.info(f"Inserted test indices {i+1-VA_PARAMS['to_bq']} to {i} inclusive")
    else:
        logger.info(f"Inserted test indices from {i} to end")


def write_all_to_bq(
    test_data: pd.DataFrame,
    table_id: str,
    logger_m: logging.Logger,
    remaining: bool = False,
):
    if remaining:
        insert_bq_output(test_data, table_id)
        logger_m.warning(f"Remaining results written to BigQuery table: {table_id}")
    else:
        insert_bq_output(test_data, table_id)
        logger_m.warning(f"Results written to BigQuery table: {table_id}")
