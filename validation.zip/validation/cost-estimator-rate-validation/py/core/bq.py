import re
import pandas_gbq
import logging
from typing import Dict
import pandas as pd
from google.cloud import bigquery as bq
from core.log_helpers import log_query
from core.constants import CFG, SQL_COL_INFO


def run_rate_query(
    row: pd.Series,
    query_type: str,
    query_str_map: Dict[str, str],
    sql_to_csv_relevant: Dict[str, str],
    logger: logging.Logger,
    client: bq.Client,
) -> pd.DataFrame:
    query_str = query_str_map[query_type]
    # obtain col param values from csv
    query_parameters = []
    for sql_col, sql_info in SQL_COL_INFO.items():
        handle_missing = False
        # if given col is in csv and is not null, add it to query param list
        if sql_col not in sql_to_csv_relevant.keys():
            handle_missing = True
        else:
            csv_col = sql_to_csv_relevant[sql_col]
            if row[csv_col] is None or row[csv_col] == "" or row[csv_col] is pd.NA:
                handle_missing = True
            else:  # note that if param is not used in the query, BQ will simply ignore the param added here
                param_type = sql_info[1]
                if param_type == "INT64":
                    param_val = int(row[csv_col])
                elif param_type == "STRING":
                    param_val = str(row[csv_col])
                else:  # varying type for PROVIDER_IDENTIFICATION_NBR
                    if query_type == "claims":
                        param_type = "STRING"
                        param_val = str(row[csv_col])
                    else:
                        param_type = "INT64"
                        param_val = int(row[csv_col])
                query_parameters.append(
                    bq.ScalarQueryParameter(sql_info[0], param_type, param_val)
                )
        if handle_missing:
            if sql_info[3] == "SKIP":
                # remove line in query that uses this parameter
                query_str = re.sub(rf"\n.*@{sql_info[0]}.*\n", "\n", query_str)
            else:  # sql_info[3] == "EMPTY"
                # add param with empty string value
                query_parameters.append(
                    bq.ScalarQueryParameter(sql_info[0], sql_info[1], "")
                )

    logger.info("RUNNING RATE QUERY")
    log_query(query_str, query_parameters, logger)
    query_job_config = bq.QueryJobConfig(query_parameters=query_parameters)
    query_result = client.query(query_str, query_job_config).to_dataframe()
    return query_result


def query_metrics_input(
    query_str_ma, query_str_mv, logger: logging.Logger
) -> pd.DataFrame:
    client = bq.Client()
    query_parameters = [
        bq.ScalarQueryParameter(
            "metrics_input_dt_str", "STRING", CFG["metrics"]["input_bq_dt_str"]
        ),
    ]
    log_query(query_str_ma, query_parameters, logger)
    query_job_config = bq.QueryJobConfig(query_parameters=query_parameters)
    query_result = client.query(query_str_ma, query_job_config).to_dataframe()
    if len(query_result) == 0:
        query_result = query_metrics_validation_input(query_str_mv, logger)
    return query_result


def query_metrics_validation_input(query_str_mv, logger: logging.Logger):
    client = bq.Client()
    query_parameters = [
        bq.ScalarQueryParameter(
            "metrics_input_dt_str", "STRING", CFG["metrics"]["input_bq_dt_str"]
        ),
    ]
    log_query(query_str_mv, query_parameters, logger)
    query_job_config = bq.QueryJobConfig(query_parameters=query_parameters)
    query_result = client.query(query_str_mv, query_job_config).to_dataframe()
    if len(query_result) == 0:
        raise ValueError(
            f"No metrics data found for metrics input dt str {CFG['metrics']['input_bq_dt_str']}"
        )
    return query_result


def insert_bq_output(
    test_data: pd.DataFrame,
    table_id: str,
):
    pandas_gbq.to_gbq(
        test_data,
        table_id,
        project_id=CFG["data_locations"]["project"],
        if_exists="append",
    )
