import os
import json
from typing import Dict, Any, Tuple

PY_DIR = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
QUERY_DIR = os.path.join(PY_DIR, "..", "queries")

CFG: Dict[str, Any] = json.load(
    open(os.path.join(PY_DIR, "..", "config", "config.json"), "r")
)
VALIDATION: bool = CFG["validation"]["run"]
ANALYSIS: bool = (
    CFG["analysis"]["run_missing_rates"] or CFG["analysis"]["run_rates_outside_min_pct"]
)
METRICS: bool = CFG["metrics"]["run"]

VA_PARAMS: Dict[str, Any] = CFG["validation_analysis_parameters"]

INPUT_SQL_MAP: Dict[str, str] = CFG["input_to_sql_map"]  # all possible input col names
SQL_COL_INFO: Dict[str, Tuple[str, str, str, str]] = CFG[
    "sql_col_info"
]  # sql info for all possible sql cols
