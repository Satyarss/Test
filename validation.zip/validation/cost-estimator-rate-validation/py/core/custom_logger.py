import glob, os
import logging
from core.constants import PY_DIR, CFG, VALIDATION, ANALYSIS, METRICS
from core.utils import get_file_prefix


class CustomLogger(logging.Logger):
    def __init__(self, log_mode, datetime_str, process: int):
        super().__init__(log_mode)
        self.log_mode = log_mode
        self.logging_dir = os.path.join(
            PY_DIR,
            "..",
            "test_cases",
            "output",
            datetime_str,
            "logs",
        )
        self.logging_filepath = os.path.join(
            self.logging_dir,
            self.get_filename(datetime_str, process),
        )
        self.setLevel(logging.INFO)
        self.add_console_handler()
        self.add_file_handler()

    def get_filename(self, datetime_str: str, process: int) -> str:
        if CFG["validation"]["input_source"] == "csv":
            input_file_prefix = (
                f"{datetime_str}_{get_file_prefix(CFG['validation']['input_csv_file'])}"
            )
        else:
            input_file_prefix = f"{datetime_str}_bq"

        if self.log_mode == "main":
            if VALIDATION:
                log_file_prefix = input_file_prefix
            elif ANALYSIS:
                if CFG["analysis"]["input_source"] == "csv":
                    log_file_prefix = get_file_prefix(CFG["analysis"]["input_csv_file"])
                else:
                    log_file_prefix = f"{datetime_str}_bq"
            elif METRICS:
                if CFG["metrics"]["input_source"] == "csv":
                    log_file_prefix = get_file_prefix(CFG["metrics"]["input_csv_file"])
                else:
                    log_file_prefix = f"{datetime_str}_bq"
            return f"{log_file_prefix}_main.log"

        elif self.log_mode == "validation":
            return f"{input_file_prefix}_validation_{process:0>2}.log"

        elif self.log_mode == "analysis":
            if VALIDATION:
                return f"{input_file_prefix}_analysis_{process:0>2}.log"
            else:
                if CFG["analysis"]["input_source"] == "csv":
                    return f"{get_file_prefix(CFG['analysis']['input_csv_file'])}_analysis_{process:0>2}.log"
                else:
                    return f"{datetime_str}_bq_analysis_{process:0>2}.log"

        else:
            raise ValueError(f"Invalid log mode: {self.log_mode}")

    def add_console_handler(self):
        console_formatter = logging.Formatter(
            "%(asctime)s %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
        )
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.WARNING)
        console_handler.setFormatter(console_formatter)
        self.addHandler(console_handler)

    def add_file_handler(self):
        file_formatter = logging.Formatter(
            "%(asctime)s.%(msecs)03d %(levelname)s %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        file_mode = "a" if self.log_mode == "main" else "w"
        file_handler = logging.FileHandler(self.logging_filepath, mode=file_mode)
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(file_formatter)
        self.addHandler(file_handler)

    @staticmethod
    def concat_logs(log_type, datetime_str):
        """Concatenates all test log files into one combined log file with process headers, then deletes sub logs"""
        log_dir = os.path.join(
            PY_DIR, "..", "test_cases", "output", datetime_str, "logs"
        )

        # Get all mp log files
        mp_logs = []
        for f in glob.glob(os.path.join(log_dir, f"*_{log_type}_*.log")):
            mp_logs.append(f)

        # Sort logs by process number
        mp_logs.sort()

        # Create combined log file
        if not VALIDATION and ANALYSIS:
            if CFG["analysis"]["input_source"] == "csv":
                file_basename = get_file_prefix(CFG["analysis"]["input_csv_file"])
            else:
                file_basename = f"{datetime_str}_bq"
        else:
            if CFG["validation"]["input_source"] == "csv":
                file_basename = f"{datetime_str}_{get_file_prefix(CFG['validation']['input_csv_file'])}"
            else:
                file_basename = f"{datetime_str}_bq"
        combined_log_path = os.path.join(log_dir, f"{file_basename}_{log_type}.log")
        with open(combined_log_path, "w") as outfile:
            for log_file in mp_logs:
                # Write header for this sublog
                outfile.write("\n\n")
                outfile.write("=" * 80 + "\n")
                outfile.write(
                    f"Begin logs for process {os.path.basename(log_file).split('_')[-1][:-4]}\n"
                )
                outfile.write("=" * 80 + "\n\n\n")

                # Copy contents of sublog
                with open(log_file, "r") as infile:
                    outfile.write(infile.read())

        # Delete the sublogs after copying
        for log_file in mp_logs:
            os.remove(log_file)

    @staticmethod
    def close_all_handlers(logger: logging.Logger):
        # close all file handlers
        for handler in logger.handlers:
            if isinstance(handler, logging.FileHandler):
                handler.close()
                logger.removeHandler(handler)
