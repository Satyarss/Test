import re
import logging
from typing import Sequence
from google.cloud import bigquery as bq
from core.constants import CFG, VALIDATION, ANALYSIS, METRICS, VA_PARAMS


def log_execution_plan(datetime_str, logger: logging.Logger):
    plan_mesg = "\nEXECUTION PLAN\n" + "*" * 80 + "\n"

    # modules
    plan_mesg += "MODULES:\n"
    if VALIDATION:
        plan_mesg += "- Validation\n"
    if ANALYSIS:
        plan_mesg += "- Analysis for\n"
        if CFG["analysis"]["run_missing_rates"]:
            plan_mesg += "\t- Missing rates\n"
        if CFG["analysis"]["run_rates_outside_min_pct"]:
            plan_mesg += "\t- Rates outside min pct\n"
    if METRICS:
        plan_mesg += "- Metrics\n"

    # input
    project_dataset = (
        CFG["data_locations"]["project"] + "." + CFG["data_locations"]["ds_dataset"]
    )
    if VALIDATION:
        if CFG["validation"]["input_source"] == "csv":
            input_source = "CSV"
            input_data = CFG["validation"]["input_csv_file"]
            if CFG["validation"]["csv_input_parameters"]["run_zero_indexed_row"]:
                input_data += (
                    " zero-indexed row "
                    + str(
                        CFG["validation"]["csv_input_parameters"][
                            "run_zero_indexed_row"
                        ]
                    )
                    + " only"
                )
            elif CFG["validation"]["csv_input_parameters"]["run_rows_from_top"]:
                input_data += (
                    " top "
                    + str(
                        CFG["validation"]["csv_input_parameters"]["run_rows_from_top"]
                    )
                    + " rows only"
                )
            elif CFG["validation"]["csv_input_parameters"]["skip_rows"]:
                input_data += (
                    " skipping the first "
                    + str(CFG["validation"]["csv_input_parameters"]["skip_rows"])
                    + " rows"
                )
        else:
            input_source = "BigQuery"
            input_data = (
                project_dataset
                + "."
                + CFG["data_locations"]["validation_input_table"]
                + " in row range "
                + str(CFG["validation"]["input_bq_row_num_range"])
            )
    elif ANALYSIS:
        if CFG["analysis"]["input_source"] == "csv":
            input_source = "CSV"
            input_data = CFG["analysis"]["input_csv_file"]
        else:
            input_source = "BigQuery"
            input_data = (
                project_dataset
                + "."
                + CFG["data_locations"]["validation_output_table"]
                + ' WHERE validation_run_dt = "'
                + CFG["analysis"]["input_bq_dt_str"]
                + '"'
            )
    elif METRICS:
        if CFG["metrics"]["input_source"] == "csv":
            input_source = "CSV"
            input_data = CFG["metrics"]["input_csv_file"]
        else:
            input_source = "BigQuery"
            input_data = (
                "Either "
                + project_dataset
                + "."
                + CFG["data_locations"]["analysis_output_table"]
                + " or "
                + project_dataset
                + "."
                + CFG["data_locations"]["validation_output_table"]
                + " with validation_run_dt "
                + CFG["metrics"]["input_bq_dt_str"]
            )

    plan_mesg += f"INPUT SOURCE: {input_source}\n"
    plan_mesg += f"INPUT DATA: {input_data}\n"

    # params
    if VALIDATION or ANALYSIS:
        va_params = (
            "- Number of processes: "
            + str(CFG["validation_analysis_parameters"]["processes"])
            + "\n"
        )
        if VA_PARAMS["flag_rates_outside_pct"]:
            va_params += (
                "- Flagging rates outside the following percentiles from allowed amount: "
                + str(CFG["validation_analysis_parameters"]["flag_rates_outside_pct"])
                + "\n"
            )
        if VA_PARAMS["to_csv"]:
            if CFG["validation_analysis_parameters"]["to_csv"] is True:
                va_params += "- Saving to CSV at the end\n"
            elif CFG["validation_analysis_parameters"]["to_csv"] is not False:
                va_params += (
                    "- Saving to CSV every "
                    + str(CFG["validation_analysis_parameters"]["to_csv"])
                    + " rows\n"
                )
        if VA_PARAMS["to_bq"]:
            if CFG["validation_analysis_parameters"]["to_bq"] is True:
                va_params += "- Saving to BigQuery at the end\n"
            elif CFG["validation_analysis_parameters"]["to_bq"] is not False:
                va_params += (
                    "- Saving to BigQuery every "
                    + str(CFG["validation_analysis_parameters"]["to_bq"])
                    + " rows\n"
                )
        if VA_PARAMS["log_time_every"]:
            va_params += (
                "- Logging time every "
                + str(CFG["validation_analysis_parameters"]["log_time_every"])
                + " rows\n"
            )
        plan_mesg += f"VALIDATION/ANALYSIS PARAMETERS:\n{va_params}"

    # output
    output_elements = ""
    if VALIDATION:
        if VA_PARAMS["to_csv"]:
            output_elements += "- Validation CSV\n"
        if VA_PARAMS["to_bq"]:
            output_elements += (
                "- Validation output table "
                + project_dataset
                + "."
                + CFG["data_locations"]["validation_output_table"]
                + "\n"
            )
    if ANALYSIS:
        if VA_PARAMS["to_csv"]:
            output_elements += "- Analysis CSV\n"
        if VA_PARAMS["to_bq"]:
            output_elements += (
                "- Analysis output table "
                + project_dataset
                + "."
                + CFG["data_locations"]["analysis_output_table"]
                + "\n"
            )
    if METRICS:
        output_elements += "- Metrics text file\n"

    plan_mesg += f"OUTPUT:\n{output_elements}"
    plan_mesg += (
        "All output files and logs can be found in the output folder test_cases/output/"
        + datetime_str
        + "\n"
    )
    plan_mesg += "*" * 80

    logger.warning(plan_mesg)


def log_query(
    query_str,
    query_parameters: Sequence[bq.ScalarQueryParameter | bq.ArrayQueryParameter],
    logger: logging.Logger,
):
    # remove comments surrounded by /* */ from query for better readability
    query_cleaned = re.sub(r"/\*[\s\S]*?\*/\n", "", query_str)
    for param in query_parameters:
        if isinstance(param, bq.ScalarQueryParameter):
            if param.type_ == "STRING":
                query_cleaned = query_cleaned.replace(
                    f"@{param.name}", f"'{param.value}'"
                )
            else:  # int
                query_cleaned = query_cleaned.replace(
                    f"@{param.name}", str(param.value)
                )
        else:  # array
            query_cleaned = query_cleaned.replace(f"@{param.name}", str(param.values))
    logger.info(f"\n{query_cleaned}")
