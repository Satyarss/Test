import os
import re
import time
import logging
from datetime import datetime
import numpy as np
import pandas as pd
from typing import Dict
from google.cloud import bigquery as bq
from core.utils import (
    get_bq_param,
    replace_data_loc_params,
    cast_dtypes,
    add_output_col,
    get_run_id,
)
from core.bq import run_rate_query
from core.constants import CFG, QUERY_DIR, VA_PARAMS
from modules.analysis.analysis_bq import query_analysis_input, run_step


def read_data_from_bq_analysis(logger: logging.Logger) -> pd.DataFrame:
    query_filepath = os.path.join(
        QUERY_DIR,
        "input_queries",
        CFG["query_files"]["input_queries"]["analysis_input"],
    )
    query_result = query_analysis_input(query_filepath, logger)
    return query_result


def preprocess_data_for_analysis(
    test_data: pd.DataFrame,
    table_id: str,
    csv_to_sql_info_relevant: dict,
    sql_to_csv_relevant: dict,
    logger_m: logging.Logger,
) -> pd.DataFrame:

    test_data = cast_dtypes(test_data, logger_m)

    test_data["retrieved_pbgs"] = test_data["retrieved_pbgs"].astype(str)
    test_data["retrieved_pbgs"] = test_data["retrieved_pbgs"].replace("nan", "")

    dtype_map = {"INT64": int, "STRING": str, "": int}
    for csv_col, sql_info in csv_to_sql_info_relevant.items():
        # if col dtype is float, first convert to int to remove decimal places
        if test_data[csv_col].dtype == "float64":
            # Fill NA/inf values with 0 before converting to int
            test_data[csv_col] = test_data[csv_col].fillna(0)
            test_data[csv_col] = test_data[csv_col].replace([np.inf, -np.inf], 0)
            test_data[csv_col] = test_data[csv_col].astype(int)
        # convert dtype for relevant csv columns
        test_data[csv_col] = test_data[csv_col].astype(dtype_map[sql_info[1]])
        # trim all str cols
        if sql_info[1] == "STRING":
            test_data[csv_col] = test_data[csv_col].str.strip()
            test_data[csv_col] = test_data[csv_col].replace("nan", "")
            test_data[csv_col] = test_data[csv_col].fillna("")

    # pad NETWORK_ID with 0s to length 5
    ntwk_id_col = sql_to_csv_relevant["NETWORK_ID"]
    test_data[ntwk_id_col] = test_data[ntwk_id_col].str.zfill(5)
    # if NETWORK_ID is 00000 (originally 0) replace with null
    test_data[ntwk_id_col] = test_data[ntwk_id_col].replace("00000", "")

    # if SPECIALTY_CD is 0 replace with null
    specialty_cd_col = sql_to_csv_relevant["SPECIALTY_CD"]
    test_data[specialty_cd_col] = test_data[specialty_cd_col].replace("0", "")
    test_data[specialty_cd_col] = test_data[specialty_cd_col].replace("00000", "")
    # test_data[specialty_cd_col] = test_data[specialty_cd_col].fillna("")

    # pad PLACE_OF_SERVICE_CD with 0s to length 2
    pos_cd_col = sql_to_csv_relevant["PLACE_OF_SERVICE_CD"]
    test_data[pos_cd_col] = test_data[pos_cd_col].str.zfill(2)

    # add output cols
    test_data = add_output_col(0, test_data, "correct_rate_found", None, None)
    test_data = add_output_col(0, test_data, "analysis_comments", "", "string")
    test_data = add_output_col(0, test_data, "analysis_log_id", 0, "int64")
    if "missing_source_data" not in test_data.columns:
        test_data.insert(1, "missing_source_data", False)
    else:
        # Only set to False if not already True
        test_data.loc[
            test_data["missing_source_data"] != True, "missing_source_data"
        ] = False

    if VA_PARAMS["to_bq"] is not False:
        run_id = get_run_id("analysis", table_id, logger_m)
    else:
        run_id = 0
    test_data = add_output_col(0, test_data, "analysis_run_id", run_id, "int64")
    test_data = add_output_col(
        0,
        test_data,
        "analysis_run_dt",
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "string",
    )
    if "row_num" in test_data.columns:
        test_data.insert(0, "row_num", test_data.pop("row_num"))

    return test_data


def filter_data_for_analysis(
    test_data: pd.DataFrame, logger_m: logging.Logger
) -> pd.DataFrame:
    if CFG["analysis"]["run_missing_rates"]:
        missing_rates_filter = test_data["retrieved_rate_final"].isna()
        logger_m.info(
            f"Number of missing rates: {len(test_data[missing_rates_filter])}"
        )
        analysis_filter = missing_rates_filter
    # TODO: FIRST CHECK IF USING DOLLAR ERROR, THEN FILTER BY DOLLAR OR PCT ACCORDINGLY
    # TODO: ALSO, REMOVE THE PCT COLS TO HAVE A STATIC SCHEMA; ALWAYS COMPUTE VALUES IN METRICS MODULE FOR BOTH DOLLAR AND PCTS
    if CFG["analysis"]["run_rates_outside_min_pct"]:
        rates_outside_min_pct_filter = (
            test_data[f"rate_within_{min(VA_PARAMS['flag_rates_outside_pct'])}pct"]
            == False
        )
        logger_m.info(
            f"Number of rates outside min pct: {len(test_data[rates_outside_min_pct_filter])}"
        )
        analysis_filter = rates_outside_min_pct_filter
    if (
        CFG["analysis"]["run_missing_rates"]
        and CFG["analysis"]["run_rates_outside_min_pct"]
    ):
        analysis_filter = pd.Series(
            missing_rates_filter, index=test_data.index
        ) | pd.Series(rates_outside_min_pct_filter, index=test_data.index)

    missing_src_filter = test_data["missing_source_data"] == False
    logger_m.info(
        f"Subtracting rows with missing source data: {len(test_data[~missing_src_filter])}"
    )
    analysis_filter = (analysis_filter) & missing_src_filter

    return pd.DataFrame(test_data[analysis_filter].copy())


def prep_analysis_queries():
    query_dict = {}
    for step, query in CFG["query_files"]["analysis_queries"].items():
        query_filepath = os.path.join(QUERY_DIR, "analysis", query)
        query_str = replace_data_loc_params(query_filepath)
        query_dict[step] = query_str
    return query_dict


def prep_analysis_rate_queries():
    query_str_map = {}
    # map each contract type to its query
    for query in CFG["query_files"]["rate_queries"]:
        query_filepath = os.path.join(QUERY_DIR, "rates_queries", query["query_file"])
        query_str = replace_data_loc_params(query_filepath)
        if query["query_type"] in ("standard", "claims"):
            # replace MAX(x.rate) AS max_rate with r.rate, disregarding capitilizations and x is a single alpha character
            query_str = re.sub(
                r"MAX\([a-z]\.rate\) AS max_rate",
                "rate, payment_method_cd",
                query_str,
                flags=re.IGNORECASE,
            )
        elif query["query_type"] in ("nonstandard_complex", "nonstandard_default"):
            # replace rate as max_rate with rate, disregarding capitilizations
            query_str = re.sub(
                r"rate AS max_rate",
                "rate",
                query_str,
                flags=re.IGNORECASE,
            )
            # remove WHERE rn = 1, disregarding capitilizations
            query_str = re.sub(r"WHERE rn = 1\n", "", query_str, flags=re.IGNORECASE)
        query_str_map[query["query_type"]] = query_str

    return query_str_map


def compare_incorrect_rate(
    row: pd.Series, rate_qry_result: pd.DataFrame, analysis, table
):
    if row["retrieved_rate_type"] == "pct":
        queried_rates_final = (
            (rate_qry_result["rate"] / 100) * row["billed_amt"]
        ).round()
    else:  # treat as unit
        if "unit_cnt" in row.index:
            queried_rates_final = (rate_qry_result["rate"] * row["unit_cnt"]).round()
        else:
            queried_rates_final = (rate_qry_result["rate"]).round()

    if row["allowed_amt"].round() in queried_rates_final.values:
        payment_methods_phrase = "from a single payment method"
        if rate_qry_result["payment_method_cd"].unique().size > 1:
            payment_methods_phrase = "across multiple payment methods"
        analysis += f"The correct rate, rounded {payment_methods_phrase} to the nearest dollar can be found in the {table} table; taking the overall maximum rate leads to an incorrect outcome.\n"
        correct_rate_found = True
    else:
        correct_rate_found = False
    return analysis, correct_rate_found


def analyze_missing_rate_nonstd_source_data_qualifer_detail(
    analysis_queries: Dict[str, str],
    pbg_nbrs: bq.ArrayQueryParameter | bq.ScalarQueryParameter,
    svc_cd: bq.ScalarQueryParameter | bq.ArrayQueryParameter,
    svc_type_cd: bq.ScalarQueryParameter | bq.ArrayQueryParameter,
    analysis: str,
    logger: logging.Logger,
    client: bq.Client,
    missing_source_data: bool,
) -> tuple[str, int, bool]:

    analysis, num_rows = run_step(
        "1.[0|1.1][0|1.1]",
        "rates for nonstandard complex payment method from TIC_SCM_FEE_SERVICE_LINE_DETAIL_VIEW with PBGs",
        analysis_queries["1.[0|1.1][0|1.1]"],
        [pbg_nbrs],
        analysis,
        logger,
        client,
    )

    if num_rows == 0:
        missing_source_data = True

    else:

        if type(svc_cd) == bq.ScalarQueryParameter and svc_cd.value == "J2272":
            logger.warning(f"SKIPPED BECAUSE RESULT IS TOO LARGE: service_cd {svc_cd}")
            analysis += "SKIPPED STEP 1.[0|1.1][0|1.1].1"
            num_rows = 0
        else:
            analysis, num_rows = run_step(
                "1.[0|1.1][0|1.1].1",
                "rates for nonstandard complex payment method with PBGs and service code",
                analysis_queries["1.[0|1.1][0|1.1].1"],
                [svc_cd, svc_type_cd, pbg_nbrs],
                analysis,
                logger,
                client,
            )

    return analysis, num_rows, missing_source_data


def analyze_missing_rate_nonstd_source_data(
    analysis_queries: Dict[str, str],
    pbg_nbrs: bq.ArrayQueryParameter | bq.ScalarQueryParameter,
    svc_cd: bq.ScalarQueryParameter | bq.ArrayQueryParameter,
    svc_type_cd: bq.ScalarQueryParameter | bq.ArrayQueryParameter,
    pos_cd: bq.ScalarQueryParameter | bq.ArrayQueryParameter,
    analysis: str,
    logger: logging.Logger,
    client: bq.Client,
    missing_source_data: bool,
) -> tuple[str, int, bool]:

    analysis, num_rows = run_step(
        "1.[0|1.1]",
        "rates for nonstandard payment method from HSQ data with PBGs and service code",
        analysis_queries["1.[0|1.1]"],
        [pbg_nbrs],
        analysis,
        logger,
        client,
    )

    if num_rows > 0:
        analysis, num_rows = run_step(
            "1.[0|1.1].1",
            "POS code(s) found for PBG",
            analysis_queries["1.[0|1.1].1"],
            [pbg_nbrs, pos_cd],
            analysis,
            logger,
            client,
        )

        if num_rows == 0:
            missing_source_data = True

        else:

            analysis, num_rows, missing_source_data = (
                analyze_missing_rate_nonstd_source_data_qualifer_detail(
                    analysis_queries,
                    pbg_nbrs,
                    svc_cd,
                    svc_type_cd,
                    analysis,
                    logger,
                    client,
                    missing_source_data,
                )
            )

    else:

        analysis, num_rows, missing_source_data = (
            analyze_missing_rate_nonstd_source_data_qualifer_detail(
                analysis_queries,
                pbg_nbrs,
                svc_cd,
                svc_type_cd,
                analysis,
                logger,
                client,
                missing_source_data,
            )
        )

    return analysis, num_rows, missing_source_data


def analyze_missing_rate(
    row: pd.Series,
    analysis_queries: Dict[str, str],
    sql_to_csv_relevant: Dict[str, str],
    logger: logging.Logger,
    client: bq.Client,
):
    analysis = ""

    svc_cd = get_bq_param(sql_to_csv_relevant, row, "SERVICE_CD")
    pos_cd = get_bq_param(sql_to_csv_relevant, row, "PLACE_OF_SERVICE_CD")
    svc_type_cd = get_bq_param(sql_to_csv_relevant, row, "SERVICE_TYPE_CD")

    missing_source_data = False

    # YES PBGs -- NONSTD
    if row["retrieved_pbgs"] != "":
        pbg_nbrs = get_bq_param(sql_to_csv_relevant, row, "retrieved_pbgs")

        analysis, num_rows = run_step(
            "1",
            "rates from rates table for nonstandard payment method for service code without POS code",
            analysis_queries["1"],
            [svc_cd, svc_type_cd, pbg_nbrs],
            analysis,
            logger,
            client,
        )

        if num_rows > 0:

            analysis, num_rows = run_step(
                "1.1",
                "rates from rates table for nonstandard payment method for service code and POS code",
                analysis_queries["1.1"],
                [svc_cd, svc_type_cd, pos_cd, pbg_nbrs],
                analysis,
                logger,
                client,
            )

            if num_rows > 0:

                analysis, num_rows, missing_source_data = (
                    analyze_missing_rate_nonstd_source_data(
                        analysis_queries,
                        pbg_nbrs,
                        svc_cd,
                        svc_type_cd,
                        pos_cd,
                        analysis,
                        logger,
                        client,
                        missing_source_data,
                    )
                )

        else:  # num_rows == 0:

            analysis, num_rows, missing_source_data = (
                analyze_missing_rate_nonstd_source_data(
                    analysis_queries,
                    pbg_nbrs,
                    svc_cd,
                    svc_type_cd,
                    pos_cd,
                    analysis,
                    logger,
                    client,
                    missing_source_data,
                )
            )

    else:  # NO PBGs -- either STD or NONSTD with missing PBGs
        ntwk_id = get_bq_param(sql_to_csv_relevant, row, "NETWORK_ID")
        pid_nbr = get_bq_param(
            sql_to_csv_relevant,
            row,
            "PROVIDER_IDENTIFICATION_NBR",
        )
        svc_loc_nbr = get_bq_param(sql_to_csv_relevant, row, "SERVICE_LOCATION_NBR")

        analysis, num_rows = run_step(
            "0",
            "providers from TIC_EPDB_TAX_IDENTIFICATION_NUMBER_ADDRESS_DETAIL_VIEW",
            analysis_queries["0"],
            [pid_nbr, svc_loc_nbr, ntwk_id],
            analysis,
            logger,
            client,
        )

        if num_rows == 0:
            missing_source_data = True

        else:
            specialty_cd = get_bq_param(sql_to_csv_relevant, row, "SPECIALTY_CD")

            analysis, num_rows = run_step(
                "0.1",
                "records from specialty table",
                analysis_queries["0.1"],
                [pid_nbr, ntwk_id, specialty_cd],
                analysis,
                logger,
                client,
            )

            if num_rows == 0:
                missing_source_data = True

            else:

                analysis, num_rows = run_step(
                    "0.1.1",
                    "rates from rates table",
                    analysis_queries["0.1.1"],
                    [svc_cd, svc_type_cd, pos_cd],
                    analysis,
                    logger,
                    client,
                )

    return analysis, missing_source_data


def analyze_incorrect_rate(
    row: pd.Series,
    analysis_rate_queries: dict,
    sql_to_csv_relevant: dict,
    logger: logging.Logger,
    client: bq.Client,
):
    analysis = ""
    if row["claims_std_nonstd"] == "C":
        rate_qry_result = run_rate_query(
            row, "claims", analysis_rate_queries, sql_to_csv_relevant, logger, client
        )
        analysis, correct_rate_found = compare_incorrect_rate(
            row, rate_qry_result, analysis, "claims"
        )

    elif row["claims_std_nonstd"] == "S":
        rate_qry_result = run_rate_query(
            row, "standard", analysis_rate_queries, sql_to_csv_relevant, logger, client
        )
        analysis, correct_rate_found = compare_incorrect_rate(
            row, rate_qry_result, analysis, "rates"
        )

    else:  #  row["claims_std_nonstd"] == "N":
        rate_qry_result = run_rate_query(
            row,
            "nonstandard_complex",
            analysis_rate_queries,
            sql_to_csv_relevant,
            logger,
            client,
        )

        if (
            len(rate_qry_result) == 0
            or rate_qry_result["rate"].max() is None
            or rate_qry_result["rate"].max() is pd.NA
        ):

            rate_qry_result = run_rate_query(
                row,
                "nonstandard_default",
                analysis_rate_queries,
                sql_to_csv_relevant,
                logger,
                client,
            )

        analysis, correct_rate_found = compare_incorrect_rate(
            row, rate_qry_result, analysis, "rates"
        )

    return analysis, correct_rate_found


def log_analysis_time(
    logger: logging.Logger,
    log_time_every,
    analysis_time,
    analysis_time_last_n,
    process,
):
    now = time.time()
    elapsed_time = now - analysis_time
    elapsed_time_str = time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    elapsed_time_last_n = now - analysis_time_last_n
    elapsed_last_n_str = time.strftime("%H:%M:%S", time.gmtime(elapsed_time_last_n))

    logger.warning(
        f"Process {process} - Time for last {log_time_every} tests: {elapsed_last_n_str}; Total analysis runtime: {elapsed_time_str}"
    )
    return now
