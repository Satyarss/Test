import os
import time
import logging
import multiprocessing
import pandas as pd
from google.cloud import bigquery as bq
from core.custom_logger import CustomLogger
from core.utils import (
    initialize_column_maps,
    write_slice_to_bq,
    save_to_csv,
    checkpoint_conditions,
    checkpoint_conditions_last,
    write_all_to_bq,
)
from core.constants import PY_DIR, CFG, VALIDATION, VA_PARAMS
from modules.analysis.analysis_helpers import (
    prep_analysis_queries,
    prep_analysis_rate_queries,
    preprocess_data_for_analysis,
    filter_data_for_analysis,
    analyze_missing_rate,
    analyze_incorrect_rate,
    log_analysis_time,
)


def analyze_rows(
    test_data_filtered: pd.DataFrame,
    analysis_filename: str,
    datetime_str: str,
    table_id: str,
    sql_to_csv_relevant: dict,
    process: int,
):
    logger = CustomLogger("analysis", datetime_str, process)
    client = bq.Client()

    analysis_queries = prep_analysis_queries()
    analysis_rate_queries = prep_analysis_rate_queries()

    to_csv, to_bq, log_time_every = (
        VA_PARAMS["to_csv"],
        VA_PARAMS["to_bq"],
        VA_PARAMS["log_time_every"],
    )
    if to_csv is not False:
        analysis_filepath = os.path.join(
            PY_DIR, "..", "test_cases", "output", datetime_str, analysis_filename
        )
        test_data_filtered.iloc[:0].to_csv(
            analysis_filepath, mode="w", index=False, header=False
        )
    if log_time_every:
        analysis_time = time.time()
        analysis_time_last_n = analysis_time

    for i in range(len(test_data_filtered)):
        if i != 0:
            logger.info("\n\n\n\n")
        log_id = process * 10000 + i
        logger.info(
            f"analysis_log_id: {log_id} (row {i+1} of {len(test_data_filtered)})"
        )
        test_data_filtered.loc[i, "analysis_log_id"] = log_id

        row = test_data_filtered.iloc[i]
        if pd.isna(row["retrieved_rate_final"]):
            analysis, missing_source_data = analyze_missing_rate(
                row, analysis_queries, sql_to_csv_relevant, logger, client
            )
        else:  # must be one or the other at this point
            analysis, correct_rate_found = analyze_incorrect_rate(
                row, analysis_rate_queries, sql_to_csv_relevant, logger, client
            )
            missing_source_data = False
            test_data_filtered.loc[i, "correct_rate_found"] = correct_rate_found

        test_data_filtered.loc[i, "analysis_comments"] = analysis[:-1]
        test_data_filtered.loc[i, "missing_source_data"] = missing_source_data

        if checkpoint_conditions(to_csv, i):
            save_to_csv(
                test_data_filtered.iloc[i + 1 - to_csv : i + 1].copy(),
                analysis_filepath,
                logger,
                i,
            )
        if checkpoint_conditions(to_bq, i):
            write_slice_to_bq(
                test_data_filtered.iloc[i + 1 - to_bq : i + 1].copy(),
                table_id,
                logger,
                i,
            )
        if checkpoint_conditions(log_time_every, i):
            analysis_time_last_n = log_analysis_time(
                logger,
                log_time_every,
                analysis_time,
                analysis_time_last_n,
                process,
            )

    len_data = len(test_data_filtered)
    if checkpoint_conditions_last(to_csv, len_data):
        last_start = len_data - len_data % to_csv if len_data > to_csv else 0
        save_to_csv(
            test_data_filtered.iloc[last_start:].copy(),
            analysis_filepath,
            logger,
            last_start,
            last=True,
        )
    if checkpoint_conditions_last(to_bq, len_data):
        last_start = len_data - len_data % to_bq if len_data > to_bq else 0
        write_slice_to_bq(
            test_data_filtered.iloc[last_start:].copy(),
            table_id,
            logger,
            last_start,
            last=True,
        )

    CustomLogger.close_all_handlers(logger)
    if to_csv is True:
        test_data_filtered.to_csv(analysis_filepath, index=False)
    return test_data_filtered


def analyze_rows_mp(
    test_data_filtered: pd.DataFrame,
    analysis_filename,
    datetime_str,
    table_id,
    sql_to_csv_relevant,
    num_analysis_processes,
) -> pd.DataFrame:
    args_list = []
    # divide test data into chunks for multiprocessing
    chunk_size = len(test_data_filtered) // num_analysis_processes
    for process in range(num_analysis_processes):
        start_idx = process * chunk_size
        if process == num_analysis_processes - 1:
            end_idx = len(test_data_filtered)
        else:
            end_idx = start_idx + chunk_size
        test_data_chunk = test_data_filtered.iloc[start_idx:end_idx].reset_index(
            drop=True
        )

        analysis_filename_mp = f"{analysis_filename[:-4]}_{process+1}.csv"

        args_list.append(
            (
                test_data_chunk,
                analysis_filename_mp,
                datetime_str,
                table_id,
                sql_to_csv_relevant,
                process + 1,  # process id starts at 1
            )
        )

    with multiprocessing.Pool() as pool:
        test_data_filtered = pd.concat(
            pool.starmap(analyze_rows, args_list)
        ).reset_index(drop=True)

    if VA_PARAMS["to_csv"] is not False:
        for args in args_list:
            os.remove(
                os.path.join(
                    PY_DIR, "..", "test_cases", "output", datetime_str, args[1]
                )
            )

    return test_data_filtered


def analysis(
    test_data, analysis_filename, datetime_str, logger_m: logging.Logger
) -> pd.DataFrame:
    csv_to_sql_info_relevant, sql_to_csv_relevant = initialize_column_maps(test_data)
    if not VALIDATION:
        logger_m.info(f"SQL to CSV mapping: {sql_to_csv_relevant}")
    table_id = f"{CFG['data_locations']['project']}.{CFG['data_locations']['ds_dataset']}.{CFG['data_locations']['analysis_output_table']}"
    test_data = preprocess_data_for_analysis(
        test_data, table_id, csv_to_sql_info_relevant, sql_to_csv_relevant, logger_m
    )
    test_data_analysis = filter_data_for_analysis(test_data, logger_m)
    analysis_rows_orig_indices = test_data_analysis.index
    test_data_analysis.reset_index(drop=True, inplace=True)

    logger_m.warning(
        f"Analysis will be run on {len(test_data_analysis)} rows of test data"
    )

    if VA_PARAMS["processes"] == 1:
        logger_m.warning("Starting analysis with single process")
        test_data_analysis = analyze_rows(
            test_data_analysis,
            analysis_filename,
            datetime_str,
            table_id,
            sql_to_csv_relevant,
            1,
        )
    else:
        # if VALIDATION:
        #     num_analysis_processes = (
        #         round((len(test_data_filtered) / len(test_data)) * VA_PARAMS["processes"]) + 1
        #     )
        # else:
        #     num_analysis_processes = VA_PARAMS["processes"]
        num_analysis_processes = VA_PARAMS["processes"]
        logger_m.warning(
            f"Starting multiprocessing analysis for {num_analysis_processes} processes"
        )
        test_data_analysis = analyze_rows_mp(
            test_data_analysis,
            analysis_filename,
            datetime_str,
            table_id,
            sql_to_csv_relevant,
            num_analysis_processes,
        )

    # Update the original test_data DataFrame with the original indices
    for col in [
        "analysis_log_id",
        "analysis_comments",
        "missing_source_data",
        "correct_rate_found",
    ]:
        if col in test_data_analysis.columns:
            test_data.loc[analysis_rows_orig_indices, col] = test_data_analysis[
                col
            ].values

    if (
        VA_PARAMS["to_csv"] is not False
    ):  # otherwise analyze_rows handles writing to csv
        analysis_filepath = os.path.join(
            PY_DIR, "..", "test_cases", "output", datetime_str, analysis_filename
        )
        if (
            VA_PARAMS["processes"] > 1
        ):  # need to consolidate csvs if multiprocessing so must rewrite all
            test_data.to_csv(analysis_filepath, index=False)
        else:  # already wrote all analyzed cases to csv in for loop
            test_data[test_data["analysis_log_id"] == 0].to_csv(
                analysis_filepath,
                mode="a",
                index=False,
                header=False,
            )

    if VA_PARAMS["to_bq"] is True:
        write_all_to_bq(test_data, table_id, logger_m)
    elif VA_PARAMS["to_bq"] is not False:
        write_all_to_bq(
            pd.DataFrame(test_data[test_data["analysis_log_id"] == 0]),
            table_id,
            logger_m,
            remaining=True,
        )
    CustomLogger.concat_logs("analysis", datetime_str)
    logger_m.warning("Analysis complete")
    return test_data
