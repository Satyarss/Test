import logging
import pandas as pd
from google.cloud import bigquery as bq
from core.constants import CFG
from core.utils import replace_data_loc_params
from core.log_helpers import log_query


def query_analysis_input(query_filepath, logger: logging.Logger) -> pd.DataFrame:
    query_str = replace_data_loc_params(query_filepath)
    query_parameters = [
        bq.ScalarQueryParameter(
            "analysis_input_dt_str", "STRING", CFG["analysis"]["input_bq_dt_str"]
        ),
    ]

    log_query(query_str, query_parameters, logger)
    query_job_config = bq.QueryJobConfig(query_parameters=query_parameters)
    client = bq.Client()
    query_result = client.query(query_str, query_job_config).to_dataframe()
    return query_result


def run_step(
    step,
    message,
    query,
    query_params,
    analysis,
    logger: logging.Logger,
    client: bq.Client,
    # return_query_result=False,
) -> tuple[str, int]:
    logger.info(f"{step}: Querying for {message}")
    log_query(query, query_params, logger)
    query_job_config = bq.QueryJobConfig(query_parameters=query_params)
    query_result = client.query(query, query_job_config).result()
    num_rows = query_result.total_rows or 0  # Convert None to 0
    analysis += f"{step}: Retrieved {num_rows} {message}.\n"
    if num_rows > 0:
        query_result_df = query_result.to_dataframe()
        logger.info(f"\n{query_result_df}")
    #     if return_query_result:
    #         return analysis, num_rows, query_result_df
    # elif return_query_result:
    #     return analysis, num_rows, None

    return analysis, num_rows
