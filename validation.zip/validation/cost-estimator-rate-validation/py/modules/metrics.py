import os
import logging
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from matplotlib.patches import FancyBboxPatch
from core.constants import PY_DIR, CFG, VA_PARAMS


# ────────────────────────────────────────────────────────────────
# Helper – draw decision-tree graphic
# ────────────────────────────────────────────────────────────────
def plot_layered_metrics(metrics: dict, threshold_text: str, save_path: str) -> None:
    """
    metrics        dict with percentages for every node
    threshold_text string like "5%" or "$5"
    save_path      PNG output path
    """

    # node coordinates (hand-tuned)
    pos = {
        "correct": (-4.0, 0),
        "incorrect": (0.0, 0),
        "no_rate": (-1.0, -2),
        "rate_retrieved": (3.0, -2),
        "missing_data": (-2.0, -4),
        "has_data_no_rate": (0.6, -4),
        "bad_pred": (3.0, -4),
        "ok_pred": (6.0, -4),
        "correct_not_selected": (1.6, -6),
        "correct_not_available": (4.4, -6),
        "under": (0.5, -8),
        "over": (2.7, -8),
    }
    edges = [
        ("incorrect", "no_rate"),
        ("incorrect", "rate_retrieved"),
        ("no_rate", "missing_data"),
        ("no_rate", "has_data_no_rate"),
        ("rate_retrieved", "bad_pred"),
        ("rate_retrieved", "ok_pred"),
        ("bad_pred", "correct_not_selected"),
        ("bad_pred", "correct_not_available"),
        ("correct_not_selected", "under"),
        ("correct_not_selected", "over"),
    ]

    # which nodes are actionable (red)
    actionable = {
        "has_data_no_rate",
        "correct_not_selected",
        "correct_not_available",
    }
    # success / good nodes (green)
    good_nodes = {"correct", "ok_pred"}

    half_h = {}  # half-height of each box

    def add_box(ax, node, label):
        x, y = pos[node]

        tmp = ax.text(
            x,
            y,
            label,
            ha="center",
            va="center",
            fontsize=11,
            linespacing=1.2,
            wrap=True,
            zorder=3,
        )
        plt.draw()
        bb = tmp.get_window_extent(renderer=ax.figure.canvas.get_renderer())
        inv = ax.transData.inverted()
        (x0, y0), (x1, y1) = inv.transform([[bb.x0, bb.y0], [bb.x1, bb.y1]])
        w, h = abs(x1 - x0), abs(y1 - y0)
        pad = 0.65  # roomy boxes
        tmp.remove()

        if node in actionable:
            fc = "#f4cccc"  # red/pink
        elif node in good_nodes:
            fc = "#b6d7a8"  # green
        else:
            fc = "white"

        ax.add_patch(
            FancyBboxPatch(
                (x - w / 2 - pad, y - h / 2 - pad),
                w + 2 * pad,
                h + 2 * pad,
                boxstyle="round,pad=0.15",
                fc=fc,
                ec="black",
                lw=1.3,
                zorder=2,
            )
        )
        ax.text(
            x,
            y,
            label,
            ha="center",
            va="center",
            fontsize=11,
            linespacing=1.2,
            wrap=True,
            zorder=3,
        )

        half_h[node] = (h + 2 * pad) / 2

    fig, ax = plt.subplots(figsize=(15, 9))
    ax.axis("off")

    add_box(ax, "correct", f"Correct Rate\n{metrics['correct']}%")
    add_box(ax, "incorrect", f"Incorrect Rate\n{metrics['incorrect']}%")

    add_box(ax, "no_rate", f"No Rate Retrieved\n{metrics['no_rate']}%")
    add_box(ax, "rate_retrieved", f"Rate Retrieved\n{metrics['rate_retrieved']}%")

    add_box(ax, "missing_data", f"Missing source data\n{metrics['missing_data']}%")
    add_box(
        ax,
        "has_data_no_rate",
        f"Has source data, but\ndidn't retrieve rate\n{metrics['has_data_no_rate']}%",
    )

    add_box(
        ax, "bad_pred", f"Outside ±{threshold_text} threshold\n{metrics['bad_pred']}%"
    )
    add_box(ax, "ok_pred", f"Within ±{threshold_text} threshold\n{metrics['ok_pred']}%")

    add_box(
        ax,
        "correct_not_selected",
        f"Correct rate available,\nbut not selected\n{metrics['correct_not_selected']}%",
    )
    add_box(
        ax,
        "correct_not_available",
        f"Correct Rate not available\n{metrics['correct_not_available']}%",
    )

    add_box(ax, "under", f"Underpredict\n{metrics['under']}%")
    add_box(ax, "over", f"Overpredict\n{metrics['over']}%")

    # arrows (margin = 0.15 --> slightly longer than previous 0.25/0.25 combo)
    margin = 0.15
    for p, c in edges:
        x0, y0 = pos[p]
        x1, y1 = pos[c]
        ax.annotate(
            "",
            xy=(x1, y1 + half_h[c] + margin),
            xytext=(x0, y0 - half_h[p] - margin),
            arrowprops=dict(arrowstyle="->", lw=1.2),
        )

    xs, ys = zip(*pos.values())
    ax.set_xlim(min(xs) - 1, max(xs) + 1)
    ax.set_ylim(min(ys) - 1.2, max(ys) + 1.2)

    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


# ────────────────────────────────────────────────────────────────
# Deep-dive helper
# ────────────────────────────────────────────────────────────────
def deep_dive_tables(
    df: pd.DataFrame,
    bucket_col: str,
    cfg_deep: dict,
    out_dir: str,
    logger: logging.Logger,
):
    """
    Build per-bucket summary tables & optional heat-maps.
    """
    #import numpy as np
    #import os

    os.makedirs(out_dir, exist_ok=True)

    # helper columns
    df["diff"] = df["retrieved_rate_final"] - df["allowed_amt"]  # signed difference
    df["row_with_rate"] = df["retrieved_rate_final"].notna()
    df["correct_flag"] = df["retrieved_rate_final"].round(2) == df["allowed_amt"].round(
        2
    )  # TRUE when prediction is correct

    # df["unit_cnt_flag"] = np.where(df["unit_cnt"] > 1, "unit>1", "unit=1")
    df["unit_cnt_flag"] = np.select(  # 3-level unit flag
        [df["unit_cnt"] == 0, df["unit_cnt"] == 1, df["unit_cnt"] > 1],
        ["unit=0", "unit=1", "unit>1"],
        default="unit=missing",  # in case unit_cnt is NaN
    )
    for gvar in cfg_deep["group_vars"]:
        # ── NEW (add below helper-columns section, before the pivot loop) ──
        # Build a *label* column that already contains the right “catch-all” strings
        label_col = f"{gvar}_label"

        df[label_col] = (
            df[gvar]  # original values
            .fillna(f"No {gvar}")  # missing --> “No <grouping variable>”
            .replace("", f"No {gvar}")  # empty strings --> same label
            .astype("object")
        )

        # rows with **no predicted rate** override whatever label they got above
        df.loc[df["retrieved_rate_final"].isna(), label_col] = "No Rate"

        gdir = os.path.join(out_dir, gvar)
        os.makedirs(gdir, exist_ok=True)

        for metric in cfg_deep["compare_metrics"]:
            if metric == "row_count":
                pivot = df.pivot_table(
                    index=label_col,
                    columns=bucket_col,
                    values="allowed_amt",
                    aggfunc="size",
                    fill_value=0,
                )
                pivot = pivot.div(pivot.sum(axis=0), axis=1).round(3)  # % of column
            elif metric == "row_with_rate":
                # --------------------------------------------
                # Build “share of rows-with-rate” FOR EACH BUCKET.
                # • If that bucket contains no rows with a rate,
                #   fall back to the share of *all* rows (so one
                #   category – often “No value” – will show as 1.0).
                # --------------------------------------------
                num = df.pivot_table(
                    index=label_col,
                    columns=bucket_col,
                    values="row_with_rate",
                    aggfunc="sum",
                    fill_value=0,
                )

                den = df.pivot_table(
                    index=label_col,
                    columns=bucket_col,
                    values="allowed_amt",
                    aggfunc="size",
                    fill_value=0,
                )

                pivot_parts = {}
                for col in num.columns:
                    if num[col].sum() == 0:  # <-- no rows with rate
                        # use raw row counts to get a 100 % column
                        part = den[col] / den[col].sum()
                    else:  # normal case
                        part = num[col] / num[col].sum()
                    pivot_parts[col] = part

                pivot = pd.DataFrame(pivot_parts).round(
                    3
                )  # values 0-1, each col sums to 1

            elif metric == "avg_diff":
                pivot = df.pivot_table(
                    index=label_col, columns=bucket_col, values="diff", aggfunc="mean"
                ).round(2)
            elif metric == "avg_allowed_amt":
                pivot = df.pivot_table(
                    index=label_col,
                    columns=bucket_col,
                    values="allowed_amt",
                    aggfunc="mean",
                ).round(2)
            elif metric == "correct_rate_pct":
                # one column, no buckets – % of correct predictions by category
                # Filter out "No Rate" rows for this metric
                df_with_rate = df[df["retrieved_rate_final"].notna()].copy()
                
                # Calculate within-threshold flag for each row (includes exact matches)
                use_dollar_error = VA_PARAMS["use_dollar_error"]
                if use_dollar_error:
                    min_dollar = min(VA_PARAMS["flag_rates_outside_dollar"])
                    df_with_rate["within_threshold_flag"] = (
                        abs(df_with_rate["retrieved_rate_final"] - df_with_rate["allowed_amt"]) <= min_dollar
                    )
                else:
                    min_pct = min(VA_PARAMS["flag_rates_outside_pct"])
                    df_with_rate["within_threshold_flag"] = (
                        abs(df_with_rate["retrieved_rate_final"] - df_with_rate["allowed_amt"])
                        / df_with_rate["allowed_amt"].clip(lower=0.001) <= min_pct / 100
                    )
                
                # Use within_threshold_flag instead of correct_flag for category-level calculations
                pivot = (
                    df_with_rate.groupby(label_col)["within_threshold_flag"]
                    .mean()  # fraction within threshold (0-1)
                    .round(3)
                    .to_frame("correct_rate_pct")
                )
                pivot = pivot.rename_axis(
                    "category"
                ).reset_index()  # rename index to "category"
                # ── add row-count column so the CSV matches the plot ──
                pivot["row_count"] = (
                    df_with_rate.groupby(label_col).size().reindex(pivot["category"]).values
                )
                # --sort by accuracy (high --> low) so the CSV output is ordered --
                pivot = pivot.sort_values(
                    "correct_rate_pct", ascending=False
                ).reset_index(drop=True)
            else:
                continue

            # -------- add Overall column and reorder ------------------------
            if metric != "correct_rate_pct":
                bucket_order = cfg_deep["buckets"] + ["Overall"]

                if metric in ("row_count", "row_with_rate"):
                    overall_series = (
                        df.groupby(label_col).size()
                        if metric == "row_count"
                        else df.groupby(label_col)["row_with_rate"].sum()
                    )
                    overall_series = overall_series.div(overall_series.sum()).round(3)
                else:  # averages
                    col_to_avg = "diff" if metric == "avg_diff" else "allowed_amt"
                    overall_series = df.groupby(label_col)[col_to_avg].mean().round(2)

                pivot["Overall"] = (
                    overall_series  # executes for all 4 metrics except correct_rate_pct
                )
                pivot = pivot.reindex(columns=bucket_order)  # drop extras / reorder

            # -------- write CSV with N/A for missing cells ------------------
            csv_path = os.path.join(gdir, f"{metric}.csv")
            if metric == "correct_rate_pct":
                pivot.to_csv(csv_path, index=False)  # already clean
            else:
                if metric == "row_with_rate":
                    pivot_to_write = pivot
                else:
                    pivot_to_write = pivot.replace({np.nan: "N/A"})
                pivot_to_write.to_csv(csv_path)

            if metric == "correct_rate_pct":
                # ─────────── horizontal bar-chart with benchmark + row-count axis ────────────
                try:
                    # --- data (exclude "No Rate" categories) ----------------------------
                    df_with_rate = df[df["retrieved_rate_final"].notna()].copy()
                    
                    ordering = pivot.set_index("category")[
                        "correct_rate_pct"
                    ].sort_values(ascending=False)
                    counts = (
                        df_with_rate.groupby(label_col).size().reindex(ordering.index)
                    )  # row counts per category (excluding No Rate)
                    
                    # Modified overall accuracy calculation
                    # Include both exact matches and within-threshold predictions
                    # from rows that have retrieved rates
                    use_dollar_error = VA_PARAMS["use_dollar_error"]
                    if use_dollar_error:
                        min_dollar = min(VA_PARAMS["flag_rates_outside_dollar"])
                        within_threshold = (
                            abs(df_with_rate["retrieved_rate_final"] - df_with_rate["allowed_amt"]) <= min_dollar
                        ).sum()
                    else:
                        min_pct = min(VA_PARAMS["flag_rates_outside_pct"])
                        within_threshold = (
                            abs(df_with_rate["retrieved_rate_final"] - df_with_rate["allowed_amt"])
                            / df_with_rate["allowed_amt"].clip(lower=0.001) <= min_pct / 100
                        ).sum()
                    
                    # Overall accuracy: within threshold / total rows with rates
                    overall = (within_threshold / len(df_with_rate)).round(3)  # (0-1)

                    # --- basic bar plot -------------------------------------------------
                    fig, ax = plt.subplots(figsize=(8, 0.45 * len(ordering) + 1))
                    y_pos = np.arange(len(ordering))
                    colors = cm.Greens(ordering.values)
                    bars = ax.barh(y_pos, ordering.values, color=colors)

                    ax.set_yticks(y_pos)
                    ax.set_yticklabels(ordering.index)
                    ax.invert_yaxis()  # best group at top
                    ax.set_xlim(0, 1.05)  # a little breathing-room on the right
                    ax.set_xlabel("% correct prediction")
                    ax.set_title(f"Prediction accuracy by {gvar}", pad=18)

                    # ── % labels on each bar  (push inside the bar when ≥ 95 %) ──────────
                    for b, v in zip(bars, ordering.values):
                        if v >= 0.95:  # 95 % or higher --> label inside bar
                            ax.text(
                                v - 0.02,  # nudge left so text is inside bar
                                b.get_y() + b.get_height() / 2,
                                f"{v:.0%}",
                                ha="right",
                                va="center",
                                color="white",
                                fontsize=9,
                                clip_on=False,
                            )
                        else:  # normal case --> outside bar
                            ax.text(
                                v + 0.015,
                                b.get_y() + b.get_height() / 2,
                                f"{v:.0%}",
                                ha="left",
                                va="center",
                                fontsize=9,
                                clip_on=False,
                            )

                    # ── vertical benchmark line (green) + label  ────────────────────────
                    ax.axvline(overall, color="forestgreen", ls="--", lw=1)

                    # put the “Overall” label **inside** the plotting area but just below the bars
                    ax.text(
                        overall + 0.015,
                        y_pos[-1] + 0.25,  # slightly above the bottom bar
                        f"Overall: {overall:.0%}",
                        color="forestgreen",
                        ha="left",
                        va="center",
                        fontsize=9,
                    )

                    # --- secondary Y-axis with row counts ------------------------------
                    ax2 = ax.twinx()
                    ax2.set_ylim(ax.get_ylim())  # keep the two y-axes aligned
                    ax2.set_yticks(y_pos)
                    ax2.set_yticklabels([f"{c:,}" for c in counts])
                    total_n = int(counts.sum())
                    ax2.set_ylabel(
                        f"Row count (n = {total_n:,})", rotation=-90, labelpad=15
                    )
                    ax2.tick_params(axis="y", pad=3)  # small gap between ticks & plot

                    # --- save -----------------------------------------------------------
                    plt.tight_layout()
                    fig.savefig(
                        os.path.join(gdir, f"{metric}.png"),
                        dpi=150,
                        bbox_inches="tight",
                    )
                    plt.close(fig)

                except Exception as e:
                    logger.warning(f"bar-plot for {gvar}/{metric} skipped ({e})")

            logger.info(f"deep-dive table saved --> {csv_path}")

            # optional heat-map
            if metric != "correct_rate_pct":
                try:
                    plt.figure(
                        figsize=(max(6, 1.2 * len(pivot.columns)), 4 + 0.3 * len(pivot))
                    )
                    mask = pivot.isna()  # keep NaNs blank in the plot
                    sns.heatmap(
                        pivot,
                        mask=mask,
                        cmap="Greens",
                        annot=True,
                        fmt=".0%" if metric.startswith("row_") else ".1f",
                    )
                    plt.title(f"{metric} by {gvar}")
                    plt.tight_layout()
                    plt.savefig(os.path.join(gdir, f"{metric}.png"), dpi=150)
                    plt.close()
                except Exception as e:
                    logger.warning(f"heat-map for {gvar}/{metric} skipped ({e})")


def metrics_old(
    test_data: pd.DataFrame,
    datetime_str: str,
    output_filename: str,
    logger_m: logging.Logger,
):
    logger_m.info("Calculating metrics")
    num_test_cases = len(test_data)
    # We only check for TINs and PBGs if rate not found in claims table,
    # so may not be be accurate
    # num_cases_with_tins = len(
    #     test_data[
    #         (test_data["retrieved_tins"].notna()) & (test_data["retrieved_tins"] != "")
    #     ]
    # )
    # num_cases_with_pbgs = len(
    #     test_data[
    #         (test_data["retrieved_pbgs"].notna()) & (test_data["retrieved_pbgs"] != "")
    #     ]
    # )
    if "pos_cd_validation_pass" in test_data.columns:
        num_cases_pos_cd_validation_fail = len(
            test_data[test_data["pos_cd_validation_pass"] == False]
        )

    if "pbgs_validation_pass" in test_data.columns:
        num_cases_pbgs_validation_fail = len(
            test_data[test_data["pbgs_validation_pass"] == False]
        )

    # Check if missing_source_data column exists and if so, contains any non-None values
    has_missing_source_data: bool = (
        "missing_source_data" in test_data.columns
        and len(test_data[test_data["missing_source_data"].notna()]) > 0
    )
    if has_missing_source_data:
        num_cases_without_missing_source_data = len(
            test_data[test_data["missing_source_data"] == False]
        )
        # remove cases missing source data
        test_data = pd.DataFrame(test_data[test_data["missing_source_data"] == False])
    else:
        num_cases_without_missing_source_data = None

    num_cases_with_rate = len(test_data[test_data["retrieved_rate_final"].notna()])
    num_cases_c = len(test_data[test_data["claims_std_nonstd"] == "C"])
    num_cases_s = len(test_data[test_data["claims_std_nonstd"] == "S"])
    num_cases_n = len(test_data[test_data["claims_std_nonstd"] == "N"])
    num_cases_s_rate = len(
        test_data[
            (test_data["claims_std_nonstd"] == "S")
            & (test_data["retrieved_rate_final"].notna())
        ]
    )
    num_cases_n_rate = len(
        test_data[
            (test_data["claims_std_nonstd"] == "N")
            & (test_data["retrieved_rate_final"].notna())
        ]
    )

    test_data_with_rates = test_data[test_data["retrieved_rate_final"].notna()]

    exact_match = test_data_with_rates[
        test_data_with_rates["retrieved_rate_final"].astype(float).round(2)
        == test_data_with_rates["allowed_amt"].astype(float).round(2)
    ]
    within_1d = test_data_with_rates[
        abs(
            test_data_with_rates["retrieved_rate_final"]
            - test_data_with_rates["allowed_amt"]
        )
        <= 1
    ]

    if "correct_rate_found" in test_data.columns:
        num_cases_correct_rate_found = len(
            test_data[test_data["correct_rate_found"] == True]
        )
        num_cases_with_rate_outside_min_pct = len(
            test_data[
                (test_data["retrieved_rate_final"].notna())
                & (
                    test_data[
                        f"rate_within_{min(VA_PARAMS['flag_rates_outside_pct'])}pct"
                    ]
                    == False
                )
            ]
        )

    metrics_filepath = os.path.join(
        PY_DIR,
        "..",
        "test_cases",
        "output",
        datetime_str,
        output_filename,
    )
    with open(metrics_filepath, "w") as f:
        f.write(f"Metrics for test cases run on: {datetime_str}\n\n")
        f.write(f"No. of test cases: {num_test_cases}\n")
        # f.write(
        #     f"No. of test cases with TINs: {num_cases_with_tins} ({round(num_cases_with_tins / num_test_cases * 100, 2)}%)\n"
        # )
        # f.write(
        #     f"No. of test cases with PBGs: {num_cases_with_pbgs} ({round(num_cases_with_pbgs / num_test_cases * 100, 2)}%)\n"
        # )
        if "pos_cd_validation_pass" in test_data.columns:
            f.write(
                f"No. of test cases where POS code validation fails: {num_cases_pos_cd_validation_fail} ({round(num_cases_pos_cd_validation_fail / num_test_cases * 100, 2)}%)\n"
            )
        if "pbgs_validation_pass" in test_data.columns:
            f.write(
                f"No. of test cases where PBG validation fails: {num_cases_pbgs_validation_fail} ({round(num_cases_pbgs_validation_fail / num_test_cases * 100, 2)}%)\n"
            )

        if num_cases_without_missing_source_data is not None:
            f.write(
                f"No. of test cases without missing source data: {num_cases_without_missing_source_data} ({round(num_cases_without_missing_source_data / num_test_cases * 100, 2)}%)\n\n"
            )
            f.write(
                f"ALL METRICS BELOW ARE BASED ON TEST CASES WITHOUT MISSING SOURCE DATA\n"
            )
            num_test_cases = num_cases_without_missing_source_data

        f.write(
            f"No. of test cases with rate: {num_cases_with_rate} ({round(num_cases_with_rate / num_test_cases * 100, 2)}%)\n"
        )
        f.write(
            f"No. of test cases with rate in claims: {num_cases_c} ({round(num_cases_c / num_test_cases * 100, 2)}%)\n"
        )
        f.write(
            f"No. of standard queries: {num_cases_s} ({round(num_cases_s / num_test_cases * 100, 2)}%)\n"
        )
        f.write(
            f"No. of nonstandard queries: {num_cases_n} ({round(num_cases_n / num_test_cases * 100, 2)}%)\n"
        )
        f.write(f"No. of test cases with standard query and rate: {num_cases_s_rate}")
        if num_cases_s > 0:
            f.write(
                f" ({round(num_cases_s_rate / num_cases_s * 100, 2)}% of cases with standard query)\n"
            )
        else:
            f.write("\n")
        f.write(
            f"No. of test cases with nonstandard query and rate: {num_cases_n_rate}"
        )
        if num_cases_n > 0:
            f.write(
                f" ({round(num_cases_n_rate / num_cases_n * 100, 2)}% of cases with nonstandard query)\n"
            )
        else:
            f.write("\n")
        if num_cases_with_rate > 0:
            f.write(
                f"No. of test cases where rate matches allowed_amt: {len(exact_match)} ({round(len(exact_match) / num_cases_with_rate * 100, 2)}% of test cases with rate)\n"
            )
            f.write(
                f"No. of test cases where rate is within $1 of allowed_amt: {len(within_1d)} ({round(len(within_1d) / num_cases_with_rate * 100, 2)}% of test cases with rate)\n"
            )
            for pct in VA_PARAMS["flag_rates_outside_pct"]:
                within_pct = test_data_with_rates[
                    test_data_with_rates[f"rate_within_{pct}pct"] == True
                ]
                f.write(
                    f"No. of test cases where rate is within {pct}% of allowed_amt: {len(within_pct)} ({round(len(within_pct) / num_cases_with_rate * 100, 2)}% of test cases with rate)\n"
                )
        if "correct_rate_found" in test_data.columns:
            correct_rate_found_pct = (
                round(
                    float(num_cases_correct_rate_found)
                    / float(num_cases_with_rate_outside_min_pct)
                    * 100,
                    2,
                )
                if num_cases_with_rate_outside_min_pct > 0
                else 0
            )
            f.write(
                f"No. of test cases with correct rate found when not taking max rate: {num_cases_correct_rate_found} ({correct_rate_found_pct}% of cases with rate outside {min(VA_PARAMS['flag_rates_outside_pct'])}% of allowed amount)\n"
            )

    logger_m.warning("Calculated metrics")


# ────────────────────────────────────────────────────────────────
# UPDATED calculate_test_metrics  (unchanged calculations)
# ────────────────────────────────────────────────────────────────
def metrics(
    test_data: pd.DataFrame,
    datetime_str: str,
    output_filename: str,
    logger_m: logging.Logger,
):
    logger_m.info("Calculating metrics")
    num_test_cases = len(test_data)

    # Determine missing source data
    has_missing_source_data = "missing_source_data" in test_data.columns
    missing_source_data = (
        test_data[test_data["missing_source_data"] == True]
        if has_missing_source_data
        else pd.DataFrame()
    )

    # Rows not missing source data
    non_missing_data = test_data[
        test_data["missing_source_data"] == False
    ]  # if has_missing_source_data else test_data
    # Determine test_data_with_rates
    test_data_with_rates = non_missing_data[
        non_missing_data["retrieved_rate_final"].notna()
    ]
    # NOTE: SINCE NON_MISSING_DATA IS NOT USED, THIS SHOULD BE THE SAME AS:
    # test_data_with_rates = test_data[test_data["retrieved_rate_final"].notna()]

    # Ensure rate comparison columns exist if needed
    use_dollar_error = VA_PARAMS["use_dollar_error"]
    if use_dollar_error:
        min_dollar = min(VA_PARAMS["flag_rates_outside_dollar"])
        col_name = f"rate_within_{min_dollar}dollar"
        if col_name not in test_data.columns:
            test_data[col_name] = (
                abs(test_data["retrieved_rate_final"] - test_data["allowed_amt"])
                <= min_dollar
            )
    else:
        min_pct = min(VA_PARAMS["flag_rates_outside_pct"])
        col_name = f"rate_within_{min_pct}pct"
        if col_name not in test_data.columns:
            test_data[
                col_name
            ] = (  # treat $0 allowed_amt as $0.001 to avoid dividing by zero
                abs(test_data["retrieved_rate_final"] - test_data["allowed_amt"])
                / test_data["allowed_amt"].clip(lower=0.001)
                <= min_pct / 100
            )

    # Layer 1: Match or not (over all rows)
    exact_match = test_data_with_rates[
        test_data_with_rates["retrieved_rate_final"].round(2)
        == test_data_with_rates["allowed_amt"].round(2)
    ]
    incorrect_cases = test_data[~test_data.index.isin(exact_match.index)]

    # Layer 2: Among incorrect, which have no retrieved rate
    incorrect_no_rate = incorrect_cases[incorrect_cases["retrieved_rate_final"].isna()]
    incorrect_with_rate = incorrect_cases[
        incorrect_cases["retrieved_rate_final"].notna()
    ]

    # Layer 3: No rate reason breakdown
    no_rate_missing_data = (
        incorrect_no_rate[incorrect_no_rate["missing_source_data"] == True]
        if has_missing_source_data
        else pd.DataFrame()
    )

    no_rate_no_missing_data = incorrect_no_rate.loc[
        incorrect_no_rate.index.difference(no_rate_missing_data.index)
    ]

    # Layer 3: For retrieved rate group, how far off?
    if use_dollar_error:
        bad_prediction = incorrect_with_rate[
            abs(
                incorrect_with_rate["retrieved_rate_final"]
                - incorrect_with_rate["allowed_amt"]
            )
            > min_dollar
        ]
        ok_prediction = incorrect_with_rate[
            abs(
                incorrect_with_rate["retrieved_rate_final"]
                - incorrect_with_rate["allowed_amt"]
            )
            <= min_dollar
        ]
    else:  # treat $0 allowed_amt as $0.001 to avoid dividing by zero
        bad_prediction = incorrect_with_rate[
            abs(
                incorrect_with_rate["retrieved_rate_final"]
                - incorrect_with_rate["allowed_amt"]
            )
            / incorrect_with_rate["allowed_amt"].clip(lower=0.001)
            > min_pct / 100
        ]
        ok_prediction = incorrect_with_rate[
            abs(
                incorrect_with_rate["retrieved_rate_final"]
                - incorrect_with_rate["allowed_amt"]
            )
            / incorrect_with_rate["allowed_amt"].clip(lower=0.001)
            <= min_pct / 100
        ]

    # Layer 4: Among bad predictions, how many had correct rate somewhere
    correct_rate_found_true = bad_prediction[
        bad_prediction["correct_rate_found"] == True
    ]
    correct_rate_found_false = bad_prediction[
        bad_prediction["correct_rate_found"] != True
    ]  # any row without an explicitly True correct_rate_found is assumed to fall into the "not available" bucket

    # Layer 5: Under vs over prediction (only for correct_rate_found_true group)
    under_predictions = correct_rate_found_true[
        correct_rate_found_true["retrieved_rate_final"]
        < correct_rate_found_true["allowed_amt"]
    ]
    over_predictions = correct_rate_found_true[
        correct_rate_found_true["retrieved_rate_final"]
        > correct_rate_found_true["allowed_amt"]
    ]

    # ── TXT REPORT ──────────────────────────────────────────────────────────
    metrics_filepath = os.path.join(
        PY_DIR,
        "..",
        "test_cases",
        "output",
        datetime_str,
        output_filename,
    )
    os.makedirs(os.path.dirname(metrics_filepath), exist_ok=True)

    with open(metrics_filepath, "w") as f:
        f.write(f"Metrics for test cases run on: {datetime_str}\n\n")
        f.write(f"No. of test cases: {num_test_cases}\n")

        f.write("\nLayer 1: Overall Accuracy\n")
        f.write(
            f"- Exact matches: {len(exact_match)} ({round(len(exact_match)/num_test_cases*100, 2)}%)\n"
        )
        f.write(
            f"- Incorrect matches: {num_test_cases - len(exact_match)} ({round((num_test_cases - len(exact_match))/num_test_cases*100, 2)}%)\n"
        )

        f.write("\nLayer 2: Among Incorrect Predictions\n")
        f.write(f"- No rate retrieved: {len(incorrect_no_rate)}\n")
        f.write(f"- Rate retrieved but not correct: {len(incorrect_with_rate)}\n")

        f.write("\nLayer 3: Reason for No Rate\n")
        f.write(f"- Missing source data: {len(missing_source_data)}\n")
        # actionable
        f.write(
            f"- Non-missing but no rate retrieved (*actionable*): {len(no_rate_no_missing_data)}\n"
        )

        f.write("\nLayer 3: Accuracy of Retrieved Rates\n")
        # no longer actionable
        f.write(f"- Poor predictions (outside threshold): {len(bad_prediction)}\n")
        f.write(f"- OK predictions (within threshold): {len(ok_prediction)}\n")
        if use_dollar_error:
            f.write(
                f"Note: threshold used = ${min_dollar} away from allowed_amt (based on dollar error)\n"
            )
        else:
            f.write(
                f"Note: threshold used = {min_pct}% away from allowed_amt (based on percentage error)\n"
            )

        f.write(
            "\nLayer 4: Correct Rate Availability (for Layer 3: Poor Predictions)\n"
        )
        # actionable
        f.write(
            f"- Found correct rate but not used (*actionable*): {len(correct_rate_found_true)}\n"
        )
        # actionable (NEW)
        f.write(
            f"- Correct rate not available (*actionable*): {len(correct_rate_found_false)}\n"
        )

        f.write("\nLayer 5: Breakdown of 'Correct rate but not used'\n")
        f.write(f"- Under predictions: {len(under_predictions)}\n")
        f.write(f"- Over predictions: {len(over_predictions)}\n")

    logger_m.warning("Calculated V1 layered metrics")

    # ── PLOT ────────────────────────────────────────────────────────────────
    pct = lambda n: round(n / num_test_cases * 100, 1)
    metrics_pct = {
        "correct": pct(len(exact_match)),
        "incorrect": pct(num_test_cases - len(exact_match)),
        "no_rate": pct(len(incorrect_no_rate)),
        "rate_retrieved": pct(len(incorrect_with_rate)),
        "missing_data": pct(len(missing_source_data)),
        "has_data_no_rate": pct(len(no_rate_no_missing_data)),
        "bad_pred": pct(len(bad_prediction)),
        "ok_pred": pct(len(ok_prediction)),
        "correct_not_selected": pct(len(correct_rate_found_true)),
        "correct_not_available": pct(len(correct_rate_found_false)),
        "under": pct(len(under_predictions)),
        "over": pct(len(over_predictions)),
    }
    threshold_label = f"${min_dollar}" if use_dollar_error else f"{min_pct}%"

    if CFG["metrics"]["generate_plot"]:
        plot_path = os.path.join(
            PY_DIR,
            "..",
            "test_cases",
            "output",
            datetime_str,
            "layered_metrics_plot.png",
        )
        os.makedirs(os.path.dirname(plot_path), exist_ok=True)
        plot_layered_metrics(metrics_pct, threshold_label, plot_path)
        logger_m.info(f"Generated layered metrics plot --> {plot_path}")

    # ── Deep-dive analysis ─────────────────────────────────────
    deep_cfg = CFG["metrics"]["deep_dive"]
    if deep_cfg["enabled"]:
        df_analysis = test_data

        # names for the three actionable buckets come from config.json
        b1, b2, b3 = deep_cfg["buckets"]

        df_analysis["bucket"] = np.select(
            [
                df_analysis.index.isin(
                    no_rate_no_missing_data.index
                ),  # Has data / no rate
                df_analysis.index.isin(
                    correct_rate_found_true.index
                ),  # Correct rate found
                df_analysis.index.isin(
                    correct_rate_found_false.index
                ),  # Correct rate not found
                df_analysis.index.isin(exact_match.index),  # Perfect match
            ],
            [
                b1,  # "Has source data, but didn't retrieve rate"
                b2,  # "Correct rate available, but not selected"
                b3,  # "Correct rate not available"
                "Correct rate",
            ],
            default="Other",
        )

        deep_out = os.path.join(
            PY_DIR, "..", "test_cases", "output", datetime_str, "deep_dive"
        )
        deep_dive_tables(df_analysis, "bucket", deep_cfg, deep_out, logger_m)
