import os
import logging
import pandas as pd
from google.cloud import bigquery as bq
from core.constants import QUERY_DIR, CFG, SQL_COL_INFO
from core.utils import replace_data_loc_params
from core.log_helpers import log_query


def query_validation_input(query_filepath, logger: logging.Logger) -> pd.DataFrame:
    query_str = replace_data_loc_params(query_filepath)
    query_parameters = [
        bq.ScalarQueryParameter(
            "row_num_min", "INT64", CFG["validation"]["input_bq_row_num_range"][0]
        ),
        bq.ScalarQueryParameter(
            "row_num_max", "INT64", CFG["validation"]["input_bq_row_num_range"][1]
        ),
    ]
    log_query(query_str, query_parameters, logger)
    query_job_config = bq.QueryJobConfig(query_parameters=query_parameters)
    client = bq.Client()
    query_result = client.query(query_str, query_job_config).to_dataframe()
    return query_result


def query_pos_cd(
    svc_cd_val, svc_type_cd_val, logger: logging.Logger, client: bq.Client
):
    pos_cd_validation_file = CFG["query_files"]["validation_queries"][
        "pos_cd_validation"
    ]
    pos_cd_validation_filepath = os.path.join(QUERY_DIR, pos_cd_validation_file)
    pos_cd_validation_query = replace_data_loc_params(pos_cd_validation_filepath)
    validation_query_params = [
        bq.ScalarQueryParameter(
            SQL_COL_INFO["SERVICE_CD"][0],
            SQL_COL_INFO["SERVICE_CD"][1],
            svc_cd_val,
        ),
        bq.ScalarQueryParameter(
            SQL_COL_INFO["SERVICE_TYPE_CD"][0],
            SQL_COL_INFO["SERVICE_TYPE_CD"][1],
            svc_type_cd_val,
        ),
    ]
    logger.info("QUERYING SCM FOR POS CD")
    log_query(pos_cd_validation_query, validation_query_params, logger)
    query_job_config = bq.QueryJobConfig(query_parameters=validation_query_params)
    query_pos_cd_result = client.query(
        pos_cd_validation_query, query_job_config
    ).result()
    return query_pos_cd_result


def query_tins(
    pid_nbr_val,
    svc_loc_nbr_val,
    ntwk_id_val,
    logger: logging.Logger,
    client: bq.Client,
):
    get_tin_file = CFG["query_files"]["validation_queries"]["tin_query"]
    get_tin_file_filepath = os.path.join(QUERY_DIR, get_tin_file)
    get_tin_query = replace_data_loc_params(get_tin_file_filepath)
    tin_query_params = [
        bq.ScalarQueryParameter(
            SQL_COL_INFO["PROVIDER_IDENTIFICATION_NBR"][0],
            "INT64",
            int(pid_nbr_val),
        ),
        bq.ScalarQueryParameter(
            SQL_COL_INFO["SERVICE_LOCATION_NBR"][0],
            SQL_COL_INFO["SERVICE_LOCATION_NBR"][1],
            int(svc_loc_nbr_val),
        ),
        bq.ScalarQueryParameter(
            SQL_COL_INFO["NETWORK_ID"][0],
            SQL_COL_INFO["NETWORK_ID"][1],
            ntwk_id_val,
        ),
    ]
    logger.info("QUERYING PROVIDERS TABLE FOR TINs")
    log_query(get_tin_query, tin_query_params, logger)
    query_job_config = bq.QueryJobConfig(query_parameters=tin_query_params)
    query_tins_result = client.query(get_tin_query, query_job_config).result()
    return query_tins_result


def query_pbgs(
    pid_nbr_val,
    svc_loc_nbr_val,
    ntwk_id_val,
    logger: logging.Logger,
    client: bq.Client,
):
    get_pbgs_file = CFG["query_files"]["validation_queries"]["pbg_query"]
    get_pbgs_file_filepath = os.path.join(QUERY_DIR, get_pbgs_file)
    get_pbgs_query = replace_data_loc_params(get_pbgs_file_filepath)
    pbg_query_params = [
        bq.ScalarQueryParameter(
            SQL_COL_INFO["PROVIDER_IDENTIFICATION_NBR"][0],
            "INT64",
            int(pid_nbr_val),
        ),
        bq.ScalarQueryParameter(
            SQL_COL_INFO["SERVICE_LOCATION_NBR"][0],
            SQL_COL_INFO["SERVICE_LOCATION_NBR"][1],
            int(svc_loc_nbr_val),
        ),
        bq.ScalarQueryParameter(
            SQL_COL_INFO["NETWORK_ID"][0],
            SQL_COL_INFO["NETWORK_ID"][1],
            ntwk_id_val,
        ),
    ]
    logger.info("QUERYING PROVIDERS TABLE FOR PBGs")
    log_query(get_pbgs_query, pbg_query_params, logger)
    query_job_config = bq.QueryJobConfig(query_parameters=pbg_query_params)
    query_pbgs_result = client.query(get_pbgs_query, query_job_config).result()
    return query_pbgs_result
