import os
import time
import logging
import pandas as pd
import numpy as np
from typing import Dict
from math import log10
from google.cloud import bigquery as bq
from core.constants import CFG, PY_DIR, QUERY_DIR, VA_PARAMS
from core.utils import (
    cast_dtypes,
    add_output_col,
    get_run_id,
)
from modules.validation.validation_bq import (
    query_pos_cd,
    query_tins,
    query_pbgs,
    query_validation_input,
)


def read_data_from_csv_validation() -> pd.DataFrame:
    test_data_dir = os.path.join(PY_DIR, "..", "test_cases", "working")
    test_data_filepath = os.path.join(
        test_data_dir, CFG["validation"]["input_csv_file"]
    )

    if CFG["validation"]["csv_input_parameters"]["run_zero_indexed_row"]:
        test_data = pd.read_csv(
            test_data_filepath,
            na_values=["", " ", "NA", "N/A", "null"],
            quotechar='"',
            skiprows=list(
                range(
                    1,
                    CFG["validation"]["csv_input_parameters"]["run_zero_indexed_row"]
                    + 1,
                )
            ),
            nrows=1,
        )
    elif CFG["validation"]["csv_input_parameters"]["run_rows_from_top"]:
        test_data = pd.read_csv(
            test_data_filepath,
            na_values=["", " ", "NA", "N/A", "null"],
            quotechar='"',
            nrows=CFG["validation"]["csv_input_parameters"]["run_rows_from_top"],
        )
    elif CFG["validation"]["csv_input_parameters"]["skip_rows"]:
        test_data = pd.read_csv(
            test_data_filepath,
            na_values=["", " ", "NA", "N/A", "null"],
            quotechar='"',
            skiprows=list(
                range(1, CFG["validation"]["csv_input_parameters"]["skip_rows"] + 1)
            ),
        )
    else:
        test_data = pd.read_csv(
            test_data_filepath,
            na_values=["", " ", "NA", "N/A", "null"],
            quotechar='"',
        )
    return test_data


def read_data_from_bq_validation(logger: logging.Logger) -> pd.DataFrame:
    query_filepath = os.path.join(
        QUERY_DIR,
        "input_queries",
        CFG["query_files"]["input_queries"]["validation_input"],
    )
    query_result = query_validation_input(query_filepath, logger)
    return query_result


def preprocess_data_for_validation(
    test_data: pd.DataFrame,
    table_id: str,
    datetime_str: str,
    csv_to_sql_info_relevant: dict,
    sql_to_csv_relevant: dict,
    logger_m: logging.Logger,
) -> pd.DataFrame:

    test_data = cast_dtypes(test_data, logger_m)

    # add output cols
    test_data = add_output_col(0, test_data, "missing_source_data", None, None)
    test_data = add_output_col(0, test_data, "pos_cd_validation_pass", None, None)
    test_data = add_output_col(0, test_data, "pbgs_validation_pass", None, None)
    test_data = add_output_col(0, test_data, "retrieved_tins", "", "string")
    test_data = add_output_col(0, test_data, "retrieved_pbgs", "", "string")
    for pct in VA_PARAMS["flag_rates_outside_pct"][::-1]:
        test_data = add_output_col(0, test_data, f"rate_within_{pct}pct", None, None)
    test_data = add_output_col(0, test_data, "retrieved_rate_final", np.nan, "float64")
    test_data = add_output_col(0, test_data, "retrieved_rate_type", "", "string")
    test_data = add_output_col(
        0, test_data, "retrieved_rate_unit_or_pct", np.nan, "float64"
    )
    test_data = add_output_col(0, test_data, "payment_method_cd", "", "string")
    test_data = add_output_col(0, test_data, "claims_std_nonstd", "", "string")
    test_data = add_output_col(0, test_data, "validation_comments", "", "string")
    test_data = add_output_col(0, test_data, "validation_log_id", 0, "int64")

    if VA_PARAMS["to_bq"] is not False:
        run_id = get_run_id("validation", table_id, logger_m)
    else:
        run_id = 0
    test_data = add_output_col(0, test_data, "validation_run_id", run_id, "int64")
    test_data = add_output_col(
        0, test_data, "validation_run_dt", datetime_str, "string"
    )
    if "row_num" in test_data.columns:
        test_data.insert(0, "row_num", test_data.pop("row_num"))

    dtype_map = {"INT64": int, "STRING": str, "": int}
    for csv_col, sql_info in csv_to_sql_info_relevant.items():
        # if col dtype is float, first convert to int to remove decimal places
        if test_data[csv_col].dtype == "float64":
            # Fill NA/inf values with 0 before converting to int
            test_data[csv_col] = test_data[csv_col].fillna(0)
            test_data[csv_col] = test_data[csv_col].replace([np.inf, -np.inf], 0)
            test_data[csv_col] = test_data[csv_col].astype(int)
        # convert dtype for relevant csv columns
        test_data[csv_col] = test_data[csv_col].astype(dtype_map[sql_info[1]])
        # trim all str cols
        if sql_info[1] == "STRING":
            test_data[csv_col] = test_data[csv_col].str.strip()
            test_data[csv_col] = test_data[csv_col].replace("nan", "")
            test_data[csv_col] = test_data[csv_col].fillna("")

    # pad NETWORK_ID with 0s to length 5
    ntwk_id_col = sql_to_csv_relevant["NETWORK_ID"]
    test_data[ntwk_id_col] = test_data[ntwk_id_col].str.zfill(5)
    # if NETWORK_ID is 00000 (originally 0) replace with null
    test_data[ntwk_id_col] = test_data[ntwk_id_col].replace("00000", "")

    # if SPECIALTY_CD is 0 or 00000 replace with null
    specialty_cd_col = sql_to_csv_relevant["SPECIALTY_CD"]
    test_data[specialty_cd_col] = test_data[specialty_cd_col].replace("0", "")
    test_data[specialty_cd_col] = test_data[specialty_cd_col].replace("00000", "")
    # test_data[specialty_cd_col] = test_data[specialty_cd_col].fillna("")

    # pad PLACE_OF_SERVICE_CD with 0s to length 2
    pos_cd_col = sql_to_csv_relevant["PLACE_OF_SERVICE_CD"]
    test_data[pos_cd_col] = test_data[pos_cd_col].str.zfill(2)

    return test_data


def validate_required_params(
    row, csv_to_sql_info_relevant: dict, comments: str, skip_rate_query: bool
):
    for csv_col, sql_info in csv_to_sql_info_relevant.items():
        if sql_info[2] == "REQUIRED" and (pd.isna(row[csv_col]) or row[csv_col] == ""):
            comments += f"SKIPPED: Column {csv_col} is required but has null value.\n"
            skip_rate_query = True
            break
    return comments, skip_rate_query


def validate_network_id(
    row,
    sql_to_csv_relevant: dict,
    comments: str,
    skip_rate_query: bool,
):
    ntwk_id = row[sql_to_csv_relevant["NETWORK_ID"]]
    if not ntwk_id.isdigit() and ntwk_id != "":
        comments += f"SKIPPED: NETWORK_ID {ntwk_id} contains non-digit characters.\n"
        skip_rate_query = True
    return comments, skip_rate_query


def validate_pid_nbr(
    row, sql_to_csv_relevant: dict, comments: str, skip_rate_query: bool
):
    # validate pid_nbr len == 7
    pid_nbr_val = row[sql_to_csv_relevant["PROVIDER_IDENTIFICATION_NBR"]]
    if int(log10(pid_nbr_val)) + 1 != 7:
        # remove last 2 digits if pid_nbr is 9 digits long and ends with 09
        if int(log10(pid_nbr_val)) + 1 == 9 and str(pid_nbr_val)[-2:] == "09":
            comments += f"PID NBR {pid_nbr_val} stripped of last 2 digits ('09').\n"
            # remove last 2 digits
            row[sql_to_csv_relevant["PROVIDER_IDENTIFICATION_NBR"]] //= 100
        else:
            comments += f"SKIPPED: PID NBR {pid_nbr_val} is not 7 digits long.\n"
            skip_rate_query = True
    return comments, skip_rate_query


def validate_pos_cd(row, sql_to_csv_relevant: dict, logger, client: bq.Client):
    svc_cd_val = row[sql_to_csv_relevant["SERVICE_CD"]]
    svc_type_cd_val = row[sql_to_csv_relevant["SERVICE_TYPE_CD"]]
    orig_pos_cd_val = row[sql_to_csv_relevant["PLACE_OF_SERVICE_CD"]]
    validation_query_result = query_pos_cd(svc_cd_val, svc_type_cd_val, logger, client)
    comment = ""
    pos_cd_validation_pass = True
    if validation_query_result.total_rows == 0:
        comment = f"SKIPPED: No POS code found in Service Code Master for Service Code {svc_cd_val}.\n"
        pos_cd_validation_pass = False
    else:
        validation_pos_cd = next(validation_query_result)["supporting_pos_cd"]
        if orig_pos_cd_val != validation_pos_cd:
            comment = f"SKIPPED: POS code validation failed. Value in Service Code Master is {validation_pos_cd} while value in CSV is {orig_pos_cd_val}.\n"
            pos_cd_validation_pass = False
    return comment, pos_cd_validation_pass


def validate_tins(
    row, sql_to_csv_relevant: Dict[str, str], logger: logging.Logger, client: bq.Client
):
    pid_nbr_val = row[sql_to_csv_relevant["PROVIDER_IDENTIFICATION_NBR"]]
    svc_loc_nbr_val = row[sql_to_csv_relevant["SERVICE_LOCATION_NBR"]]
    ntwk_id_val = row[sql_to_csv_relevant["NETWORK_ID"]]
    query_tins_result = query_tins(
        pid_nbr_val, svc_loc_nbr_val, ntwk_id_val, logger, client
    )
    tins = ""
    comment = f"No TINs found in providers table.\n"
    if (
        query_tins_result
        and query_tins_result.total_rows
        and query_tins_result.total_rows > 0
    ):
        tins = [
            tin_row_result["TAX_IDENTIFICATION_NBR"]
            for tin_row_result in query_tins_result
            if tin_row_result["TAX_IDENTIFICATION_NBR"] is not None
        ]
        if len(tins) > 0:
            comment = ""
        else:
            tins = ""
            comment = f"Only NULL TINs found in providers table.\n"

    return tins, comment


def validate_pbgs(row, sql_to_csv_relevant: dict, logger, client: bq.Client):
    pid_nbr_val = row[sql_to_csv_relevant["PROVIDER_IDENTIFICATION_NBR"]]
    svc_loc_nbr_val = row[sql_to_csv_relevant["SERVICE_LOCATION_NBR"]]
    ntwk_id_val = row[sql_to_csv_relevant["NETWORK_ID"]]
    query_pbgs_result = query_pbgs(
        pid_nbr_val, svc_loc_nbr_val, ntwk_id_val, logger, client
    )
    pbgs = ""
    comment = f"SKIPPED: No PBGs found in providers table.\n"
    pbgs_validation_pass = False
    if (
        query_pbgs_result
        and query_pbgs_result.total_rows
        and query_pbgs_result.total_rows > 0
    ):
        pbgs_validation_pass = True
        pbgs = [
            pbg_row_result["PROVIDER_BUSINESS_GROUP_NBR"]
            for pbg_row_result in query_pbgs_result
            if pbg_row_result["PROVIDER_BUSINESS_GROUP_NBR"] is not None
        ]
        if len(pbgs) > 0:
            comment = ""
        else:
            pbgs = None
            comment = (
                f"Only NULL PBGs found in providers table; treating as standard.\n"
            )

    return pbgs, comment, pbgs_validation_pass


def log_validation_time(
    logger: logging.Logger, log_time_every, test_time, test_time_last_n, i, process
):
    now = time.time()
    elapsed_test_time = now - test_time
    elapsed_test_time_str = time.strftime("%H:%M:%S", time.gmtime(elapsed_test_time))
    avg_time_per_test = elapsed_test_time / (i + 1)
    avg_time_per_test_str = time.strftime("%H:%M:%S", time.gmtime(avg_time_per_test))
    elapsed_test_time_last_n = now - test_time_last_n
    avg_time_per_last_n_tests = elapsed_test_time_last_n / log_time_every
    avg_time_per_last_n_tests_str = time.strftime(
        "%H:%M:%S", time.gmtime(avg_time_per_last_n_tests)
    )

    logger.warning(
        f"Process {process} - Avg time per last {log_time_every} tests: {avg_time_per_last_n_tests_str}; Running avg time per test: {avg_time_per_test_str}; Total test runtime (across all processes): {elapsed_test_time_str}"
    )
    return now
