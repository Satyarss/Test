import os
import time
import math
import logging
import multiprocessing
import pandas as pd
from google.cloud import bigquery as bq
from core.custom_logger import CustomLogger
from core.utils import (
    initialize_column_maps,
    prep_rate_queries,
    write_slice_to_bq,
    save_to_csv,
    write_all_to_bq,
    checkpoint_conditions,
    checkpoint_conditions_last,
)
from core.bq import run_rate_query
from core.constants import CFG, VA_PARAMS
from modules.validation.validation_helpers import (
    read_data_from_csv_validation,
    read_data_from_bq_validation,
    preprocess_data_for_validation,
    validate_required_params,
    validate_network_id,
    validate_pid_nbr,
    validate_pos_cd,
    validate_pbgs,
    validate_tins,
    log_validation_time,
)


def validate_rows(
    test_data: pd.DataFrame,
    output_dir: str,
    output_filename: str,
    datetime_str,
    table_id: str,
    csv_to_sql_info_relevant,
    sql_to_csv_relevant,
    process: int,
) -> pd.DataFrame:

    logger = CustomLogger("validation", datetime_str, process)
    client = bq.Client()

    rate_query_str_map = prep_rate_queries()

    to_csv, to_bq, log_time_every = (
        VA_PARAMS["to_csv"],
        VA_PARAMS["to_bq"],
        VA_PARAMS["log_time_every"],
    )
    if to_csv is not False:
        output_filepath = os.path.join(output_dir, output_filename)
        test_data.iloc[:0].to_csv(output_filepath, mode="w", index=False)
    if log_time_every:
        test_time = time.time()
        test_time_last_n = test_time

    for i in range(len(test_data)):
        if i != 0:
            logger.info("\n\n\n\n")
        log_id = process * 10000 + i
        logger.info(f"validation_log_id: {log_id} (row {i+1} of {len(test_data)})")
        test_data.loc[i, "validation_log_id"] = log_id
        comments = ""
        skip_rates_table_query = False  # should be the only time this is set to False

        # STEP 0: validate required params
        logger.debug(f"{process} - step 0")
        comments, skip_rates_table_query = validate_required_params(
            test_data.iloc[i],
            csv_to_sql_info_relevant,
            comments,
            skip_rates_table_query,
        )
        logger.debug(f"{process} - step 0.1")
        comments, skip_rates_table_query = validate_network_id(
            test_data.iloc[i],
            sql_to_csv_relevant,
            comments,
            skip_rates_table_query,
        )
        logger.debug(f"{process} - step 0.2")
        comments, skip_rates_table_query = validate_pid_nbr(
            test_data.iloc[i],
            sql_to_csv_relevant,
            comments,
            skip_rates_table_query,
        )

        # STEP 1: Check if rate is in claims table
        logger.debug(f"{process} - step 1")
        rate_qry_result = run_rate_query(
            test_data.iloc[i],
            "claims",
            rate_query_str_map,
            sql_to_csv_relevant,
            logger,
            client,
        )

        if (
            len(rate_qry_result) > 0
            and rate_qry_result.iloc[0]["max_rate"] is not None
            and pd.notna(rate_qry_result.iloc[0]["max_rate"])
        ):
            query_type = "C"
            test_data.loc[i, "claims_std_nonstd"] = query_type
            skip_rates_table_query = True
        else:

            # STEP 2: validate pos code
            logger.debug(f"{process} - step 2")
            pos_cd_comment, pos_cd_validation_pass = validate_pos_cd(
                test_data.iloc[i], sql_to_csv_relevant, logger, client
            )
            comments += pos_cd_comment
            test_data.loc[i, "pos_cd_validation_pass"] = pos_cd_validation_pass
            if not pos_cd_validation_pass:  # POS code missing or mismatch
                skip_rates_table_query = True
                test_data.loc[i, "missing_source_data"] = True
                test_data.loc[i, "retrieved_pbgs"] = ""
            else:

                # STEP 3: obtain PBGs
                logger.debug(f"{process} - step 3")
                pbgs, pbgs_comment, pbgs_validation_pass = validate_pbgs(
                    test_data.iloc[i], sql_to_csv_relevant, logger, client
                )
                comments += pbgs_comment
                test_data.loc[i, "pbgs_validation_pass"] = pbgs_validation_pass
                if pbgs is not None:
                    test_data.loc[i, "retrieved_pbgs"] = str(pbgs)
                    if pbgs == "":  # PBGs are missing, unknown if S/N
                        skip_rates_table_query = True
                else:
                    test_data.loc[i, "retrieved_pbgs"] = ""

                # STEP 4: obtain TINs
                logger.debug(f"{process} - step 4")
                tins, tin_comment = validate_tins(
                    test_data.iloc[i], sql_to_csv_relevant, logger, client
                )
                test_data.loc[i, "retrieved_tins"] = str(tins)
                comments += tin_comment

        if not skip_rates_table_query:

            if pbgs is None:

                # STEP 5: try standard query
                logger.debug(f"{process} - step 5")
                query_type = "S"
                rate_qry_result = run_rate_query(
                    test_data.iloc[i],
                    "standard",
                    rate_query_str_map,
                    sql_to_csv_relevant,
                    logger,
                    client,
                )
            else:

                query_type = "N"

                # STEP 5.1: try nonstandard complex query
                logger.debug(f"{process} - step 5.1")
                rate_qry_result = run_rate_query(
                    test_data.iloc[i],
                    "nonstandard_complex",
                    rate_query_str_map,
                    sql_to_csv_relevant,
                    logger,
                    client,
                )

                if (
                    len(rate_qry_result) == 0
                    or rate_qry_result.iloc[0]["max_rate"] is None
                    or pd.isna(rate_qry_result.iloc[0]["max_rate"])
                ):

                    # STEP 5.2: try nonstandard default query
                    logger.debug(f"{process} - step 5.2")
                    rate_qry_result = run_rate_query(
                        test_data.iloc[i],
                        "nonstandard_default",
                        rate_query_str_map,
                        sql_to_csv_relevant,
                        logger,
                        client,
                    )

            test_data.loc[i, "claims_std_nonstd"] = query_type

        if (
            len(rate_qry_result) == 0
            or rate_qry_result.iloc[0]["max_rate"] is None
            or pd.isna(rate_qry_result.iloc[0]["max_rate"])
        ):
            logger.info(f"No rate found")
        else:

            # STEP 6: record retrieved rate
            logger.debug(f"{process} - step 6")
            rate_unit_or_pct = rate_qry_result.iloc[0]["max_rate"]
            test_data.loc[i, "retrieved_rate_unit_or_pct"] = round(rate_unit_or_pct, 5)
            if query_type == "N":
                test_data.loc[i, "payment_method_cd"] = rate_qry_result.iloc[0][
                    "payment_method_cd"
                ]
            if query_type == "N" and rate_qry_result.iloc[0]["payment_method_cd"] in [
                "PERBIL",
                "PERBLX",
                "PERINV",
                "PBLXDL",
            ]:
                rate_pct = rate_unit_or_pct
                test_data.loc[i, "retrieved_rate_type"] = "pct"
                test_data.loc[i, "retrieved_rate_final"] = round(
                    (rate_pct / 100) * test_data.loc[i, "billed_amt"], 5
                )
            elif "unit_cnt" in test_data.columns:
                rate_unit = rate_unit_or_pct
                test_data.loc[i, "retrieved_rate_type"] = "unit"
                test_data.loc[i, "retrieved_rate_final"] = round(
                    rate_unit * test_data.loc[i, "unit_cnt"], 5
                )
            else:
                rate_unit = rate_unit_or_pct
                test_data.loc[i, "retrieved_rate_final"] = round(rate_unit, 5)

            # STEP 7: check if rate is within flag_outside_pct% of allowed amount
            for pct in VA_PARAMS["flag_rates_outside_pct"]:
                logger.debug(f"{process} - step 7")
                test_data.loc[i, f"rate_within_{pct}pct"] = (
                    abs(
                        test_data.loc[i, "retrieved_rate_final"]
                        - test_data.loc[i, "allowed_amt"]
                    )
                    / max(test_data.loc[i, "allowed_amt"], 0.001)
                    #  treat $0 allowed_amts as $0.001
                    <= pct / 100
                )

        logger.debug(f"{process} - step 8")
        test_data.loc[i, "validation_comments"] = comments[:-1]

        if checkpoint_conditions(to_csv, i):
            save_to_csv(
                test_data.iloc[i + 1 - to_csv : i + 1].copy(),
                output_filepath,
                logger,
                i,
            )
        if checkpoint_conditions(to_bq, i):
            write_slice_to_bq(
                test_data.iloc[i + 1 - to_bq : i + 1].copy(), table_id, logger, i
            )
        if checkpoint_conditions(log_time_every, i):
            test_time_last_n = log_validation_time(
                logger,
                log_time_every,
                test_time,
                test_time_last_n,
                i,
                process,
            )

    len_data = len(test_data)
    if checkpoint_conditions_last(to_csv, len_data):
        last_start = len_data - len_data % to_csv if len_data > to_csv else 0
        save_to_csv(
            test_data.iloc[last_start:].copy(),
            output_filepath,
            logger,
            last_start,
            last=True,
        )
    if checkpoint_conditions_last(to_bq, len_data):
        last_start = len_data - len_data % to_bq if len_data > to_bq else 0
        write_slice_to_bq(
            test_data.iloc[last_start:].copy(), table_id, logger, last_start, last=True
        )

    CustomLogger.close_all_handlers(logger)
    if to_csv is True:
        test_data.to_csv(output_filepath, index=False)
    return test_data


def validate_rows_mp(
    datetime_str,
    output_dir,
    test_data: pd.DataFrame,
    table_id: str,
    csv_to_sql_info_relevant,
    sql_to_csv_relevant,
) -> pd.DataFrame:
    args_list = []
    chunk_size = math.ceil(len(test_data) / VA_PARAMS["processes"])
    for process in range(VA_PARAMS["processes"]):
        start_idx = process * chunk_size
        if process == VA_PARAMS["processes"] - 1:
            end_idx = len(test_data)
        else:
            end_idx = start_idx + chunk_size
        test_data_chunk = test_data.iloc[start_idx:end_idx].reset_index(drop=True)

        if CFG["validation"]["input_source"] == "csv":
            output_filename_process = f"{datetime_str}_{CFG['validation']['input_csv_file'][:-4]}_validation_{process+1}.csv"
        else:
            output_filename_process = f"{datetime_str}_bq_validation_{process+1}.csv"

        args_list.append(
            (
                test_data_chunk,
                output_dir,
                output_filename_process,
                datetime_str,
                table_id,
                csv_to_sql_info_relevant,
                sql_to_csv_relevant,
                process + 1,  # process id starts at 1
            )
        )

    with multiprocessing.Pool() as pool:
        test_data = pd.concat(pool.starmap(validate_rows, args_list)).reset_index(
            drop=True
        )

    if VA_PARAMS["to_csv"] is not False:
        # Combine outputs from all processes into a single csv file
        if CFG["validation"]["input_source"] == "csv":
            output_filename = f"{datetime_str}_{CFG['validation']['input_csv_file'][:-4]}_validation.csv"
        else:
            output_filename = f"{datetime_str}_bq_validation.csv"
        output_filepath = os.path.join(output_dir, output_filename)
        test_data.to_csv(output_filepath, index=False)

        for args in args_list:
            os.remove(os.path.join(args[1], args[2]))

    return test_data


def validation(datetime_str: str, output_dir: str, logger_m: logging.Logger):
    if CFG["validation"]["input_source"] == "csv":
        test_data = read_data_from_csv_validation()
    else:
        test_data = read_data_from_bq_validation(logger_m)
    csv_to_sql_info_relevant, sql_to_csv_relevant = initialize_column_maps(test_data)
    logger_m.info(f"SQL to CSV mapping: {sql_to_csv_relevant}")
    table_id = f"{CFG['data_locations']['project']}.{CFG['data_locations']['ds_dataset']}.{CFG['data_locations']['validation_output_table']}"
    test_data = preprocess_data_for_validation(
        test_data,
        table_id,
        datetime_str,
        csv_to_sql_info_relevant,
        sql_to_csv_relevant,
        logger_m,
    )

    logger_m.warning(f"Validation will be run on {len(test_data)} rows of data")
    if VA_PARAMS["processes"] == 1:
        logger_m.warning("Starting validation with single process")
        if CFG["validation"]["input_source"] == "csv":
            output_filename = f"{datetime_str}_{CFG['validation']['input_csv_file'][:-4]}_validation.csv"
        else:
            output_filename = f"{datetime_str}_bq_validation.csv"
        test_data = validate_rows(
            test_data,
            output_dir,
            output_filename,
            datetime_str,
            table_id,
            csv_to_sql_info_relevant,
            sql_to_csv_relevant,
            process=1,
        )
    else:
        logger_m.warning(
            f"Starting multiprocessing validation for {VA_PARAMS['processes']} processes"
        )
        test_data = validate_rows_mp(
            datetime_str,
            output_dir,
            test_data,
            table_id,
            csv_to_sql_info_relevant,
            sql_to_csv_relevant,
        )

    if VA_PARAMS["to_bq"] is True:
        write_all_to_bq(test_data, table_id, logger_m)
    CustomLogger.concat_logs("validation", datetime_str)
    logger_m.warning("Validation complete")
    return test_data
