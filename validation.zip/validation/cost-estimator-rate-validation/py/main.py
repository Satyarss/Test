import sys
import time
import traceback
from core.custom_logger import CustomLogger
from core.utils import (
    get_dt_and_dir,
    read_data_from_csv,
    read_data_from_bq_metrics,
    obtain_output_filename,
)
from core.log_helpers import log_execution_plan
from core.constants import VALIDATION, ANALYSIS, METRICS, CFG, VA_PARAMS
from modules.validation.validation import validation
from modules.analysis.analysis import analysis
from modules.analysis.analysis_helpers import read_data_from_bq_analysis
from modules.metrics import metrics, metrics_old

# EXECUTE THE FOLLOWING COMMAND BEFORE RUNNING (except for calculating metrics):
# gcloud auth application-default login
if __name__ == "__main__":
    start = time.time()
    if not (VALIDATION or ANALYSIS or METRICS):
        raise ValueError("No module(s) selected")
    if VA_PARAMS["to_bq"] is False and VA_PARAMS["to_csv"] is False:
        raise ValueError("No output selected")
    output_dir, datetime_str = get_dt_and_dir(start)
    logger_m = CustomLogger("main", datetime_str, 1)
    log_execution_plan(datetime_str, logger_m)

    try:
        if VALIDATION:
            test_data = validation(datetime_str, output_dir, logger_m)

        if ANALYSIS:
            if not VALIDATION:
                if CFG["analysis"]["input_source"] == "csv":
                    test_data, datetime_str_a = read_data_from_csv("analysis")
                else:
                    test_data = read_data_from_bq_analysis(logger_m)
                    datetime_str_a = CFG["analysis"]["input_bq_dt_str"]
            else:
                datetime_str_a = datetime_str

            analysis_output_filename = obtain_output_filename(
                "analysis", datetime_str_a
            )
            test_data = analysis(
                test_data, analysis_output_filename, datetime_str_a, logger_m
            )

        if METRICS:
            if not VALIDATION and not ANALYSIS:
                if CFG["metrics"]["input_source"] == "csv":
                    test_data, datetime_str_m = read_data_from_csv("metrics")
                else:
                    test_data = read_data_from_bq_metrics(logger_m)
                    datetime_str_m = CFG["metrics"]["input_bq_dt_str"]
            else:
                datetime_str_m = datetime_str

            metrics_output_filename = obtain_output_filename("metrics", datetime_str_m)
            metrics_old(
                test_data,
                datetime_str_m,
                metrics_output_filename[:-4] + "_old.txt",
                logger_m,
            )
            metrics(test_data, datetime_str_m, metrics_output_filename, logger_m)

    except Exception as e:
        stack_trace = traceback.format_exc()[:-1]
        logger_m.debug(f"Stack trace:\n{stack_trace}")
        raise

    finally:
        end = time.time()
        elapsed_time = time.strftime("%H:%M:%S", time.gmtime(end - start))
        if sys.exc_info()[0] is not None:
            logger_m.error(
                f"Terminated with an error after elapsed time: {elapsed_time}\n"
            )
        else:
            logger_m.warning(f"Total elapsed time: {elapsed_time}\n")
