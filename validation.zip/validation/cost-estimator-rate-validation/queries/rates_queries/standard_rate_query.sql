/*
DATA LOCATION PARAMETERS:
  @project
  @dec_dataset
  @dataset
  @providers_table
  @rates_table

COLUMN PARAMETERS (param, type, example, required/optional):
  @pid_nbr          INT64     6219448       REQUIRED
  @tin_nbr          STRING    '812751049'   OPTIONAL
  @tin_fmt_cd       STRING    'E'           OPTIONAL
  @network_id       STRING    '00124'       REQUIRED
  @svc_loc_nbr      INT64     4855742       REQUIRED
  @provider_type_cd STRING    'PAS'         OPTIONAL
  @specialty_cd     STRING    '90380'       OPTIONAL
  @pos_cd           STRING    '12'          REQUIRED
  @service_cd       STRING    'E1357'       REQUIRED
  @service_type_cd  STRING    'HCPC'        REQUIRED

FOR PY SCRIPT TO PROPERLY READ THIS QUERY,
THERE MUST BE NO MORE THAN 1 COLUMN PARAMETER PER LINE.
IF AN OPTIONAL PARAMETER VALUE IS NOT IN CSV,
ANY LINE WITH THAT PARAMETER WILL BE COMMENTED OUT FROM THIS QUERY.
*/
-- STANDARD
SELECT
  MAX(r.rate) AS max_rate
FROM
  `@project.@dec_dataset.@providers_table` p
JOIN
  `@project.@dec_dataset.@rates_table` r
ON
  p.PRODUCT_CD = r.PRODUCT_CD
  AND p.EPDB_GEOGRAPHIC_AREA_CD = r.GEOGRAPHIC_AREA_CD
  AND p.RATING_SYSTEM_CD = r.RATE_SYSTEM_CD
  AND (p.PROVIDER_BUSINESS_GROUP_NBR = r.PROVIDER_BUSINESS_GROUP_NBR
      OR (p.PROVIDER_BUSINESS_GROUP_NBR IS NULL AND r.PROVIDER_BUSINESS_GROUP_NBR IS NULL))
WHERE
  p.PROVIDER_IDENTIFICATION_NBR = @pid_nbr
  AND p.TAX_IDENTIFICATION_NBR = @tin_nbr
  AND p.TAX_IDENTIFICATION_FORMAT_CD = @tin_fmt_cd
  AND p.NETWORK_ID = @network_id
  AND p.SERVICE_LOCATION_NBR = @svc_loc_nbr
  AND p.PROVIDER_TYPE_CD = @provider_type_cd
  AND TRIM(p.SPECIALTY_CD) = @specialty_cd
  AND r.PLACE_OF_SERVICE_CD = @pos_cd
  AND r.SERVICE_CD = @service_cd
  AND r.SERVICE_TYPE_CD = @service_type_cd
;