SELECT DISTINCT
  TAX_IDENTIFICATION_NBR
FROM
  `@project.@dec_dataset.@providers_table` p
WHERE
  p.PROVIDER_IDENTIFICATION_NBR = @pid_nbr
  AND p.SERVICE_LOCATION_NBR = @svc_loc_nbr
  AND NETWORK_ID = @network_id
;