SELECT * FROM `@project.@ds_dataset.@validation_input_table`
WHERE row_num >= @row_num_min AND row_num < @row_num_max