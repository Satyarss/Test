SELECT * FROM `@project.@ds_dataset.@analysis_output_table`
WHERE validation_run_dt = @metrics_input_dt_str
AND analysis_run_id = (
    SELECT MAX(analysis_run_id)
    FROM `@project.@ds_dataset.@analysis_output_table`
    WHERE validation_run_dt = @metrics_input_dt_str
    )