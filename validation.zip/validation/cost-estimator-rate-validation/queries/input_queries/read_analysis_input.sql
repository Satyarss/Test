SELECT * FROM `@project.@ds_dataset.@validation_output_table`
WHERE validation_run_dt = @analysis_input_dt_str