SELECT supporting_pos_cd
FROM `@project.@dataset.@scm_table`
WHERE TRIM(primary_svc_cd) = @service_cd
AND servc_type = @service_type_cd
AND in_scope_ind = 1
;