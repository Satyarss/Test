SELECT *
FROM `edp-prod-hcbstorage.edp_hcb_costtpy_cnsv.TIC_SCM_FEE_SERVICE_LINE_DETAIL_VIEW`
WHERE qualifier_id IN (
    SELECT qualifier_id
    FROM `edp-prod-hcbstorage.edp_hcb_costtpy_cnsv.TIC_SCM_FEE_SERVICE_QUALIFIER_DETAIL_VIEW`
    WHERE PROVIDER_BUSINESS_GROUP_NBR IN UNNEST(@pbg_nbrs)
)
;