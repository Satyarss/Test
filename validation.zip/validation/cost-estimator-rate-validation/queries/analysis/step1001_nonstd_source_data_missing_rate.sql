SELECT
    *
FROM
    `edp-prod-hcbstorage.edp_hcb_costtpy_cns.TIC_SCM_FEE_SERVICE_LINE_DETAIL` ld
JOIN
    `edp-prod-hcbstorage.edp_hcb_costtpy_cns.TIC_SCM_FEE_SERVICE_QUALIFIER_DETAIL` qd
    ON qd.QUALIFIER_ID = CAST(ld.QUALIFIER_ID AS INT)
JOIN
    `edp-prod-hcbstorage.edp_hcb_costtpy_cns.TIC_SCSR_SERVICE_AFFILIATION` aff
    ON ld.SERVICE_GROUP_CD = aff.OWNER_SERVICE_CD
    AND ld.SERVICE_GROUP_TYPE_CD = aff.OWNER_SERVICE_TYPE_CD
JOIN
    `edp-prod-hcbstorage.edp_hcb_costtpy_cns.TIC_EPDB_CONTRACT_PROVIDER_BUSINESS_GROUP` pbgnbr
    ON pbgnbr.PROVIDER_BUSINESS_GROUP_NBR = qd.PROVIDER_BUSINESS_GROUP_NBR
JOIN
    `edp-prod-hcbstorage.edp_hcb_costtpy_cns.TIC_SCM_FEE_SERVICE_DETAIL` sd
    ON sd.STRUCTURED_STATEMENT_ID = ld.STRUCTURED_STATEMENT_ID
WHERE
    qd.PROVIDER_BUSINESS_GROUP_NBR IN UNNEST(@pbg_nbrs)
    AND aff.MEMBER_SERVICE_CD = @service_cd
    AND aff.MEMBER_SERVICE_TYPE_CD = @service_type_cd
;