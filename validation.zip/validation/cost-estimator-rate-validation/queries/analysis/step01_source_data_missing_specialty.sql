SELECT *
FROM
    `edp-prod-hcbstorage.edp_hcb_costtpy_cns.TIC_EPDB_SPECIALTY`
WHERE
    PROVIDER_IDENTIFICATION_NBR = @pid_nbr
    AND NETWORK_ID = @network_id
    AND SPECIALTY_CD = @specialty_cd