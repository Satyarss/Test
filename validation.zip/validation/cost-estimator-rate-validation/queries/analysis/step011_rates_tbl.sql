SELECT DISTINCT RATE, SERVICE_CD, SERVICE_TYPE_CD, PLACE_OF_SERVICE_CD
FROM `@project.@dec_dataset.@rates_table`
WHERE
    SERVICE_CD = @service_cd
    AND SERVICE_TYPE_CD = @service_type_cd
    AND PLACE_OF_SERVICE_CD = @pos_cd
    AND RATE IS NOT NULL