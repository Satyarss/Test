class HealthInsurancePlan:
    def __init__(self, copay, coinsurance_rate, copay_applies_oopmax, coins_applies_oopmax, deductible_applies_oopmax,
                 copay_continue_deductible_met, copay_continue_oopmax_met, copay_count_to_deductible,
                 is_deductible_before_copay, d_calculated=0, oopmax_calculated=0):
        self.copay = copay
        self.coinsurance_rate = coinsurance_rate
        self.copay_applies_oopmax = copay_applies_oopmax
        self.coins_applies_oopmax = coins_applies_oopmax
        self.deductible_applies_oopmax = deductible_applies_oopmax
        self.copay_continue_deductible_met = copay_continue_deductible_met
        self.copay_continue_oopmax_met = copay_continue_oopmax_met
        self.copay_count_to_deductible = copay_count_to_deductible
        self.is_deductible_before_copay = is_deductible_before_copay
        self.d_calculated = d_calculated
        self.oopmax_calculated = oopmax_calculated

    def calculate_patient_pay(self, service_cost, is_service_covered, benefit_limitation, deductible_code_exists,
                              cost_share_copay, cost_share_coinsurance, oopmax_i_calculated, oopmax_f_calculated,
                              di_calculated, df_calculated, limit_calculated_value, limit_type):
        """
        Function to calculate the out-of-pocket cost .

        Parameters:
        service_cost (float): The cost of the service.
        is_service_covered (bool): Flag indicating if the service is covered.
        benefit_limitation (float): The benefit limitation amount.
        deductible_code_exists (bool): Flag indicating if the deductible code exists.
        cost_share_copay (float): The copay amount.
        cost_share_coinsurance (float): The coinsurance rate.
        oopmax_i_calculated (float): The calculated individual OOPMAX value.
        oopmax_f_calculated (float): The calculated family OOPMAX value.
        di_calculated (float): The calculated individual deductible value.
        df_calculated (float): The calculated family deductible value.
        limit_calculated_value (float): The calculated limit value.
        limit_type (str): The type of limit (Counter/Dollar).

        Returns:
        float: The out-of-pocket cost for the service.
        """

        # Use calculated values as calculated values
        self.oopmax_calculated = min(oopmax_i_calculated, oopmax_f_calculated)
        # oopmax_i_calculated if oopmax_i_calculated > 0 else oopmax_f_calculated
        self.d_calculated = min(di_calculated, df_calculated)
        # di_calculated if di_calculated > 0 else df_calculated
        self.copay = cost_share_copay
        self.coinsurance_rate = cost_share_coinsurance

        # Check if service is covered
        if not is_service_covered:
            print("Service not covered")
            return service_cost

        # Check if OOPMAX limit is met
        if self.oopmax_calculated == 0 and not self.copay_continue_oopmax_met:
            print("OOPMAX met")
            return 0.0

        # Check if deductible limit is met
        if self.is_deductible_before_copay:
            print(self.is_deductible_before_copay)
            if self.d_calculated > 0 and deductible_code_exists == 1:
                print("1")
                print(self.d_calculated)
                if service_cost <= self.d_calculated:
                    # Service cost is less than calculated deductible
                    self.d_calculated -= service_cost
                    print("2 - Amount left to meet deductible $" + str(self.d_calculated))
                    print(self.d_calculated)
                    print(service_cost)
                    if self.deductible_applies_oopmax:

                        #  add logic to check if oopmax met during calculation
                        print(self.oopmax_calculated)
                        if service_cost <= self.OOPMAX_calculated:
                            print("3 OOPmax_calculated value is reduced by the calculated deducible")
                            self.oopmax_calculated -= service_cost
                        else:
                            print("OOPMAX is met no more cost share")
                            membercost = self.oopmax_calculated
                            self.oopmax_calculated -= self.oopmax_calculated
                            return (self.copay + membercost)
                    return service_cost
                else:
                    # Service cost exceeds calculated deductible
                    service_cost -= self.d_calculated

                    print("4 Deductible is met")
                    print(service_cost)
                    print("5 Above service cost is used for applying coinsurance")
                    print(self.d_calculated)
                    print(self.deductible_applies_oopmax)
                    if self.deductible_applies_oopmax:
                        # deductible is met
                        self.d_calculated -= self.d_calculated
                        print("Deductible met and applied to OOPMAX")
                        print(f"DEDUCTIBLE: {self.d_calculated}")
                        #  add logic to check if oopmax met during calculation
                        print(self.oopmax_calculated)
                        if self.d_calculated <= self.OOPMAX_calculated:
                            print("6 OOPmax_calculated value is reduced by the calculated deducible")
                            self.oopmax_calculated -= self.d_calculated
                        else:
                            self.oopmax_calculated -= self.oopmax_calculated
                            print("OOPMAX is met no more cost share")
                            return (self.copay + service_cost)

                    else:
                        # deductible is met
                        self.d_calculated -= self.d_calculated
                        print("6a Deductile met but its not applied to OOPMAX")
                        print(f"DEDUCTIBLE: {self.d_calculated}")
        else:
            print("7")
            print(self.oopmax_calculated)
            print(self.d_calculated)

        # Apply copay if applicable
        if self.copay > 0 and (self.oopmax_calculated > 0 or self.copay_continue_deductible_met):
            if self.copay <= service_cost:
                print(self.copay)
                service_cost -= self.copay
                if self.copay_applies_oopmax:
                    self.oopmax_calculated -= self.copay
                if self.copay_count_to_deductible and not self.is_deductible_before_copay:
                    self.d_calculated -= self.copay
                    if self.d_calculated >= service_cost:
                        print("8 Add  service amount + copay to it")
                        self.d_calculated -= service_cost
                        print("9 Service cost applied to deductble")
                        return (self.copay + service_cost)
                    else:
                        print(
                            "10 Difference of service cost - calculated deductible is sent as service amount to coinsurance application ")
                        service_cost -= self.d_calculated
                        return self.copay + self.calculate_coinsurance(service_cost, self.oopmax_calculated)
                else:
                    if self.d_calculated >= service_cost:
                        self.d_calculated -= service_cost
                        print("11 service cost applied to deductble")
                        return (self.copay + service_cost)
                    else:
                        print(
                            "12 Difference of service cost - calculated deductible is sent as service amount to coinsurance application ")
                        service_cost -= self.d_calculated
                        print(self.oopmax_calculated)
                        print(service_cost)
                        membercost = self.copay + service_cost
                        # if self.deductible_applies_oopmax:
                        if membercost < self.oopmax_calculated:
                            print(self.copay)
                            print(self.d_calculated)
                            print(self.calculate_coinsurance(service_cost, self.oopmax_calculated))
                            print(service_cost)
                            print(self.oopmax_calculated)
                            return (self.copay + self.d_calculated + self.calculate_coinsurance(service_cost,
                                                                                                self.oopmax_calculated))
                        else:
                            print("12a OOPMAX reached")
                            return (self.oopmax_calculated)
                        # else:
                        # return(self.copay +  self.d_calculated + self.calculate_coinsurance(service_cost,self.oopmax_calculated))
            else:
                print(self.current_oopmax)
                print("13 Copay is more than service cost, So amount equal to service cost is applied to OOPMAX")
                if self.copay_applies_oopmax:
                    self.oopmax_calculated -= service_cost
                if self.copay_count_to_deductible and not self.is_deductible_before_copay:
                    self.d_calculated -= service_cost
                return service_cost

        # Apply coinsurance if applicable
        return self.calculate_coinsurance(service_cost, self.oopmax_calculated)

    def calculate_coinsurance(self, service_cost, oopmax_calculated):
        """
        Helper function to calculate the coinsurance amount.

        Parameters:
        service_cost (float): The cost of the service.

        Returns:
        float: The coinsurance amount.
        """

        oopmax_calculated = self.oopmax_calculated
        coinsurance_amount = service_cost * self.coinsurance_rate
        if coinsurance_amount <= oopmax_calculated or not self.coins_applies_oopmax:
            if self.coins_applies_oopmax:
                print(coinsurance_amount)
                self.oopmax_calculated -= coinsurance_amount
                print(self.oopmax_calculated)
                print("15 Amount left to meet out-of-pocket maximum " + str(self.oopmax_calculated))
                return coinsurance_amount
            else:
                return 0
        else:
            self.oopmax_calculated -= self.oopmax_calculated
            print(
                "15a Coinsurance calculated value is more than OOP calulated value so coinsurance equal to OOPMAX calculated values applies")
            return oopmax_calculated


#  Use case
plan = HealthInsurancePlan(
    copay=0.0,
    coinsurance_rate=0.0,
    copay_applies_oopmax=True,
    coins_applies_oopmax=False,
    deductible_applies_oopmax=False,
    copay_continue_deductible_met=False,
    copay_continue_oopmax_met=False,
    copay_count_to_deductible=False,
    is_deductible_before_copay=True,
    d_calculated=0,
    oopmax_calculated=0
)
service_cost = 161.0
is_service_covered = True
benefit_limitation = None
deductible_code_exists = False
cost_share_copay = 30.0
cost_share_coinsurance = 0.0
oopmax_i_calculated = 6000.0
oopmax_f_calculated = 12000.0
di_calculated = 0.0
df_calculated = 0.0
limit_calculated_value = 0
limit_type = "Dollar"

OOPMAX = plan.oopmax_calculated
DEDUCTIBLE = plan.d_calculated
out_of_pocket_cost = plan.calculate_patient_pay(service_cost, is_service_covered, benefit_limitation,
                                                deductible_code_exists, cost_share_copay, cost_share_coinsurance,
                                                oopmax_i_calculated, oopmax_f_calculated, di_calculated, df_calculated,
                                                limit_calculated_value, limit_type)
print(f"You Pay ${out_of_pocket_cost}")
