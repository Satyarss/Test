from abc import ABC, abstractmethod

from app.models.rate_criteria import CostEstimatorRateCriteria


class CostEstimatorRepositoryInterface(ABC):
    @abstractmethod
    async def get_rate(self, rate_type: str, rate_criteria: CostEstimatorRateCriteria, *args, **kwargs) -> float:
        """
        Retrieve the rate based on the rate_type and additional parameters.
        """
        pass