from typing import List, Optional
from pydantic import BaseModel
from app.schemas.cost_estimator_request_model import CostEstimatorRequest


class EffectivePeriod(BaseModel):
    datetimeBegin: str
    datetimeEnd: str


class Accumulator(BaseModel):
    level: str
    frequency: str
    relationshipToSubscriber: str
    suffix: str
    benefitProductType: str
    description: str
    currentValue: str
    limitValue: str
    code: str
    effectivePeriod: EffectivePeriod
    calculatedValue: str
    savingsLevel: str
    networkIndicator: str
    accumExCode: str
    limitType: Optional[str] = None
    networkIndicatorCode: str


class MembershipIdentifier(BaseModel):
    idSource: str
    idValue: str
    idType: str
    resourceId: str


class Dependent(BaseModel):
    privacyRestriction: str
    membershipIdentifier: MembershipIdentifier
    accumulators: List[Accumulator]


class Memberships(BaseModel):
    dependents: List[Dependent]


class ReadAccumulatorsResponse(BaseModel):
    memberships: Memberships


class AccumulatorResponse(BaseModel):
    readAccumulatorsResponse: ReadAccumulatorsResponse

    def __init__(self, response_data: dict = None):
        if response_data:
            super().__init__(**response_data)
        else:
            super().__init__(readAccumulatorsResponse=ReadAccumulatorsResponse(
                memberships=Memberships(dependents=[])
            ))

    def get_accumulators_by_network(self, network_indicator: str = "InNetwork") -> List[Accumulator]:
        """Get accumulators filtered by network indicator."""
        accumulators = []
        for dependent in self.readAccumulatorsResponse.memberships.dependents:
            for accumulator in dependent.accumulators:
                if accumulator.networkIndicator == network_indicator:
                    accumulators.append(accumulator)
        return accumulators

    def get_accumulator_by_code(self, code: str, network_indicator: str = "InNetwork") -> Optional[Accumulator]:
        """Get a specific accumulator by its code and network indicator."""
        for dependent in self.readAccumulatorsResponse.memberships.dependents:
            for accumulator in dependent.accumulators:
                if accumulator.code == code and accumulator.networkIndicator == network_indicator:
                    return accumulator
        return None

    def get_out_of_pocket_max(self, network_indicator: str = "InNetwork") -> Optional[Accumulator]:
        """Get the out-of-pocket maximum accumulator."""
        return self.get_accumulator_by_code("OOP Max", network_indicator)

    def get_deductible(self, network_indicator: str = "InNetwork") -> Optional[Accumulator]:
        """Get the deductible accumulator."""
        return self.get_accumulator_by_code("Deductible", network_indicator)

    def get_annual_maximum(self, network_indicator: str = "InNetwork") -> Optional[Accumulator]:
        """Get the annual maximum accumulator."""
        return self.get_accumulator_by_code("Annual Maximum", network_indicator)

    def get_accumulator_by_description(self, description: str, network_indicator: str = "InNetwork") -> Optional[Accumulator]:
        """Get a specific accumulator by its description and network indicator."""
        for dependent in self.readAccumulatorsResponse.memberships.dependents:
            for accumulator in dependent.accumulators:
                if accumulator.description == description and accumulator.networkIndicator == network_indicator:
                    return accumulator
        return None

    def get_accumulator_by_accum_ex_code(self, accum_ex_code: str, network_indicator: str = "InNetwork") -> Optional[Accumulator]:
        """Get a specific accumulator by its accumExCode and network indicator."""
        for dependent in self.readAccumulatorsResponse.memberships.dependents:
            for accumulator in dependent.accumulators:
                if accumulator.accumExCode == accum_ex_code and accumulator.networkIndicator == network_indicator:
                    return accumulator
        return None 