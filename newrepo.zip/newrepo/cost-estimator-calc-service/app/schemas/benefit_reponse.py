import json


from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field

class Modifier(BaseModel):
    # Empty object, can be extended as needed
    pass

class ServiceCodeInfo(BaseModel):
    code: str
    type: str
    modifier: Optional[Modifier] = Field(default_factory=Modifier)

class PlaceOfServiceItem(BaseModel):
    code: str

class ProviderTypeItem(BaseModel):
    code: str

class ProviderSpecialtyItem(BaseModel):
    code: str

class Prerequisite(BaseModel):
    type: str
    isRequired: str

class BenefitTier(BaseModel):
    benefitTierName: str

class ServiceProviderItem(BaseModel):
    providerDesignation: Optional[str] = ""

class RelatedAccumulator(BaseModel):
    code: str
    level: str
    deductibleCode: str
    accumExCode: str
    networkIndicatorCode: str

class Coverage(BaseModel):
    sequenceNumber: int
    benefitDescription: str
    costShareCopay: float
    costShareCoinsurance: float
    copayAppliesOutOfPocket: str
    coinsAppliesOutOfPocket: str
    deductibleAppliesOutOfPocket: str
    deductibleAppliesOutOfPocketOtherIndicator: str
    copayCountToDeductibleIndicator: str
    copayContinueWhenDeductibleMetIndicator: str
    copayContinueWhenOutOfPocketMaxMetIndicator: str
    coinsuranceToOutOfPocketOtherIndicator: str
    copayToOutofPocketOtherIndicator: str
    isDeductibleBeforeCopay: str
    benefitLimitation: str
    isServiceCovered: str
    relatedAccumulators: List[RelatedAccumulator]

class Benefit(BaseModel):
    benefitName: str
    benefitCode: int
    isInitialBenefit: str
    benefitTier: BenefitTier
    networkCategory: str
    prerequisites: List[Prerequisite]
    benefitProvider: str
    serviceProvider: List[ServiceProviderItem]
    coverages: List[Coverage]

class ServiceCodeInfoItem(BaseModel):
    code: str
    type: str
    modifier: Optional[Modifier] = Field(default_factory=Modifier)
    benefit: Optional[List[Benefit]] = None

class ServiceInfoItem(BaseModel):
    serviceCodeInfo: List[ServiceCodeInfoItem]
    placeOfService: List[PlaceOfServiceItem]
    providerType: List[ProviderTypeItem]
    providerSpecialty: List[ProviderSpecialtyItem]

class BenefitResponse(BaseModel):
    serviceInfo: List[ServiceInfoItem]
