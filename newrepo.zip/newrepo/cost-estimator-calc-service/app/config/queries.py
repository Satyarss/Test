"""SQL query configurations for the cost estimator service."""

# Rate queries
RATE_QUERIES = {
    "get_claim_based_rate": "SELECT MAX(RATE) AS RATE FROM CET_CLAIM_BASED_AMOUNTS WHERE PROVIDER_IDENTIFICATION_NBR = @provideridentificationnumber AND NETWORK_ID = @networkid AND PLACE_OF_SERVICE_CD = @placeofservice AND SERVICE_CD = @servicecd AND SERVICE_TYPE_CD = @servicetype",
    "get_provider_info": "SELECT DISTINCT PROVIDER_BUSINESS_GROUP_NBR,PRODUCT_CD,RATING_SYSTEM_CD,EPDB_GEOGRAPHIC_AREA_CD FROM CET_PROVIDERS p WHERE p.PROVIDER_IDENTIFICATION_NBR = @provideridentificationnumber AND p.NETWORK_ID = @networkid AND p.SERVICE_LOCATION_NBR = @servicelocationnumber",
    "get_standard_rate": "select Max(RATE) AS RATE from CET_RATES where  RATE_SYSTEM_CD = @ratesystemcd and SERVICE_CD = @servicecd and SERVICE_TYPE_CD = @servicetype and  GEOGRAPHIC_AREA_CD = @geographicareacd and PLACE_OF_SERVICE_CD = @placeofservice and PRODUCT_CD = @productcd and contract_type = @contracttype",
    "get_non_standard_rate": "select Max(RATE) AS RATE from CET_RATES where SERVICE_CD = @servicecd and SERVICE_TYPE_CD = @servicetype and  PLACE_OF_SERVICE_CD = @placeofservice and PRODUCT_CD = @productcd and provider_business_group_nbr = @providerbusinessgroupnbr and contract_type in ('C', 'N', 'D')",
}

