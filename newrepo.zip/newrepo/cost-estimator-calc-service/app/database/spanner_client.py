from google.cloud.spanner_v1 import SpannerAsyncClient
from google.cloud.spanner_v1 import PartitionOptions, PartitionReadRequest, PartitionQueryRequest
from typing import Optional, List, Dict, Any, Union
from app.core.logger import logger
import asyncio
from contextlib import asynccontextmanager
from concurrent.futures import ThreadPoolExecutor

class SpannerClient:
    def __init__(self, 
                 project_id: str,
                 instance_id: str,
                 database_id: str,
                 max_workers: int = 10,
                 pool_size: int = 5):
        """Initialize async Spanner client for read-only operations."""
        self.project_id = project_id
        self.instance_id = instance_id
        self.database_id = database_id
        self.max_workers = max_workers
        self.pool_size = pool_size
        
        # Create database path
        self.database_path = f"projects/{project_id}/instances/{instance_id}/databases/{database_id}"
        
        # Connection pool
        self._client_pool = asyncio.Queue(maxsize=pool_size)
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        
        # Simple in-memory cache for frequently accessed data
        self._cache = {}
        self._cache_ttl = 300  # 5 minutes
        
        logger.info(f"Async SpannerClient initialized for database: {self.database_path}")
        logger.info(f"Connection pool size: {pool_size}, Max workers: {max_workers}")

    @asynccontextmanager
    async def _get_client_and_session(self):
        """Context manager for Spanner client and session."""
        client = SpannerAsyncClient()
        try:
            session = await client.create_session(request={"database": self.database_path})
            try:
                yield client, session
            finally:
                await client.delete_session(request={"name": session.name})
        finally:
            # SpannerAsyncClient doesn't have a close method
            pass

    async def execute_query(self, 
                          query: str, 
                          params: Optional[Dict[str, Any]] = None) -> List[Dict]:
        """Execute a read-only query using async Cloud Spanner client."""
        try:
            logger.info(f"Executing async query: {query}")
            logger.info(f"Query params: {params}")
            
            async with self._get_client_and_session() as (client, session):
                # Execute query using session
                request_data = {
                    "session": session.name,
                    "sql": query,
                    "params": params or {}
                }
              
                
                response = await client.execute_sql(request=request_data)
                
                return response.rows;
                
        except Exception as e:
            logger.error(f"Error executing async read-only query: {str(e)}")
            logger.error(f"Query: {query}")
            logger.error(f"Params: {params}")
            logger.error(f"Exception type: {type(e)}")
            logger.error(f"Exception details: {e}")
            return []

    async def execute_query_cached(self, 
                                 query: str, 
                                 params: Optional[Dict[str, Any]] = None,
                                 cache_key: Optional[str] = None,
                                 ttl: int = 300) -> List[Dict]:
        """Execute query with caching for better performance."""
        if cache_key:
            # Check cache first
            cached_result = self._get_from_cache(cache_key)
            if cached_result is not None:
                logger.info(f"Cache hit for key: {cache_key}")
                return cached_result
        
        # Execute query
        result = await self.execute_query(query, params)
        
        # Cache the result
        if cache_key and result:
            self._set_cache(cache_key, result, ttl)
        
        return result

    def _get_from_cache(self, key: str) -> Optional[List[Dict]]:
        """Get value from cache."""
        if key in self._cache:
            timestamp, value = self._cache[key]
            if asyncio.get_event_loop().time() - timestamp < self._cache_ttl:
                return value
            else:
                del self._cache[key]
        return None

    def _set_cache(self, key: str, value: List[Dict], ttl: int = 300):
        """Set value in cache."""
        self._cache[key] = (asyncio.get_event_loop().time(), value)
        
        # Simple cache cleanup (remove old entries)
        if len(self._cache) > 1000:  # Limit cache size
            oldest_key = min(self._cache.keys(), 
                           key=lambda k: self._cache[k][0])
            del self._cache[oldest_key]

    

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        logger.info("Async SpannerClient closed")

   