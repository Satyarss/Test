import aiohttp
import json
import requests
import ssl
from typing import Dict, Any
from app.core.logger import logger
from app.schemas.benefit_request import BenefitRequest
from app.schemas.benefit_reponse import BenefitResponse
from app.core.constants import BENEFITS_URL
from app.core.session_manager import SessionManager
from app.services.token_service import TokenService


class BenefitServiceImpl:
    """Service implementation for handling benefit-related operations."""

    def __init__(self):
        # Create SSL context that doesn't verify certificates
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE
        self.token_service = TokenService()

    async def get_benefit(self, benefit_request: BenefitRequest) -> BenefitResponse:
        """
        Get benefit information for the given request.
        
        Args:
            benefit_request (BenefitRequest): The benefit request object
            
        Returns:
            Dict[str, Any]: The benefit response data
            
        Raises:
            Exception: If the benefit request fails
        """
        
        try:
            token = SessionManager.get_token()
            if not token:
                # Get new token and store it
                token = await self.token_service.get_new_token()
                SessionManager.set_token(token)
            
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {token['access_token']}",
                "id_token": f"{token['id_token']}"
            }
            benefit_request_json = json.loads(benefit_request.model_dump_json())
        
      
            connector = aiohttp.TCPConnector(ssl=self.ssl_context)
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.post(
                    url=BENEFITS_URL,
                    json=benefit_request.model_dump(),
                    headers=headers
                ) as response:
                    response_text = await response.text()
                    
                    if response.status == 401:  # Token expired
                        SessionManager.clear_token()
                        # Retry with new token
                        return await self.get_benefit(benefit_request)
                        
                    if response.status == 400:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Benefit request failed with status 400: "
                                f"{response_json.get('httpMessage', 'Bad Request')} - "
                                f"{response_json.get('moreInformation', 'Invalid request data')}"
                            )
                        except:
                            error_msg = f"Benefit request failed with status 400: {response_text}"
                        logger.error(error_msg)
                        raise Exception(error_msg)
                        
                    if response.status == 500:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Benefit service error with status 500: "
                                f"{response_json.get('httpMessage', 'Internal Server Error')} - "
                                f"{response_json.get('moreInformation', 'Service temporarily unavailable')}"
                            )
                        except:
                            error_msg = f"Benefit service error with status 500: {response_text}"
                        logger.error(error_msg)
                        raise Exception(error_msg)
                        
                    if response.status != 200:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Benefit request failed with status {response.status}: "
                                f"{response_json.get('httpMessage', 'Request failed')} - "
                                f"{response_json.get('moreInformation', 'Unknown error')}"
                            )
                        except:
                            error_msg = f"Benefit request failed with status {response.status}: {response_text}"
                        logger.error(error_msg)
                        raise Exception(error_msg)
                    
                    # Success case - return the benefit response
                    response_data = await response.json()
                    benefit_response = BenefitResponse(**response_data)
                    return benefit_response
                
                    
        except Exception as e:
            logger.error(f"Error in get_benefit: {str(e)}")
            raise
        
   