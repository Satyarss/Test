from abc import ABC, abstractmethod


class CostEstimationServiceInterface(ABC):
    @abstractmethod
    async def get_rate(self, request):
        pass
