import aiohttp
import json
import ssl
from typing import Dict, Any
from app.core.logger import logger
from app.core.constants import TOKEN_URL, TOKEN_AUTHORIZATION, ASSERTION


class TokenService:
    """Service for handling authentication token operations."""

    def __init__(self):
        # Create SSL context that doesn't verify certificates
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE

    async def get_new_token(self) -> Dict[str, Any]:
        """
        Get a new authentication token.
        
        Returns:
            Dict[str, Any]: Token data containing access_token and id_token
            
        Raises:
            Exception: If token retrieval fails
        """
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {TOKEN_AUTHORIZATION}"
        }
        payload = json.dumps(
            {
                "scope": "Public NonPII PII PHI openid",
                "assertion": ASSERTION,
                "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
            }
        )

        try:
            connector = aiohttp.TCPConnector(ssl=self.ssl_context)
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.post(
                    url=TOKEN_URL,
                    headers=headers,
                    data=payload
                ) as response:
                    if response.status == 200:
                        token_data = await response.json()
                        logger.info("Successfully retrieved new token")
                        return token_data
                    else:
                        error_msg = f"Failed to get new token. Status: {response.status}"
                        logger.error(error_msg)
                        raise Exception(error_msg)
        except Exception as e:
            logger.error(f"Error in get_new_token: {str(e)}")
            raise 