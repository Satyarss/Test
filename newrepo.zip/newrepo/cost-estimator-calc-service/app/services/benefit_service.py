from abc import ABC, abstractmethod
from app.schemas.benefit_request import BenefitRequest
from app.schemas.benefit_reponse import BenefitResponse


class BenefitServiceInterface(ABC):
    @abstractmethod
    async def get_benefit(self, request: BenefitRequest) -> BenefitResponse:
        """
        Abstract method to get benefit information using a BenefitRequest object.
        Returns a BenefitResponse object.
        """
        pass
