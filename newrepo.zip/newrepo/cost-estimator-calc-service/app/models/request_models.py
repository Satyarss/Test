from typing import List, Dict, Any, Optional
from pydantic import BaseModel

class RelatedAccumulator(BaseModel):
    code: str
    level: str
    deductibleCode: Optional[str] = ""
    accumExCode: Optional[str] = ""
    networkIndicatorCode: Optional[str] = ""

class Coverage(BaseModel):
    sequenceNumber: int
    benefitDescription: str
    costShareCopay: float
    costShareCoinsurance: float
    copayAppliesOutOfPocket: str
    coinsAppliesOutOfPocket: str
    deductibleAppliesOutOfPocket: str
    deductibleAppliesOutOfPocketOtherIndicator: str
    copayCountToDeductibleIndicator: str
    copayContinueWhenDeductibleMetIndicator: Optional[str] = ""
    copayContinueWhenOutOfPocketMaxMetIndicator: Optional[str] = ""
    coinsuranceToOutOfPocketOtherIndicator: str
    copayToOutofPocketOtherIndicator: str
    isDeductibleBeforeCopay: str
    benefitLimitation: Optional[str] = ""
    isServiceCovered: str
    relatedAccumulators: List[RelatedAccumulator]

class ServiceProvider(BaseModel):
    providerDesignation: Optional[str] = ""

class Prerequisite(BaseModel):
    type: str
    isRequired: str

class BenefitTier(BaseModel):
    benefitTierName: Optional[str] = ""

class Benefit(BaseModel):
    benefitName: str
    benefitCode: int
    isInitialBenefit: str
    benefitTier: BenefitTier
    networkCategory: str
    prerequisites: List[Prerequisite]
    benefitProvider: Optional[str] = ""
    serviceProvider: List[ServiceProvider]
    coverages: List[Coverage]

class ProviderSpecialty(BaseModel):
    code: Optional[str] = ""

class ProviderType(BaseModel):
    code: Optional[str] = ""

class PlaceOfService(BaseModel):
    code: str

class ServiceCodeInfo(BaseModel):
    code: str
    type: str
    modifier: Dict[str, Any] = {}

class ServiceInfo(BaseModel):
    serviceCodeInfo: List[ServiceCodeInfo]
    placeOfService: List[PlaceOfService]
    providerType: List[ProviderType]
    providerSpecialty: List[ProviderSpecialty]
    benefit: List[Benefit]

class RequestModel(BaseModel):
    serviceInfo: List[ServiceInfo] 