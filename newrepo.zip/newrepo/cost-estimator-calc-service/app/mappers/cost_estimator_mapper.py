from typing import List, Dict, Any
from app.schemas.cost_estimator_request_model import (
    RequestModel, Service, PlaceOfService, ProviderInfo
)
from app.schemas.benefit_request import BenefitRequest
from app.models.rate_criteria import CostEstimatorRateCriteria

class CostEstimatorMapper:
    @staticmethod
    def to_benefit_request(request: RequestModel) -> BenefitRequest:
        """
        Maps a RequestModel to a BenefitRequest.
        
        Args:
            request (RequestModel): The input request model
            
        Returns:
            BenefitRequest: The mapped benefit request
        """
        service_info = {
            "serviceCodeInfo": {
                "code": request.service.code,
                "type": request.service.type,
                "providerType": [{"code": provider.providerType} for provider in request.providerInfo],
                "placeOfService": [{"code": request.service.placeOfService.code}],
                "providerSpecialty": [{"code": provider.specialty.code} for provider in request.providerInfo]
            }
        }
        
        return BenefitRequest(
            benefitProductType=request.benefitProductType,
            membershipID=request.membershipId,
            planIdentifier="3~",  # Using membershipId as planIdentifier
            serviceInfo=[service_info]
        )

    @staticmethod
    def to_rate_criteria(request: RequestModel) -> CostEstimatorRateCriteria:
        """
        Maps a RequestModel to CostEstimatorRateCriteria.
        
        Args:
            request (RequestModel): The input request model
            
        Returns:
            CostEstimatorRateCriteria: The mapped rate criteria
        """
        # Debug: Print the available fields
        print("CostEstimatorRateCriteria fields:", CostEstimatorRateCriteria.__annotations__)
        
        try:
            return CostEstimatorRateCriteria(
                providerIdentificationNumber=request.providerInfo[0].providerIdentificationNumber,
                serviceCode=request.service.code,
                serviceType=request.service.type,
                serviceLocationNumber=request.providerInfo[0].serviceLocation,
                networkId=request.providerInfo[0].providerNetworks.networkID,
                placeOfService=request.service.placeOfService.code,
                zipCode=request.zipCode
            )
        except Exception as e:
            print(f"Error creating CostEstimatorRateCriteria: {e}")
            raise
        