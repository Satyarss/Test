import pytest
from unittest.mock import create_autospec, MagicMock
from app.services.benefit_service import (
    BenefitRequest,
    BenefitResponse,
    BenefitServiceInterface,
)

# Abstract Behavior


def test_interface_is_abstract():
    with pytest.raises(TypeError):
        BenefitServiceInterface()


def test_subclass_without_implementation_fails():
    class IncompleteService(BenefitServiceInterface):
        pass

    with pytest.raises(TypeError):
        IncompleteService()


# the following 3 test cases are currently failing


def test_subclass_with_implementation_succeeds():
    class ConcreteBenefitService(BenefitServiceInterface):
        def get_benefit(self, request: BenefitRequest) -> BenefitResponse:
            return BenefitResponse(request)

    mock_request = BenefitRequest(
        url="http://mock-url.com/benefits", payload={}, headers={}
    )
    mock_request.send_request()

    service = ConcreteBenefitService()
    result = service.get_benefit(mock_request)
    assert isinstance(result, BenefitResponse)


def test_mocked_interface_behavior():
    mock_service = create_autospec(BenefitServiceInterface, instance=True)

    mock_request = BenefitRequest(
        url="http://mock-url.com/benefits", payload={}, headers={}
    )
    mock_request.send_request()
    mock_response = BenefitResponse(mock_request)
    mock_service.get_benefit.return_value = mock_response

    response = mock_service.get_benefit(mock_request)

    mock_service.get_benefit.assert_called_once_with(mock_request)
    assert response is not None


def test_mock_used_in_application_logic():
    def app_logic(
        service: BenefitServiceInterface, request: BenefitRequest
    ) -> BenefitResponse:
        return service.get_benefit(request)

    mock_service = MagicMock(spec=BenefitServiceInterface)
    mock_request = BenefitRequest(
        url="http://mock-url.com/benefits", payload={}, headers={}
    )
    mock_request.send_request()
    mock_service.get_benefit.return_value = BenefitResponse(mock_request)
    res = app_logic(mock_service, mock_request)

    mock_service.get_benefit.assert_called_once()
    assert res is not None
