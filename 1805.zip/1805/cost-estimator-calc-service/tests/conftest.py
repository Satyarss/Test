import sys
import os
import pytest
from fastapi.testclient import TestClient

# Add the app directory to the Python path so we can import from app
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))

from app.main import app

# Register custom pytest marks to avoid warnings
pytest_plugins = []


def pytest_configure(config):
    """Register custom markers."""
    config.addinivalue_line("markers", "unit: Unit tests")
    config.addinivalue_line("markers", "integration: Integration tests")
    config.addinivalue_line(
        "markers", "real_services: Real external service integration tests"
    )
    config.addinivalue_line("markers", "slow: Slow running tests")
    config.addinivalue_line("markers", "api: API tests")
    config.addinivalue_line("markers", "repository: Repository tests")
    config.addinivalue_line("markers", "service: Service tests")
    config.addinivalue_line("markers", "asyncio: Async tests")


@pytest.fixture
def client():
    """Create a test client for the FastAPI app."""
    return TestClient(app)


@pytest.fixture
def async_client():
    """Create an async test client for the FastAPI app."""
    from httpx import AsyncClient

    return AsyncClient(app=app, base_url="http://test")


@pytest.fixture
def valid_request_data():
    """Provide valid request data for testing."""
    return {
        "membershipId": "5~186103331+10+7+20240101+793854+8A+829",
        "zipCode": "85305",
        "benefitProductType": "Medical",
        "languageCode": "11",
        "service": {
            "code": "99214",
            "type": "CPT4",
            "description": "Adult Office visit Age 30-39",
            "supportingService": {"code": "470", "type": "DRG"},
            "modifier": {"modifierCode": "E1"},
            "diagnosisCode": "F33 40",
            "placeOfService": {"code": "11"},
        },
        "providerInfo": [
            {
                "serviceLocation": "000761071",
                "providerType": "HO",
                "speciality": {"code": "91017"},
                "taxIdentificationNumber": "0000431173518",
                "taxIdQualifier": "SN",
                "providerNetworks": {"networkID": "58921"},
                "providerIdentificationNumber": "0004000317",
                "nationalProviderId": "1386660504",
                "providerNetworkParticipation": {"providerTier": "1"},
            }
        ],
    }


@pytest.fixture
def mock_service():
    """Provide a mock service for testing."""
    from unittest.mock import Mock

    mock = Mock()
    mock.get_rate.return_value = 150.50
    return mock


@pytest.fixture
def rate_criteria():
    """Provide rate criteria for testing."""
    from app.models.rate_criteria import CostEstimatorRateCriteria

    return CostEstimatorRateCriteria(
        serviceCode="99213",
        providerIdentificationNumber="1234567890",
        placeOfService="11",
        serviceType="1",
        networkId="NET001",
        serviceLocationNumber="LOC001",
        zipCode="85305",
        isOutofNetwork=False,
        providerType="HO",
        providerSpecialtyCode="91017",
    )
