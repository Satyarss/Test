import pytest
from app.schemas.benefit_response import (
    BenefitApiResponse,
    ServiceInfoItem,
    ServiceCodeInfoItem,
    PlaceOfServiceItem,
    ProviderTypeItem,
    ProviderSpecialtyItem,
    Benefit,
    BenefitTier,
    Prerequisite,
    ServiceProviderItem,
    Coverage,
    RelatedAccumulator,
)


def test_benefit_api_response():
    response = BenefitApiResponse(
        serviceInfo=[
            ServiceInfoItem(
                serviceCodeInfo=[ServiceCodeInfoItem(code="99214", type="CPT4")],
                placeOfService=[PlaceOfServiceItem(code="11")],
                providerType=[ProviderTypeItem(code="HO")],
                providerSpecialty=[ProviderSpecialtyItem(code="91017")],
                benefit=[
                    Benefit(
                        benefitName="Test Benefit",
                        benefitCode=123,
                        isInitialBenefit="Yes",
                        benefitTier=BenefitTier(benefitTierName="Tier 1"),
                        networkCategory="In-Network",
                        prerequisites=[Prerequisite(type="Referral", isRequired="Yes")],
                        benefitProvider="Provider A",
                        serviceProvider=[
                            ServiceProviderItem(providerDesignation="Primary Care")
                        ],
                        coverages=[
                            Coverage(
                                sequenceNumber=1,
                                benefitDescription="General consultation",
                                costShareCopay=10.0,
                                costShareCoinsurance=5.0,
                                copayAppliesOutOfPocket="yes",
                                coinsAppliesOutOfPocket="No",
                                deductibleAppliesOutOfPocket="yes",
                                deductibleAppliesOutOfPocketOtherIndicator="No",
                                copayCountToDeductibleIndicator="yes",
                                copayContinueWhenDeductibleMetIndicator="No",
                                copayContinueWhenOutOfPocketMaxMetIndicator="yes",
                                coinsuranceToOutOfPocketOtherIndicator="No",
                                copayToOutofPocketOtherIndicator="yes",
                                isDeductibleBeforeCopay="No",
                                benefitLimitation="No Limit",
                                isServiceCovered="Yes",
                                relatedAccumulators=[
                                    RelatedAccumulator(
                                        code="ACC1",
                                        level="Level1",
                                        deductibleCode="Deductible1",
                                        accumExCode="AccumEx1",
                                        networkIndicatorCode="Network1",
                                    )
                                ],
                            )
                        ],
                    )
                ],
            )
        ]
    )

    assert response.serviceInfo[0].benefit[0].benefitName == "Test Benefit"
    assert response.serviceInfo[0].benefit[0].benefitTier.benefitTierName == "Tier 1"
    assert response.serviceInfo[0].benefit[0].coverages[0].costShareCopay == 10.0
    assert (
        response.serviceInfo[0].benefit[0].coverages[0].relatedAccumulators[0].code
        == "ACC1"
    )
    assert response.serviceInfo[0].placeOfService[0].code == "11"
    assert response.serviceInfo[0].providerType[0].code == "HO"
    assert response.serviceInfo[0].providerSpecialty[0].code == "91017"
    assert (
        response.serviceInfo[0].benefit[0].coverages[0].benefitDescription
        == "General consultation"
    )
    assert (
        response.serviceInfo[0].benefit[0].coverages[0].copayAppliesOutOfPocket == "yes"
    )
