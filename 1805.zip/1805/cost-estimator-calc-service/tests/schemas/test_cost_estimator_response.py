import pytest
from unittest.mock import Mock
from app.schemas.cost_estimator_response import (
    CostEstimatorResponse,
    CostEstimateResponse,
    CostEstimateResponseInfo,
    Coverage,
    Cost,
    HealthClaimLine,
    AccumulatorInfo,
    Accumulator,
    AccumulatorCalculation,
)
from app.schemas.cost_estimator_request import (
    CostEstimatorRequest,
    Service,
    ProviderInfo,
    SupportingService,
    Modifier,
    PlaceOfService,
    Speciality,
    ProviderNetworks,
    ProviderNetworkParticipation,
)
from app.models.selected_benefit import SelectedBenefit, SelectedCoverage
from app.models.rate_criteria import NegotiatedRate
from app.schemas.benefit_response import BenefitTier, Prerequisite, ServiceProviderItem
from app.core.base import InsuranceContext
from app.schemas.accumulator_response import Accumulator as AccumulatorResponse


class TestCostEstimatorResponse:
    @pytest.fixture
    def sample_request(self):
        """Create a sample CostEstimatorRequest for testing"""
        return CostEstimatorRequest(
            membershipId="test-member-123",
            zipCode="12345",
            benefitProductType="Medical",
            languageCode="en",
            service=Service(
                code="99214",
                type="CPT4",
                description="Office visit",
                supportingService=SupportingService(code="470", type="DRG"),
                modifier=Modifier(modifierCode="E1"),
                diagnosisCode="F33 40",
                placeOfService=PlaceOfService(code="11"),
            ),
            providerInfo=[
                ProviderInfo(
                    serviceLocation="123456",
                    providerType="HO",
                    speciality=Speciality(code="91017"),
                    taxIdentificationNumber="123456789",
                    taxIdQualifier="SN",
                    providerNetworks=ProviderNetworks(networkID="NET001"),
                    providerIdentificationNumber="PROV001",
                    nationalProviderId="1234567890",
                    providerNetworkParticipation=ProviderNetworkParticipation(
                        providerTier="1"
                    ),
                )
            ],
        )

    @pytest.fixture
    def sample_selected_benefit(self):
        """Create a sample SelectedBenefit for testing"""
        coverage = SelectedCoverage(
            sequenceNumber=1,
            benefitDescription="Test benefit",
            costShareCopay=25.0,
            costShareCoinsurance=20.0,
            copayAppliesOutOfPocket="Y",
            coinsAppliesOutOfPocket="Y",
            deductibleAppliesOutOfPocket="Y",
            deductibleAppliesOutOfPocketOtherIndicator="N",
            copayCountToDeductibleIndicator="Y",
            copayContinueWhenDeductibleMetIndicator="N",
            copayContinueWhenOutOfPocketMaxMetIndicator="Y",
            coinsuranceToOutOfPocketOtherIndicator="N",
            copayToOutofPocketOtherIndicator="Y",
            isDeductibleBeforeCopay="N",
            benefitLimitation="Y",
            isServiceCovered="Y",
            matchedAccumulators=[],
        )

        return SelectedBenefit(
            benefitName="Test Benefit",
            benefitCode=123,
            isInitialBenefit="Y",
            benefitTier=BenefitTier(benefitTierName="Tier 1"),
            networkCategory="In-Network",
            prerequisites=[Prerequisite(type="Referral", isRequired="Yes")],
            benefitProvider="Test Provider",
            serviceProvider=[ServiceProviderItem(providerDesignation="Primary Care")],
            coverage=coverage,
        )

    @pytest.fixture
    def sample_insurance_context(self):
        """Create a sample InsuranceContext for testing"""
        context = InsuranceContext()
        context.service_amount = 150.0
        context.is_service_covered = True
        context.cost_share_copay = 25.0
        context.cost_share_coinsurance = 20.0
        context.limit_calculated = 1000.0
        context.member_pays = 50.0
        context.amount_copay = 25.0
        context.amount_coinsurance = 30.0
        context.benefit_id = "123"
        context.oopmax_family_calculated = 500.0
        context.oopmax_individual_calculated = 250.0
        context.deductible_individual_calculated = 200.0
        context.deductible_family_calculated = 400.0
        return context

    def test_build_cost_estimator_response_success(
        self, sample_request, sample_selected_benefit, sample_insurance_context
    ):
        """Test successful building of CostEstimatorResponse"""
        selected_benefits = [sample_selected_benefit]
        rate = NegotiatedRate(
            paymentMethod="COPAY", rate=150.0, rateType="AMOUNT", isRateFound=True
        )

        response = CostEstimatorResponse.build_cost_estimator_response(
            sample_request, selected_benefits, sample_insurance_context, rate
        )

        assert response is not None
        assert isinstance(response, CostEstimatorResponse)
        assert response.costEstimateResponse is not None
        assert len(response.costEstimateResponse.costEstimateResponseInfo) == 1

        # Check coverage
        coverage = response.costEstimateResponse.costEstimateResponseInfo[0].coverage
        assert coverage.isServiceCovered == "Y"
        assert coverage.maxCoverageAmount == 1000.0
        assert coverage.costShareCopay == 25.0
        assert coverage.costShareCoinsurance == 20.0

        # Check cost
        cost = response.costEstimateResponse.costEstimateResponseInfo[0].cost
        assert cost.inNetworkCosts == 150.0
        assert cost.outOfNetworkCosts == 0.0
        assert cost.inNetworkCostsType == "Amount"

        # Check health claim line
        health_claim = response.costEstimateResponse.costEstimateResponseInfo[
            0
        ].healthClaimLine
        assert health_claim.amountCopay == 25.0
        assert health_claim.amountCoinsurance == 30.0
        assert health_claim.amountResponsibility == 150.0
        assert health_claim.percentResponsibility == "20.0"
        assert health_claim.amountpayable == 50.0

    def test_build_cost_estimator_response_no_benefits(
        self, sample_request, sample_insurance_context
    ):
        """Test building response with no selected benefits"""
        selected_benefits = []
        rate = NegotiatedRate(
            paymentMethod="COPAY", rate=150.0, rateType="AMOUNT", isRateFound=True
        )

        response = CostEstimatorResponse.build_cost_estimator_response(
            sample_request, selected_benefits, sample_insurance_context, rate
        )

        assert response is not None
        assert isinstance(response, CostEstimatorResponse)
        assert response.costEstimateResponse is not None
        assert len(response.costEstimateResponse.costEstimateResponseInfo) == 1

        # Check coverage when no benefits
        coverage = response.costEstimateResponse.costEstimateResponseInfo[0].coverage
        assert coverage.isServiceCovered == "N"

    def test_select_benefit_with_highest_member_pay_matching_code(
        self, sample_selected_benefit, sample_insurance_context
    ):
        """Test selecting benefit when benefit code matches"""
        selected_benefits = [sample_selected_benefit]

        result = CostEstimatorResponse.select_benefit(
            selected_benefits, sample_insurance_context
        )

        assert result is not None
        assert result == sample_selected_benefit

    def test_select_benefit_with_highest_member_pay_no_matching_code(
        self, sample_selected_benefit, sample_insurance_context
    ):
        """Test selecting benefit when no benefit code matches"""
        sample_insurance_context.benefit_id = "999"  # Different code
        selected_benefits = [sample_selected_benefit]

        result = CostEstimatorResponse.select_benefit(
            selected_benefits, sample_insurance_context
        )

        assert result is not None
        assert (
            result == sample_selected_benefit
        )  # Should return first benefit when no match

    def test_select_benefit_with_highest_member_pay_empty_list(
        self, sample_insurance_context
    ):
        """Test selecting benefit from empty list"""
        selected_benefits = []

        result = CostEstimatorResponse.select_benefit(
            selected_benefits, sample_insurance_context
        )

        assert result is None

    def test_build_accumulator_info_limit(self, sample_insurance_context):
        """Test building accumulator info for limit type"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "limit"
        mock_accumulator.level = "individual"
        mock_accumulator.limitValue = 1000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 500.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "limit"
        assert result[0].accumulator.level == "individual"
        assert result[0].accumulator.limitValue == 1000.0
        from app.schemas.cost_estimator_response import AccumulatorWithLimitType

        assert isinstance(result[0].accumulator, AccumulatorWithLimitType)
        assert result[0].accumulator.limitType == "dollar"
        assert result[0].accumulator.calculatedValue == 500.0

    def test_build_accumulator_info_deductible_individual(
        self, sample_insurance_context
    ):
        """Test building accumulator info for individual deductible"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "deductible"
        mock_accumulator.level = "individual"
        mock_accumulator.limitValue = 1000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 200.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "deductible"
        assert result[0].accumulator.level == "individual"
        assert result[0].accumulatorCalculation.remainingValue == 200.0

    def test_build_accumulator_info_deductible_family(self, sample_insurance_context):
        """Test building accumulator info for family deductible"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "deductible"
        mock_accumulator.level = "family"
        mock_accumulator.limitValue = 2000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 400.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "deductible"
        assert result[0].accumulator.level == "family"
        assert result[0].accumulatorCalculation.remainingValue == 400.0

    def test_build_accumulator_info_oopmax_individual(self, sample_insurance_context):
        """Test building accumulator info for individual OOP max"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "oop max"
        mock_accumulator.level = "individual"
        mock_accumulator.limitValue = 5000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 250.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "oop max"
        assert result[0].accumulator.level == "individual"
        assert result[0].accumulatorCalculation.remainingValue == 250.0

    def test_build_accumulator_info_oopmax_family(self, sample_insurance_context):
        """Test building accumulator info for family OOP max"""
        # Create mock accumulator
        mock_accumulator = Mock()
        mock_accumulator.code = "oop max"
        mock_accumulator.level = "family"
        mock_accumulator.limitValue = 10000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 500.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context
        )

        assert len(result) == 1
        assert isinstance(result[0], AccumulatorInfo)
        assert result[0].accumulator.code == "oop max"
        assert result[0].accumulator.level == "family"
        assert result[0].accumulatorCalculation.remainingValue == 500.0

    def test_build_accumulator_info_unknown_type(self, sample_insurance_context):
        """Test building accumulator info for unknown accumulator type"""
        # Create mock accumulator with unknown code
        mock_accumulator = Mock()
        mock_accumulator.code = "unknown"
        mock_accumulator.level = "individual"
        mock_accumulator.limitValue = 1000.0
        mock_accumulator.limitType = "dollar"
        mock_accumulator.calculatedValue = 500.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context
        )

        assert len(result) == 0  # Should not process unknown accumulator types

    def test_build_accumulator_info_empty_list(self, sample_insurance_context):
        """Test building accumulator info with empty list"""
        accumulators = []

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context
        )

        assert len(result) == 0

    def test_build_accumulator_info_none_limit_type(self, sample_insurance_context):
        """Test building accumulator info with None limit type"""
        # Create mock accumulator with None limitType
        mock_accumulator = Mock()
        mock_accumulator.code = "limit"
        mock_accumulator.level = "individual"
        mock_accumulator.limitValue = 1000.0
        mock_accumulator.limitType = None
        mock_accumulator.calculatedValue = 500.0

        accumulators = [mock_accumulator]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context
        )

        assert len(result) == 1
        from app.schemas.cost_estimator_response import AccumulatorWithLimitType

        assert isinstance(result[0].accumulator, AccumulatorWithLimitType)
        assert (
            result[0].accumulator.limitType == ""
        )  # Should convert None to empty string

    def test_build_accumulator_info_multiple_accumulators(
        self, sample_insurance_context
    ):
        """Test building accumulator info with multiple accumulators"""
        # Create multiple mock accumulators
        mock_limit = Mock()
        mock_limit.code = "limit"
        mock_limit.level = "individual"
        mock_limit.limitValue = 1000.0
        mock_limit.limitType = "dollar"
        mock_limit.calculatedValue = 500.0

        mock_deductible = Mock()
        mock_deductible.code = "deductible"
        mock_deductible.level = "individual"
        mock_deductible.limitValue = 1000.0
        mock_deductible.limitType = "dollar"
        mock_deductible.calculatedValue = 200.0

        mock_oopmax = Mock()
        mock_oopmax.code = "oop max"
        mock_oopmax.level = "family"
        mock_oopmax.limitValue = 5000.0
        mock_oopmax.limitType = "dollar"
        mock_oopmax.calculatedValue = 500.0

        accumulators = [mock_limit, mock_deductible, mock_oopmax]

        result = CostEstimatorResponse.build_accumulator(
            accumulators, sample_insurance_context
        )

        assert len(result) == 3
        assert result[0].accumulator.code == "limit"
        assert result[1].accumulator.code == "deductible"
        assert result[2].accumulator.code == "oop max"
