import pytest
import pytest_asyncio
from unittest.mock import AsyncMock, patch
from app.repository.impl.cost_estimator_repository_impl import (
    CostEstimatorRepositoryImpl,
)
from app.models.rate_criteria import CostEstimatorRateCriteria
from app.models.rate_criteria import NegotiatedRate


@pytest.fixture
def sample_rate_criteria():
    return CostEstimatorRateCriteria(
        serviceCode="99214",
        placeOfService="11",
        serviceType="CPT4",
        zipCode="85305",
        providerIdentificationNumber="0004000317",
        networkId="58921",
        serviceLocationNumber="000761071",
        isOutofNetwork=False,
        providerSpecialtyCode="91017",
        providerType="HO",
    )


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_rate_claim_based_success(
    mock_config, mock_client_class, sample_rate_criteria
):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()
    mock_client.execute_query.return_value = [
        {"RATE": "250.00", "payment_method_cd": "FIXED"}
    ]
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    result = await repo.get_rate(sample_rate_criteria)

    assert isinstance(result, NegotiatedRate)
    assert result.rate == 250.00
    assert result.paymentMethod == "FIXED"
    assert result.isRateFound == True
    assert result.rateType == "AMOUNT"


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_rate_all_na_fallback_to_na(
    mock_config, mock_client_class, sample_rate_criteria
):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()
    mock_client.execute_query.side_effect = [
        [],  # Claim-based
        [],  # Provider Info
        [],  # Standard
    ]
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()

    # Expect RateNotFoundException when no rate is found
    from app.exception.exceptions import RateNotFoundException

    with pytest.raises(RateNotFoundException) as exc_info:
        await repo.get_rate(sample_rate_criteria)

    assert "Rate not found for the given parameters." in str(exc_info.value)


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_rate_out_of_network_success(
    mock_config, mock_client_class, sample_rate_criteria
):
    mock_config.is_valid.return_value = True
    sample_rate_criteria.isOutofNetwork = True

    mock_client = AsyncMock()
    mock_client.execute_query.return_value = [
        {"RATE": "300.00", "payment_method_cd": "PERBIL"}
    ]
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    result = await repo.get_rate(sample_rate_criteria)

    assert isinstance(result, NegotiatedRate)
    assert result.rate == 300.00
    assert result.paymentMethod == "PERBIL"
    assert result.isRateFound == True
    assert result.rateType == "PERCENTAGE"


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_rate_provider_info_to_standard_rate(
    mock_config, mock_client_class, sample_rate_criteria
):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()
    mock_client.execute_query.side_effect = [
        [],  # Claim-based
        [
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "None",
                "PRODUCT_CD": "PROD1",
                "RATING_SYSTEM_CD": "RS1",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA1",
            }
        ],  # Provider info -> contract_type = S
        [{"RATE": "200.00", "payment_method_cd": "FIXED"}],  # Standard rate
    ]
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    result = await repo.get_rate(sample_rate_criteria)

    assert isinstance(result, NegotiatedRate)
    assert result.rate == 200.00
    assert result.paymentMethod == "FIXED"
    assert result.isRateFound == True
    assert result.rateType == "AMOUNT"
