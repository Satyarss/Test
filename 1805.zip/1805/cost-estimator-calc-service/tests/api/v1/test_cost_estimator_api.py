"""
Live API testing for the Cost Estimator service.
These tests make real HTTP requests to the running API endpoints.
"""

import pytest
import asyncio
import time
import json
from typing import Dict, Any
from fastapi.testclient import TestClient
from app.main import app
from app.schemas.cost_estimator_request import CostEstimatorRequest


class TestLiveAPI:
    """Live API tests that make real HTTP requests."""

    @pytest.fixture(scope="class")
    def client(self):
        """Create a test client for the FastAPI app."""
        return TestClient(app)

    @pytest.fixture(scope="class")
    def sample_request_data(self) -> Dict[str, Any]:
        """Sample request data for live testing."""
        return {
            "membershipId": "5~186103331+10+7+20240101+793854+8A+829",
            "zipCode": "85305",
            "benefitProductType": "Medical",
            "languageCode": "11",
            "service": {
                "code": "99214",
                "type": "CPT4",
                "description": "Adult Office visit Age 30-39",
                "supportingService": {"code": "470", "type": "DRG"},
                "modifier": {"modifierCode": "E1"},
                "diagnosisCode": "F33 40",
                "placeOfService": {"code": "11"},
            },
            "providerInfo": [
                {
                    "serviceLocation": "000761071",
                    "providerType": "HO",
                    "speciality": {"code": "91017"},
                    "taxIdentificationNumber": "0000431173518",
                    "taxIdQualifier": "SN",
                    "providerNetworks": {"networkID": "58921"},
                    "providerIdentificationNumber": "0004000317",
                    "nationalProviderId": "1386660504",
                    "providerNetworkParticipation": {"providerTier": "1"},
                }
            ],
        }

    @pytest.fixture(scope="class")
    def headers(self) -> Dict[str, str]:
        """Sample headers for API requests."""
        return {
            "Content-Type": "application/json",
            "X-API-Key": "test-api-key-12345",
            "X-Correlation-ID": "test-correlation-123",
            "X-Client-Ref-ID": "test-client-456",
            "Authorization": "Bearer test-jwt-token",
            "EIE-Header-Action": "ESTIMATE_COST",
            "EIE-Header-Application-Identifier": "TEST_APP",
            "EIE-Header-Orchestrating-Application-Identifier": "TEST_ORCH",
            "EIE-Header-User-Context": "TEST_USER",
            "EIE-Header-Version": "1.0",
        }

    @pytest.mark.live_api
    def test_live_api_endpoint_availability(self, client):
        """Test that the API endpoint is available and responding."""
        # Test the health/status endpoint if available
        try:
            response = client.get("/")
            assert response.status_code in [200, 404, 405]  # Accept various responses
        except Exception:
            # If root endpoint doesn't exist, that's fine
            pass

        # Test the main cost estimator endpoint
        response = client.post("/costestimator/v1/rate", json={})
        # Should get validation error (400) rather than 404 (not found)
        assert response.status_code in [400, 422]  # Bad request or validation error

    @pytest.mark.live_api
    def test_live_api_request_validation(self, client, sample_request_data):
        """Test live API request validation."""
        # Test with valid request data
        print(sample_request_data)
        response = client.post("/costestimator/v1/rate", json=sample_request_data)
        print(response.json())

        # Should get a response (could be success or error depending on external services)
        assert response.status_code in [200, 400, 500]

        # Validate response structure
        if response.status_code == 200:
            result = response.json()
            # Check if it's a success or error response
            if "status" in result:
                assert result["status"] in ["success", "error"]
            else:
                # Direct response object
                assert "costEstimateResponse" in result or "error" in result

    @pytest.mark.live_api
    def test_live_api_with_headers(self, client, sample_request_data, headers):
        """Test live API with various headers."""
        response = client.post(
            "/costestimator/v1/rate", json=sample_request_data, headers=headers
        )

        # Should get a response
        assert response.status_code in [200, 400, 500]

        # Check that headers were processed (log entries would show this)
        result = response.json()
        assert result is not None

    @pytest.mark.live_api
    def test_live_api_response_time(self, client, sample_request_data):
        """Test API response time performance."""
        start_time = time.time()

        response = client.post("/costestimator/v1/rate", json=sample_request_data)

        end_time = time.time()
        response_time = end_time - start_time

        # Should get a response
        assert response.status_code in [200, 400, 500]

        # Response time should be reasonable (adjust threshold as needed)
        assert response_time < 30.0  # 30 seconds max

        print(f"API Response Time: {response_time:.2f} seconds")

    @pytest.mark.live_api
    def test_live_api_error_handling(self, client):
        """Test live API error handling with invalid data."""
        # Test with missing required fields
        invalid_request = {"membershipId": "invalid"}

        response = client.post("/costestimator/v1/rate", json=invalid_request)

        # Should get validation error
        assert response.status_code in [400, 422]

        result = response.json()
        assert "detail" in result or "error" in result

    @pytest.mark.live_api
    def test_live_api_concurrent_requests(self, client, sample_request_data):
        """Test API performance under concurrent load."""
        import concurrent.futures

        def make_request():
            response = client.post("/costestimator/v1/rate", json=sample_request_data)
            return response.status_code

        # Make 5 concurrent requests
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(make_request) for _ in range(5)]
            results = [future.result() for future in futures]

        # All requests should complete
        assert len(results) == 5

        # All should return valid status codes
        for status_code in results:
            assert status_code in [200, 400, 500]

    @pytest.mark.live_api
    def test_live_api_data_persistence(self, client, sample_request_data):
        """Test that API requests are properly logged/persisted."""
        # Make a request
        response = client.post("/costestimator/v1/rate", json=sample_request_data)

        # Should get a response
        assert response.status_code in [200, 400, 500]

        # Check if response has correlation ID or tracking info
        result = response.json()

        # If it's an error response, it might have error details
        if response.status_code != 200:
            assert "detail" in result or "error" in result
        else:
            # Success response should have proper structure
            if "status" in result:
                assert result["status"] in ["success", "error"]

    @pytest.mark.live_api
    def test_live_api_rate_limiting(self, client, sample_request_data):
        """Test API rate limiting behavior."""
        # Make multiple rapid requests
        responses = []
        for i in range(10):
            response = client.post("/costestimator/v1/rate", json=sample_request_data)
            responses.append(response.status_code)
            time.sleep(0.1)  # Small delay between requests

        # All requests should complete (rate limiting might be disabled in dev)
        assert len(responses) == 10

        # Check response status codes
        for status_code in responses:
            assert status_code in [200, 400, 500]

    @pytest.mark.live_api
    def test_live_api_authentication(self, client, sample_request_data):
        """Test API authentication requirements."""
        # Test without authentication headers
        response = client.post("/costestimator/v1/rate", json=sample_request_data)

        # Should still work (authentication might be optional in dev)
        assert response.status_code in [200, 400, 500]

        # Test with invalid authentication
        invalid_headers = {"Authorization": "Bearer invalid-token"}
        response = client.post(
            "/costestimator/v1/rate", json=sample_request_data, headers=invalid_headers
        )

        # Should still work (authentication validation might be disabled in dev)
        assert response.status_code in [200, 400, 500]

    @pytest.mark.live_api
    def test_live_api_schema_validation(self, client):
        """Test API schema validation with various data types."""
        test_cases = [
            # Valid case
            {
                "membershipId": "5~186103331+10+7+20240101+793854+8A+829",
                "zipCode": "85305",
                "benefitProductType": "Medical",
                "languageCode": "11",
                "service": {"code": "99214", "type": "CPT4"},
                "providerInfo": [],
            },
            # Invalid membership ID
            {
                "membershipId": "invalid",
                "zipCode": "85305",
                "benefitProductType": "Medical",
                "languageCode": "11",
                "service": {"code": "99214", "type": "CPT4"},
                "providerInfo": [],
            },
            # Missing required fields
            {"membershipId": "5~186103331+10+7+20240101+793854+8A+829"},
        ]

        for i, test_case in enumerate(test_cases):
            response = client.post("/costestimator/v1/rate", json=test_case)

            # Should get appropriate response
            if i == 0:  # Valid case
                assert response.status_code in [200, 400, 500]
            else:  # Invalid cases
                assert response.status_code in [400, 422]  # Validation error

    @pytest.mark.live_api
    def test_live_api_end_to_end_workflow(self, client, sample_request_data):
        """Test complete end-to-end workflow."""
        # Step 1: Make initial request
        response = client.post("/costestimator/v1/rate", json=sample_request_data)
        print(response.json())
        assert response.status_code in [200, 400, 500]

        # Step 2: Make same request again (test caching/idempotency)
        response2 = client.post("/costestimator/v1/rate", json=sample_request_data)
        assert response2.status_code in [200, 400, 500]

        # Step 3: Make request with slight modification
        modified_data = sample_request_data.copy()
        modified_data["zipCode"] = "85306"  # Different zip code

        response3 = client.post("/costestimator/v1/rate", json=modified_data)
        assert response3.status_code in [200, 400, 500]

        # All requests should complete
        assert all(
            r.status_code in [200, 400, 500] for r in [response, response2, response3]
        )

    @pytest.mark.live_api
    def test_live_api_health_check(self, client):
        """Test API health and status endpoints."""
        # Test if there are any health check endpoints
        health_endpoints = ["/health", "/status", "/ping", "/ready"]

        for endpoint in health_endpoints:
            try:
                response = client.get(endpoint)
                if response.status_code == 200:
                    print(f"Health endpoint found: {endpoint}")
                    break
            except Exception:
                continue
        else:
            print("No health endpoints found - this is acceptable")

    @pytest.mark.live_api
    def test_live_api_metrics(self, client):
        """Test if API provides metrics or monitoring endpoints."""
        # Test common metrics endpoints
        metrics_endpoints = ["/metrics", "/stats", "/debug", "/admin"]

        for endpoint in metrics_endpoints:
            try:
                response = client.get(endpoint)
                if response.status_code in [200, 401, 403]:  # Success or auth required
                    print(f"Metrics endpoint found: {endpoint}")
                    break
            except Exception:
                continue
        else:
            print("No metrics endpoints found - this is acceptable")


if __name__ == "__main__":
    # Run tests directly
    pytest.main([__file__, "-v", "-s", "-m", "live_api"])
