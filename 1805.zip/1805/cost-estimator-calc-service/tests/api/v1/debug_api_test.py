#!/usr/bin/env python3
"""
Debug script for test_cost_estimator_api issues.
This script helps isolate and debug the Pydantic validation errors.
"""

import json
import asyncio
from fastapi.testclient import TestClient
from app.main import app
from app.schemas.cost_estimator_request import CostEstimatorRequest


def debug_api_request():
    """Debug a single API request to understand the validation errors."""

    # Sample request data (same as in the test)
    sample_request_data = {
        "membershipId": "5~186103331+10+7+20240101+793854+8A+829",
        "zipCode": "85305",
        "benefitProductType": "Medical",
        "languageCode": "11",
        "service": {
            "code": "99214",
            "type": "CPT4",
            "description": "Adult Office visit Age 30-39",
            "supportingService": {"code": "470", "type": "DRG"},
            "modifier": {"modifierCode": "E1"},
            "diagnosisCode": "F33 40",
            "placeOfService": {"code": "11"},
        },
        "providerInfo": [
            {
                "serviceLocation": "000761071",
                "providerType": "HO",
                "speciality": {"code": "91017"},
                "taxIdentificationNumber": "0000431173518",
                "taxIdQualifier": "SN",
                "providerNetworks": {"networkID": "58921"},
                "providerIdentificationNumber": "0004000317",
                "nationalProviderId": "1386660504",
                "providerNetworkParticipation": {"providerTier": "1"},
            }
        ],
    }

    # Create test client
    client = TestClient(app)

    print("=== API Request Debug ===")
    print(f"Request URL: /costestimator/v1/rate")
    print(f"Request Data: {json.dumps(sample_request_data, indent=2)}")
    print()

    try:
        # Make the request
        response = client.post("/costestimator/v1/rate", json=sample_request_data)

        print(f"Response Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")
        print()

        # Try to get response JSON
        try:
            response_json = response.json()
            print(f"Response JSON: {json.dumps(response_json, indent=2)}")
        except Exception as e:
            print(f"Could not parse response as JSON: {e}")
            print(f"Response Text: {response.text}")

        print()
        print("=== Analysis ===")

        if response.status_code == 500:
            print(
                "❌ Server Error (500) - This indicates the Pydantic validation error"
            )
            print("The error is happening in the get_accumulator method")
            print("The external service is returning malformed data for dependents")
        elif response.status_code == 200:
            print("✅ Success (200) - Request processed successfully")
        elif response.status_code in [400, 422]:
            print("⚠️  Client Error (400/422) - Validation error in request")
        else:
            print(f"❓ Unexpected status code: {response.status_code}")

    except Exception as e:
        print(f"❌ Exception during request: {e}")
        import traceback

        traceback.print_exc()


def debug_pydantic_validation():
    """Debug the specific Pydantic validation error."""

    print("=== Pydantic Validation Debug ===")

    # The error shows these fields are missing:
    missing_fields = [
        "readAccumulatorsResponse.memberships.dependents.0.privacyRestriction",
        "readAccumulatorsResponse.memberships.dependents.0.membershipIdentifier.resourceId",
        "readAccumulatorsResponse.memberships.dependents.0.accumulators",
    ]

    print("Missing fields in AccumulatorResponse:")
    for field in missing_fields:
        print(f"  - {field}")

    print()
    print("=== Root Cause Analysis ===")
    print("1. The external accumulator service is returning malformed data")
    print("2. The dependents array contains objects missing required fields")
    print("3. This causes Pydantic validation to fail")
    print("4. The API returns a 500 error with validation details")

    print()
    print("=== Potential Solutions ===")
    print("1. Fix the external service to return proper data")
    print("2. Add validation/transformation in the service layer")
    print("3. Make the fields optional in the Pydantic model")
    print("4. Add error handling to gracefully handle malformed data")


def debug_test_environment():
    """Debug the test environment setup."""

    print("=== Test Environment Debug ===")

    # Check if we can import the main app
    try:
        from app.main import app

        print("✅ App imports successfully")
    except Exception as e:
        print(f"❌ App import failed: {e}")
        return

    # Check if we can create a test client
    try:
        client = TestClient(app)
        print("✅ TestClient created successfully")
    except Exception as e:
        print(f"❌ TestClient creation failed: {e}")
        return

    # Check if the endpoint exists
    try:
        response = client.post("/costestimator/v1/rate", json={})
        print(f"✅ Endpoint exists (status: {response.status_code})")
    except Exception as e:
        print(f"❌ Endpoint test failed: {e}")


if __name__ == "__main__":
    print("🔍 Cost Estimator API Debug Tool")
    print("=" * 50)

    debug_test_environment()
    print()

    debug_pydantic_validation()
    print()

    debug_api_request()
    print()

    print("🎯 Debug Complete!")
    print("Check the output above for issues and potential solutions.")
