import pytest
from unittest.mock import Mock, AsyncMock, patch
from app.services.impl.cost_estimation_service_impl import CostEstimationServiceImpl
from app.schemas.cost_estimator_request import CostEstimatorRequest
from app.schemas.benefit_response import BenefitApiResponse
from app.schemas.accumulator_response import AccumulatorResponse


@pytest.fixture
def sample_request_data():
    """Sample request data for testing."""
    return {
        "membershipId": "5~186103331+10+7+20240101+793854+8A+829",
        "zipCode": "85305",
        "benefitProductType": "Medical",
        "languageCode": "11",
        "service": {
            "code": "99214",
            "type": "CPT4",
            "description": "Adult Office visit Age 30-39",
            "supportingService": {"code": "470", "type": "DRG"},
            "modifier": {"modifierCode": "E1"},
            "diagnosisCode": "F33 40",
            "placeOfService": {"code": "11"},
        },
        "providerInfo": [
            {
                "serviceLocation": "000761071",
                "providerType": "HO",
                "speciality": {"code": "91017"},
                "taxIdentificationNumber": "0000431173518",
                "taxIdQualifier": "SN",
                "providerNetworks": {"networkID": "58921"},
                "providerIdentificationNumber": "0004000317",
                "nationalProviderId": "1386660504",
                "providerNetworkParticipation": {"providerTier": "1"},
            }
        ],
    }


@pytest.fixture
def sample_benefit_response():
    """Sample benefit response for testing."""
    return {
        "serviceInfo": [
            {
                "benefit": [
                    {
                        "benefitTierName": "1",
                        "coverage": [
                            {
                                "isServiceCovered": "Y",
                                "costShareCopay": 25.0,
                                "costShareCoinsurance": 20.0,
                                "relatedAccumulators": [
                                    {
                                        "code": "Deductible",
                                        "level": "Individual",
                                        "networkIndicator": "InNetwork",
                                    }
                                ],
                            }
                        ],
                    }
                ]
            }
        ]
    }


@pytest.fixture
def sample_accumulator_response():
    """Sample accumulator response for testing."""
    return {
        "readAccumulatorsResponse": {
            "memberships": {
                "dependents": [
                    {
                        "accumulators": [
                            {
                                "code": "Deductible",
                                "level": "Individual",
                                "limitValue": "5000",
                                "calculatedValue": "345",
                                "networkIndicator": "InNetwork",
                            }
                        ]
                    }
                ]
            }
        }
    }


@pytest.mark.asyncio
@patch("app.services.impl.cost_estimation_service_impl.BenefitServiceImpl")
@patch("app.services.impl.cost_estimation_service_impl.AccumulatorServiceImpl")
@patch("app.services.impl.cost_estimation_service_impl.CostEstimatorRepositoryImpl")
async def test_cost_estimate_response_structure(
    mock_repo,
    mock_accumulator,
    mock_benefit,
    sample_request_data,
    sample_benefit_response,
    sample_accumulator_response,
):
    """Test that the cost estimation service returns the correct response structure."""

    # Setup mocks
    mock_repo_instance = Mock()
    mock_repo_instance.get_rate = AsyncMock(return_value=150.50)
    mock_repo.return_value = mock_repo_instance

    mock_benefit_instance = Mock()
    mock_benefit_instance.get_benefit = AsyncMock(return_value=sample_benefit_response)
    mock_benefit.return_value = mock_benefit_instance

    mock_accumulator_instance = Mock()
    mock_accumulator_instance.get_accumulator = AsyncMock(
        return_value=sample_accumulator_response
    )
    mock_accumulator.return_value = mock_accumulator_instance

    # Create service and test
    service = CostEstimationServiceImpl()
    request = CostEstimatorRequest(**sample_request_data)

    result = await service.estimate_cost(request)

    # Handle both success (CostEstimatorResponse) and error (dict) cases
    if isinstance(result, dict):
        # Error case - should have status and message
        assert result["status"] == "error"
        return

    # Success case - result is a CostEstimatorResponse object
    assert hasattr(result, "costEstimateResponse")

    cost_estimate_response = result.costEstimateResponse

    # Verify service information
    assert hasattr(cost_estimate_response, "service")
    service_info = cost_estimate_response.service
    assert service_info.code == "99214"
    assert service_info.type == "CPT4"
    assert service_info.description == "Adult Office visit Age 30-39"
    assert service_info.supportingService.code == "470"
    assert service_info.modifier.modifierCode == "E1"
    assert service_info.diagnosisCode == "F33 40"
    assert service_info.placeOfService.code == "11"

    # Verify costEstimateResponseInfo
    assert hasattr(cost_estimate_response, "costEstimateResponseInfo")
    response_info_list = cost_estimate_response.costEstimateResponseInfo
    assert len(response_info_list) == 1

    response_info = response_info_list[0]

    # Verify provider info
    assert hasattr(response_info, "providerInfo")
    provider_info = response_info.providerInfo
    assert provider_info.serviceLocation == "000761071"
    assert provider_info.providerType == "HO"
    assert provider_info.providerNetworkParticipation.providerTier == "1"

    # Verify coverage info
    assert hasattr(response_info, "coverage")
    coverage = response_info.coverage
    assert hasattr(coverage, "isServiceCovered")
    assert hasattr(coverage, "maxCoverageAmount")
    assert hasattr(coverage, "costShareCopay")
    assert hasattr(coverage, "costShareCoinsurance")

    # Verify cost info
    assert hasattr(response_info, "cost")
    cost = response_info.cost
    assert hasattr(cost, "inNetworkCosts")
    assert hasattr(cost, "outOfNetworkCosts")
    assert hasattr(cost, "inNetworkCostsType")

    # Verify health claim line
    assert hasattr(response_info, "healthClaimLine")
    health_claim_line = response_info.healthClaimLine
    assert hasattr(health_claim_line, "amountCopay")
    assert hasattr(health_claim_line, "amountCoinsurance")
    assert hasattr(health_claim_line, "amountResponsibility")
    assert hasattr(health_claim_line, "percentResponsibility")
    assert hasattr(health_claim_line, "amountpayable")

    # Verify accumulators
    assert hasattr(response_info, "accumulators")
    accumulators = response_info.accumulators
    assert isinstance(accumulators, list)


@pytest.mark.asyncio
@patch("app.services.impl.cost_estimation_service_impl.BenefitServiceImpl")
@patch("app.services.impl.cost_estimation_service_impl.AccumulatorServiceImpl")
@patch("app.services.impl.cost_estimation_service_impl.CostEstimatorRepositoryImpl")
async def test_member_pay_attributes_in_response(
    mock_repo,
    mock_accumulator,
    mock_benefit,
    sample_request_data,
    sample_benefit_response,
    sample_accumulator_response,
):
    """Test that member_pay_attributes are included in the response."""

    # Setup mocks
    mock_repo_instance = Mock()
    mock_repo_instance.get_rate = AsyncMock(return_value=150.50)
    mock_repo.return_value = mock_repo_instance

    mock_benefit_instance = Mock()
    mock_benefit_instance.get_benefit = AsyncMock(return_value=sample_benefit_response)
    mock_benefit.return_value = mock_benefit_instance

    mock_accumulator_instance = Mock()
    mock_accumulator_instance.get_accumulator = AsyncMock(
        return_value=sample_accumulator_response
    )
    mock_accumulator.return_value = mock_accumulator_instance

    # Create service and test
    service = CostEstimationServiceImpl()
    request = CostEstimatorRequest(**sample_request_data)

    result = await service.estimate_cost(request)

    # Handle both success (CostEstimatorResponse) and error (dict) cases
    if isinstance(result, dict):
        # Error case - should have status and message
        assert result["status"] == "error"
        return

    # Success case - result is a CostEstimatorResponse object
    # Get the response info for the first provider
    response_info = result.costEstimateResponse.costEstimateResponseInfo[0]

    # Verify the response structure matches the schema
    assert hasattr(response_info, "providerInfo")
    assert hasattr(response_info, "coverage")
    assert hasattr(response_info, "cost")
    assert hasattr(response_info, "healthClaimLine")
    assert hasattr(response_info, "accumulators")

    # Verify provider info
    assert response_info.providerInfo.serviceLocation == "000761071"
    assert response_info.providerInfo.providerType == "HO"
    assert response_info.providerInfo.providerNetworkParticipation.providerTier == "1"

    # Verify coverage info
    assert response_info.coverage.isServiceCovered == "Y"
    assert response_info.coverage.maxCoverageAmount >= 0
    assert response_info.coverage.costShareCopay >= 0
    assert response_info.coverage.costShareCoinsurance >= 0

    # Verify cost info
    assert response_info.cost.inNetworkCosts >= 0
    assert response_info.cost.outOfNetworkCosts >= 0
    assert response_info.cost.inNetworkCostsType == "Amount"

    # Verify health claim line
    assert response_info.healthClaimLine.amountCopay >= 0
    assert response_info.healthClaimLine.amountCoinsurance >= 0
    assert response_info.healthClaimLine.amountResponsibility >= 0
    assert isinstance(response_info.healthClaimLine.percentResponsibility, str)
    assert response_info.healthClaimLine.amountpayable >= 0

    # Verify accumulators
    assert isinstance(response_info.accumulators, list)
