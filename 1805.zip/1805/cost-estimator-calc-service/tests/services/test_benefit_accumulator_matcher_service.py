from typing import Dict, Any
import pytest
import json
import os
from unittest.mock import AsyncMock, patch
from app.services.impl.cost_estimation_service_impl import CostEstimationServiceImpl
from app.schemas.cost_estimator_request import CostEstimatorRequest
from app.schemas.benefit_response import BenefitApiResponse
from app.schemas.accumulator_response import AccumulatorResponse, Accumulator
from app.schemas.benefit_response import Benefit
from app.services.impl.benefit_accumulator_matcher_service_impl import (
    BenefitAccumulatorMatcherServiceImpl,
)
from app.exception.exceptions import BenefitsNotFoundException

# Load the JSON file
mock_data_path = os.path.join(
    os.path.dirname(__file__),
    "..",
    "mock-data",
)


@pytest.fixture
def cost_estimator_request_fixtures() -> Dict[str, CostEstimatorRequest]:
    requests = {}
    for folder_name in os.listdir(mock_data_path):
        folder_path = os.path.join(mock_data_path, folder_name)
        if os.path.isdir(folder_path):
            cost_estimator_request_file = os.path.join(
                folder_path, "CostEstimatorRequest.json"
            )
            if os.path.exists(cost_estimator_request_file):
                with open(cost_estimator_request_file, "r") as f:
                    cost_estimator_request_data = json.load(f)
                    requests[folder_name] = CostEstimatorRequest(
                        **cost_estimator_request_data
                    )
    return requests


@pytest.fixture
def benefit_response_fixtures() -> Dict[str, BenefitApiResponse]:
    responses = {}
    for folder_name in os.listdir(mock_data_path):
        folder_path = os.path.join(mock_data_path, folder_name)
        if os.path.isdir(folder_path):
            benefit_response_file = os.path.join(folder_path, "BenefitApiResponse.json")
            if os.path.exists(benefit_response_file):
                with open(benefit_response_file, "r") as f:
                    benefit_data = json.load(f)
                    responses[folder_name] = BenefitApiResponse(**benefit_data)
    return responses


@pytest.fixture
def benefit_fixtures(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
) -> Dict[str, Benefit]:
    benefits = {}
    for key, response in benefit_response_fixtures.items():
        benefits[key] = response.serviceInfo[0].benefit[0]
    return benefits


@pytest.fixture
def accumulator_data_fixtures() -> Dict[str, Any]:
    data = {}
    for folder_name in os.listdir(mock_data_path):
        folder_path = os.path.join(mock_data_path, folder_name)
        if os.path.isdir(folder_path):
            accumulator_data_file = os.path.join(
                folder_path, "AccumulatorResponse.json"
            )
            if os.path.exists(accumulator_data_file):
                with open(accumulator_data_file, "r") as f:
                    data[folder_name] = json.load(f)
    return data


@pytest.fixture
def accumulator_response_fixtures(
    accumulator_data_fixtures: Dict[str, Any],
) -> Dict[str, AccumulatorResponse]:
    responses = {}
    for key, data in accumulator_data_fixtures.items():
        responses[key] = AccumulatorResponse(**data)
    return responses


@pytest.fixture
def benefit_accumulator_matcher_service_fixture() -> (
    BenefitAccumulatorMatcherServiceImpl
):
    return BenefitAccumulatorMatcherServiceImpl()


def _get_selected_benefits(
    benefit_response: BenefitApiResponse,
    accumulator_response: AccumulatorResponse,
    cost_estimator_request: CostEstimatorRequest,
    accumulator_data: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
    isOutofNetwork: bool,
    expected_num_selected_benefits: int,
    expected_num_matched_accumulators: int = 0,
    accumulator_data_index: int = 0,
):

    if expected_num_selected_benefits == 0:
        # Expect BenefitsNotFoundException when no benefits should be found
        with pytest.raises(BenefitsNotFoundException):
            benefit_accumulator_matcher_service_fixture.get_selected_benefits(
                cost_estimator_request.membershipId,
                benefit_response,
                accumulator_response,
                cost_estimator_request,
                isOutofNetwork,
            )
    else:
        selected_benefits = (
            benefit_accumulator_matcher_service_fixture.get_selected_benefits(
                cost_estimator_request.membershipId,
                benefit_response,
                accumulator_response,
                cost_estimator_request,
                isOutofNetwork,
            )
        )
        assert selected_benefits is not None
        assert len(selected_benefits) == expected_num_selected_benefits
        if expected_num_selected_benefits > 0:
            assert selected_benefits[0].coverage.matchedAccumulators is not None
            assert (
                len(selected_benefits[0].coverage.matchedAccumulators)
                == expected_num_matched_accumulators
            )
            assert selected_benefits[0].coverage.matchedAccumulators[0] == Accumulator(
                **accumulator_data["readAccumulatorsResponse"]["memberships"][
                    "subscriber"
                ]["accumulators"][accumulator_data_index]
            )


def test_get_selected_benefits_in_network_without_tiering_without_designation(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    benefit_response = benefit_response_fixtures["sample2-no_tiering_no_designation"]
    accumulator_response = accumulator_response_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    accumulator_data = accumulator_data_fixtures["sample2-no_tiering_no_designation"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=False,
        expected_num_selected_benefits=2,
        expected_num_matched_accumulators=1,
        accumulator_data_index=28,
    )


def test_get_selected_benefits_in_network_without_tiering_non_pcp_designation(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    cost_estimator_request.providerInfo[0].speciality.code = "91017"
    benefit_response = benefit_response_fixtures["sample2-no_tiering_no_designation"]
    accumulator_response = accumulator_response_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    accumulator_data = accumulator_data_fixtures["sample2-no_tiering_no_designation"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=False,
        expected_num_selected_benefits=2,
        expected_num_matched_accumulators=1,
        accumulator_data_index=28,
    )
    cost_estimator_request.providerInfo[0].speciality.code = ""  # needed?


def test_get_selected_benefits_in_network_without_tiering_with_designation(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    cost_estimator_request.providerInfo[0].speciality.code = "10101"
    benefit_response = benefit_response_fixtures["sample2-no_tiering_no_designation"]
    accumulator_response = accumulator_response_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    accumulator_data = accumulator_data_fixtures["sample2-no_tiering_no_designation"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=False,
        expected_num_selected_benefits=1,
        expected_num_matched_accumulators=1,
        accumulator_data_index=28,
    )
    cost_estimator_request.providerInfo[0].speciality.code = ""  # needed?


def test_get_selected_benefits_in_network_with_tiering_with_non_pcp_designation(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures["sample1-with_tiering"]
    benefit_response = benefit_response_fixtures["sample1-with_tiering"]
    accumulator_response = accumulator_response_fixtures["sample1-with_tiering"]
    accumulator_data = accumulator_data_fixtures["sample1-with_tiering"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=False,
        expected_num_selected_benefits=2,
        expected_num_matched_accumulators=2,
        accumulator_data_index=2,
    )


def test_get_selected_benefits_in_network_with_tiering_with_designation(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures["sample1-with_tiering"]
    cost_estimator_request.providerInfo[0].speciality.code = "10101"
    benefit_response = benefit_response_fixtures["sample1-with_tiering"]
    accumulator_response = accumulator_response_fixtures["sample1-with_tiering"]
    accumulator_data = accumulator_data_fixtures["sample1-with_tiering"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=False,
        expected_num_selected_benefits=1,
        expected_num_matched_accumulators=2,
        accumulator_data_index=2,
    )
    cost_estimator_request.providerInfo[0].speciality.code = "91017"  # needed?


def test_get_selected_benefits_in_network_with_tiering_non_pcp_designation_empty(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures["sample3-with_tiering2"]
    cost_estimator_request.providerInfo[0].providerNetworkParticipation.providerTier = (
        "6"
    )
    benefit_response = benefit_response_fixtures["sample3-with_tiering2"]
    accumulator_response = accumulator_response_fixtures["sample3-with_tiering2"]
    accumulator_data = accumulator_data_fixtures["sample3-with_tiering2"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=False,
        expected_num_selected_benefits=0,
    )
    cost_estimator_request.providerInfo[0].providerNetworkParticipation.providerTier = (
        "1"  # needed?
    )


def test_get_selected_benefits_in_network_with_tiering_pcp_designation_empty(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures["sample3-with_tiering2"]
    cost_estimator_request.providerInfo[0].speciality.code = "10101"
    benefit_response = benefit_response_fixtures["sample3-with_tiering2"]
    accumulator_response = accumulator_response_fixtures["sample3-with_tiering2"]
    accumulator_data = accumulator_data_fixtures["sample3-with_tiering2"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=False,
        expected_num_selected_benefits=0,
    )
    cost_estimator_request.providerInfo[0].speciality.code = "91017"  # needed?


def test_get_selected_benefits_out_of_network_without_tiering_without_designation(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    benefit_response = benefit_response_fixtures["sample2-no_tiering_no_designation"]
    accumulator_response = accumulator_response_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    accumulator_data = accumulator_data_fixtures["sample2-no_tiering_no_designation"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=True,
        expected_num_selected_benefits=2,
        expected_num_matched_accumulators=2,
        accumulator_data_index=0,
    )


def test_get_selected_benefits_out_of_network_without_tiering_with_designation(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    cost_estimator_request.providerInfo[0].speciality.code = "10101"
    benefit_response = benefit_response_fixtures["sample2-no_tiering_no_designation"]
    accumulator_response = accumulator_response_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    accumulator_data = accumulator_data_fixtures["sample2-no_tiering_no_designation"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=True,
        expected_num_selected_benefits=1,
        expected_num_matched_accumulators=2,
        accumulator_data_index=0,
    )
    cost_estimator_request.providerInfo[0].speciality.code = ""  # needed?


def test_get_selected_benefits_out_of_network_without_tiering_with_code_is_empty(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures[
        "sample1-with_code_is_empty"
    ]
    cost_estimator_request.providerInfo[0].speciality.code = "10101"
    benefit_response = benefit_response_fixtures["sample1-with_code_is_empty"]
    accumulator_response = accumulator_response_fixtures["sample1-with_code_is_empty"]
    accumulator_data = accumulator_data_fixtures["sample1-with_code_is_empty"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=True,
        expected_num_selected_benefits=1,
        expected_num_matched_accumulators=2,
        accumulator_data_index=0,
    )
    cost_estimator_request.providerInfo[0].speciality.code = ""  # needed?
