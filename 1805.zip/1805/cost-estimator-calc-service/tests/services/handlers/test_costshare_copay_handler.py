#!/usr/bin/env python3
"""
Tests for the CalculationService class and interface.
"""

import sys
import os
from unittest.mock import Mock, patch

import pytest
from app.services.impl.calculation_service_impl import CalculationServiceImpl
from app.core.base import (
    InsuranceContext,
    MatchedAccumulator,
)
from app.models.selected_benefit import (
    SelectedBenefit,
    SelectedCoverage,
)
from app.schemas.accumulator_response import (
    EffectivePeriod,
)
from app.schemas.benefit_response import (
    BenefitTier,
    Prerequisite,
    ServiceProviderItem,
)
from app.services.calculation_service import (
    CalculationServiceInterface,
)
from tests.services.handlers.test_data import (
    mock_matched_accumulator_individual_oopmax,
    mock_matched_accumulator_family_oopmax,
    mock_matched_accumulator_individual_deductible,
    mock_main,
    MockBenefit,
    MockCoverage,
)

# Add the project root to Python path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, project_root)


class TestCalculationService:
    """Test the CalculationService implementation"""

    def setup_method(self):
        """Set up test fixtures"""
        self.calculation_service = CalculationServiceImpl()

    def test_calculation_service_implements_interface(self):
        """Test that CalculationService implements the interface"""
        assert isinstance(self.calculation_service, CalculationServiceInterface)

    def test_calculation_service_has_chain(self):
        """Test that CalculationService has a calculation chain"""
        assert hasattr(self.calculation_service, "chain")
        assert self.calculation_service.chain is not None
    

    def test_ind_find_highest_member_pay_copay_greater_than_service_amount_lesser_than_oopmax(
        self,
    ):  # revisit later
        """Test find_highest_member_pay with benefit that has OOP max > service amount and copay > service amount"""
        # Create a benefit with OOP max accumulator

        # Create a benefit with limit accumulator with calculatedValue=0 (only override this value)
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=500)
        #matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=1000)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max", costShareCopay=300.0
            ),
            matched_accumulators=[matched_accum],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(
            service_amount, [benefit]
        )
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_member_pays_service_amount was called (look for its trace message)
        _apply_member_pays_service_amount = False
        for trace in result.trace_entries:
            if "_apply_member_pays_service_amount" in trace.step:
                _apply_member_pays_service_amount = True
                print(
                    f"_apply_member_pays_service_amount trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_member_pays_service_amount
        ), "Expected _apply_member_pays_service_amount trace message not found"

        assert (
            result.service_amount == 0
        ), f"Expected service_amount to be 0, got {result.service_amount}"
        assert (
            insurance_pays == 0
        ), f"Expected insurance_pays to be 0, got {insurance_pays}"

        print(result)


    def test_find_highest_member_pay_copay_greater_than_service_amount_lesser_than_oopmax(
        self,
    ):  # revisit later
        """Test find_highest_member_pay with benefit that has OOP max > service amount and copay > service amount"""
        # Create a benefit with OOP max accumulator

        # Create a benefit with limit accumulator with calculatedValue=0 (only override this value)
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=500)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=1000)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max", costShareCopay=300.0
            ),
            matched_accumulators=[matched_accum, matched_accum2],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(
            service_amount, [benefit]
        )
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_member_pays_service_amount was called (look for its trace message)
        _apply_member_pays_service_amount = False
        for trace in result.trace_entries:
            if "_apply_member_pays_service_amount" in trace.step:
                _apply_member_pays_service_amount = True
                print(
                    f"_apply_member_pays_service_amount trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_member_pays_service_amount
        ), "Expected _apply_member_pays_service_amount trace message not found"

        assert (
            result.service_amount == 0
        ), f"Expected service_amount to be 0, got {result.service_amount}"
        assert (
            insurance_pays == 0
        ), f"Expected insurance_pays to be 0, got {insurance_pays}"

        print(result)

    def test_find_highest_member_pay_copay_greater_than_service_amount_greater_than_oopmax(
        self,
    ):  # revisit later
        """Test find_highest_member_pay with benefit that has OOP max < service amount and copay > service amount"""
        # Create a benefit with OOP max accumulator
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=50)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=100)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max", costShareCopay=300.0
            ),
            matched_accumulators=[matched_accum, matched_accum2],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(
            service_amount, [benefit]
        )
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_member_pays_full_amount was called (look for its trace message)
        _apply_member_pays_full_amount = False
        for trace in result.trace_entries:
            if "_apply_member_pays_full_amount" in trace.step:
                _apply_member_pays_full_amount = True
                print(
                    f"_apply_member_pays_full_amount trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_member_pays_full_amount
        ), "Expected _apply_member_pays_full_amount trace message not found"

        assert (
            result.service_amount == 0
        ), f"Expected service_amount to be 0, got {result.service_amount}"

        print(result)


    def test_find_highest_member_pay_copay_lesser_than_service_amount_copay_lesser_than_oopmax(
        self,
    ):  # revisit later
        """Test find_highest_member_pay with benefit that has OOP max > copay and copay < service amount"""
        # Create a benefit with OOP max accumulator
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=500)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=1000)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max", costShareCopay=100.0
            ),
            matched_accumulators=[matched_accum, matched_accum2],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(
            service_amount, [benefit]
        )
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_member_pays_cost_share_copay was called (look for its trace message)
        _apply_member_pays_cost_share_copay = False
        for trace in result.trace_entries:
            if "_apply_member_pays_cost_share_copay" in trace.step:
                _apply_member_pays_cost_share_copay = True
                print(
                    f"_apply_member_pays_cost_share_copay trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_member_pays_cost_share_copay
        ), "Expected _apply_member_pays_cost_share_copay trace message not found"

        assert (
            result.cost_share_copay == 0
        ), f"Expected cost_share_copay to be 0, got {result.cost_share_copay}"

        print(result)

    def test_find_highest_member_pay_copay_lesser_than_service_amount_and_copay_greater_than_oopmax(
        self,
    ):  # revisit later
        """Test find_highest_member_pay with benefit that has OOP max < copay and copay < service amount"""
        # Create a benefit with OOP max accumulator
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=50)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=100)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max", costShareCopay=150.0
            ),
            matched_accumulators=[matched_accum, matched_accum2],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(
            service_amount, [benefit]
        )
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_member_pays_cost_share_amount was called (look for its trace message)
        _apply_member_pays_cost_share_amount = False
        for trace in result.trace_entries:
            if "_apply_member_pays_cost_share_amount" in trace.step:
                _apply_member_pays_cost_share_amount = True
                print(
                    f"_apply_member_pays_cost_share_amount trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_member_pays_cost_share_amount
        ), "Expected _apply_member_pays_cost_share_amount trace message not found"

        assert (
            result.cost_share_copay == 0
        ), f"Expected cost_share_copay to be 0, got {result.cost_share_copay}"

        print(result)
