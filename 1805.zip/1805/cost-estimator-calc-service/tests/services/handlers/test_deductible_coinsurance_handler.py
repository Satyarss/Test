#!/usr/bin/env python3
"""
Tests for the CalculationService class and interface.
"""

import sys
import os
from unittest.mock import Mock, patch

import pytest
from app.services.impl.calculation_service_impl import CalculationServiceImpl
from app.core.base import (
    InsuranceContext,
    MatchedAccumulator,
)
from app.models.selected_benefit import (
    SelectedBenefit,
    SelectedCoverage,
)
from app.schemas.accumulator_response import (
    EffectivePeriod,
)
from app.schemas.benefit_response import (
    BenefitTier,
    Prerequisite,
    ServiceProviderItem,
)
from app.services.calculation_service import (
    CalculationServiceInterface,
)
from tests.services.handlers.test_data import (
    mock_matched_accumulator_individual_oopmax,
    mock_matched_accumulator_family_oopmax,
    mock_matched_accumulator_individual_deductible,
    mock_matched_accumulator_family_deductible,
    mock_main,
    MockBenefit,
    MockCoverage,
)
# Add the project root to Python path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, project_root)


class TestCalculationService:
    """Test the CalculationService implementation"""

    def setup_method(self):
        """Set up test fixtures"""
        self.calculation_service = CalculationServiceImpl()

    def test_calculation_service_implements_interface(self):
        """Test that CalculationService implements the interface"""
        assert isinstance(self.calculation_service, CalculationServiceInterface)

    def test_calculation_service_has_chain(self):
        """Test that CalculationService has a calculation chain"""
        assert hasattr(self.calculation_service, "chain")
        assert self.calculation_service.chain is not None
   
   # cost share coinsurance is less than zero
    def test_cost_share_coinsurance_less_than_zero(self):
        """Test find_highest_member_pay with cost share coinsurance less than zero"""
        matched_accum = mock_matched_accumulator_individual_deductible(calculatedValue=0)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(benefitDescription="Test benefit with OOP max"),
            matched_accumulators=[matched_accum],
        )
        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(service_amount, [benefit])
        insurance_pays = service_amount - result.member_pays
        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_member_pays_no_co_insurance was called (look for its trace message)
        _apply_member_pays_no_co_insurance = False
        for trace in result.trace_entries:
            if "_apply_member_pays_no_co_insurance" in trace.step:
                _apply_member_pays_no_co_insurance = True
                print(
                    f"_apply_member_pays_no_co_insurance trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_member_pays_no_co_insurance
        ), "Expected _apply_member_pays_no_co_insurance trace message not found"

        print(result)
    
    # cost share coinsurance is greater than zero
    def test_cost_share_coinsurance_greater_than_zero(self):
        """Test find_highest_member_pay with cost share coinsurance greater than zero"""
        matched_accum = mock_matched_accumulator_individual_deductible(calculatedValue=0)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(benefitDescription="Test benefit with OOP max",costShareCoinsurance=20.0,coinsAppliesOutOfPocket="N"),
            matched_accumulators=[matched_accum],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(service_amount, [benefit])
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_member_pays_co_insurance_and_not_applied_to_oopmax was called (look for its trace message)
        _apply_member_pays_co_insurance_and_not_applied_to_oopmax = False
        for trace in result.trace_entries:
            if "_apply_member_pays_co_insurance_and_not_applied_to_oopmax" in trace.step:
                _apply_member_pays_co_insurance_and_not_applied_to_oopmax = True
                print(
                    f"_apply_member_pays_co_insurance_and_not_applied_to_oopmax trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_member_pays_co_insurance_and_not_applied_to_oopmax
        ), "Expected _apply_member_pays_co_insurance_and_not_applied_to_oopmax trace message not found"

        print(result)
    
    #cost share coinsurance greater than zero and applied to oopmax and coinsurance greater than service amount
    def test_cost_share_coinsurance_greater_than_zero_and_applied_to_oopmax_and_coinsurance_greater_than_service_amount(self):
        """Test find_highest_member_pay with cost share coinsurance greater than zero and applied to oopmax and coinsurance greater than service amount"""
        matched_accum = mock_matched_accumulator_individual_deductible(calculatedValue=0)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=100)
        matched_accum3 = mock_matched_accumulator_individual_oopmax(calculatedValue=100)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(benefitDescription="Test benefit with OOP max",costShareCoinsurance=2000.0,coinsAppliesOutOfPocket="Y"),
            matched_accumulators=[matched_accum,matched_accum2,matched_accum3],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(service_amount, [benefit])
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")


        print(result)
    
    #cost share coinsurance greater than zero and applied to oopmax and coinsurance lesser than service amount and coinsurane amount less than oopmax
    def test_coinsurance_amount_lesser_than_service_amount_and_lesser_than_oopmax(self):
        """Test coinsurance amount lesser than service amount and lesser than oopmax"""
        matched_accum = mock_matched_accumulator_individual_deductible(calculatedValue=0)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=50)
        matched_accum3 = mock_matched_accumulator_individual_oopmax(calculatedValue=100)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(benefitDescription="Test benefit with OOP max",costShareCoinsurance=20.0,coinsAppliesOutOfPocket="Y"),
            matched_accumulators=[matched_accum,matched_accum2,matched_accum3],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(service_amount, [benefit])
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_member_pays_co_insurance_and_applied_to_oopmax was called (look for its trace message)
        _apply_member_pays_co_insurance_and_applied_to_oopmax = False
        for trace in result.trace_entries:
            if "_apply_member_pays_co_insurance_and_applied_to_oopmax" in trace.step:
                _apply_member_pays_co_insurance_and_applied_to_oopmax = True
                print(
                    f"_apply_member_pays_co_insurance_and_applied_to_oopmax trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_member_pays_co_insurance_and_applied_to_oopmax
        ), "Expected _apply_member_pays_co_insurance_and_applied_to_oopmax trace message not found"
        print(result)
    
    #cost share coinsurance greater than zero and applied to oopmax and coinsurance lesser than service amount and coinsurane amount greater than oopmax
    def test_coinsurance_amount_lesser_than_service_amount_and_greater_than_oopmax(self):
        """Test coinsurance amount lesser than service amount and greater than oopmax"""
        matched_accum = mock_matched_accumulator_individual_deductible(calculatedValue=0)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=50)
        matched_accum3 = mock_matched_accumulator_individual_oopmax(calculatedValue=50)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(benefitDescription="Test benefit with OOP max",costShareCoinsurance=40.0,coinsAppliesOutOfPocket="Y"),
            matched_accumulators=[matched_accum,matched_accum2,matched_accum3],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(service_amount, [benefit])
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_member_pays_oopmax_difference was called (look for its trace message)
        _apply_member_pays_oopmax_difference = False
        for trace in result.trace_entries:
            if "_apply_member_pays_oopmax_difference" in trace.step:
                _apply_member_pays_oopmax_difference = True
                print(
                    f"_apply_member_pays_oopmax_difference trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_member_pays_oopmax_difference
        ), "Expected _apply_member_pays_oopmax_difference trace message not found"
        print(result)
    

        

