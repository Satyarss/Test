#!/usr/bin/env python3
"""
Tests for the CalculationService class and interface.
"""

import sys
import os
from unittest.mock import Mock, patch

import pytest
from app.services.impl.calculation_service_impl import CalculationServiceImpl
from app.core.base import (
    InsuranceContext,
    MatchedAccumulator,
)
from app.models.selected_benefit import (
    SelectedBenefit,
    SelectedCoverage,
)
from app.schemas.accumulator_response import (
    EffectivePeriod,
)
from app.schemas.benefit_response import (
    BenefitTier,
    Prerequisite,
    ServiceProviderItem,
)
from app.services.calculation_service import (
    CalculationServiceInterface,
)
from tests.services.handlers.test_data import (
    mock_matched_accumulator_individual_oopmax,
    mock_matched_accumulator_family_oopmax,
    mock_matched_accumulator_individual_deductible,
    mock_matched_accumulator_family_deductible,
    mock_main,
    MockBenefit,
    MockCoverage,
)

# Add the project root to Python path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, project_root)


class TestCalculationService:
    """Test the CalculationService implementation"""

    def setup_method(self):
        """Set up test fixtures"""
        self.calculation_service = CalculationServiceImpl()

    def test_calculation_service_implements_interface(self):
        """Test that CalculationService implements the interface"""
        assert isinstance(self.calculation_service, CalculationServiceInterface)

    def test_calculation_service_has_chain(self):
        """Test that CalculationService has a calculation chain"""
        assert hasattr(self.calculation_service, "chain")
        assert self.calculation_service.chain is not None

    # deductible benefit, copay does not applies out of pocket, copay greater than service amount

    def test_ind_benefit_with_deductible_no_copayappliesoopmax_copay_greater_than_service_amount(
        self,
    ):
        """Test find_highest_member_pay with benefit that has OOP max = 0 and with dedictible accum and OOP max accum"""
        # Create a benefit with OOP max accumulator
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=100)
        #matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=100)
        matched_accum3 = mock_matched_accumulator_individual_deductible(
            calculatedValue=100
        )
        #matched_accum4 = mock_matched_accumulator_family_deductible(calculatedValue=100)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max",
                costShareCopay=300.0,
                copayAppliesOutOfPocket="N",
                isDeductibleBeforeCopay="N",
            ),
            matched_accumulators=[
                matched_accum,
               # matched_accum2,
                matched_accum3#,
                #matched_accum4,
            ],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(
            service_amount, [benefit]
        )
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")
        print(f"Deductible Individual Calculated: ${result.deductible_individual_calculated}")
        print(f"Deductible Family Calculated: ${result.deductible_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_member_pays_remaining_service_amount was called (look for its trace message)
        _apply_member_pays_remaining_service_amount = False
        for trace in result.trace_entries:
            if "_apply_member_pays_remaining_service_amount" in trace.step:
                _apply_member_pays_remaining_service_amount = True
                print(
                    f"_apply_member_pays_remaining_service_amount trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_member_pays_remaining_service_amount
        ), "Expected _apply_member_pays_remaining_service_amount trace message not found"

        print(result)

    def test_benefit_with_deductible_no_copayappliesoopmax_copay_greater_than_service_amount(
        self,
    ):
        """Test find_highest_member_pay with benefit that has OOP max = 0 and with dedictible accum and OOP max accum"""
        # Create a benefit with OOP max accumulator
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=100)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=100)
        matched_accum3 = mock_matched_accumulator_individual_deductible(
            calculatedValue=100
        )
        matched_accum4 = mock_matched_accumulator_family_deductible(calculatedValue=100)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max",
                costShareCopay=300.0,
                copayAppliesOutOfPocket="N",
                isDeductibleBeforeCopay="N",
            ),
            matched_accumulators=[
                matched_accum,
                matched_accum2,
                matched_accum3,
                matched_accum4,
            ],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(
            service_amount, [benefit]
        )
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_member_pays_remaining_service_amount was called (look for its trace message)
        _apply_member_pays_remaining_service_amount = False
        for trace in result.trace_entries:
            if "_apply_member_pays_remaining_service_amount" in trace.step:
                _apply_member_pays_remaining_service_amount = True
                print(
                    f"_apply_member_pays_remaining_service_amount trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_member_pays_remaining_service_amount
        ), "Expected _apply_member_pays_remaining_service_amount trace message not found"

        print(result)

    # deductible benefit, copay does not applies out of pocket, copay lesser than service amount, deductible before copay
    def test_with_deductible_benefit_no_copayappliesoopmax_cp_lesser_than_sa_deductiblebeforecopay(
        self,
    ):
        """Test find_highest_member_pay with benefit that has deductible accum and OOP max accum copay does not applies out of pocket, copay lesser than service amount, deductible before copay"""

        # Create a benefit with OOP max accumulator
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=100)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=100)
        matched_accum3 = mock_matched_accumulator_individual_deductible(
            calculatedValue=100
        )
        matched_accum4 = mock_matched_accumulator_family_deductible(calculatedValue=100)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max",
                costShareCopay=100.0,
                copayAppliesOutOfPocket="N",
                isDeductibleBeforeCopay="N",
            ),
            matched_accumulators=[
                matched_accum,
                matched_accum2,
                matched_accum3,
                matched_accum4,
            ],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(
            service_amount, [benefit]
        )
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")
        print(
            f"Deductible Individual Calculated: ${result.deductible_individual_calculated}"
        )
        print(f"Deductible Family Calculated: ${result.deductible_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_costshare_copay_deductible was called (look for its trace message)
        _apply_costshare_copay_deductible = False
        for trace in result.trace_entries:
            if "_apply_costshare_copay_deductible" in trace.step:
                _apply_costshare_copay_deductible = True
                print(
                    f"_apply_costshare_copay_deductible trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_costshare_copay_deductible
        ), "Expected _apply_costshare_copay_deductible trace message not found"

        print(result)

    # deductible benefit, copay applies out of pocket, copay lesser than service amount, copay greater than oopmax
    def test_deductible_copayappliesoopmax_cp_lesser_than_sa_copay_greater_than_oopmax(
        self,
    ):
        """Test find_highest_member_pay with benefit that has deductible accum and OOP max accum copay applies out of pocket, copay lesser than service amount, copay greater than oopmax"""
        # Create a benefit with OOP max accumulator
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=100)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=100)
        matched_accum3 = mock_matched_accumulator_individual_deductible(
            calculatedValue=100
        )
        matched_accum4 = mock_matched_accumulator_family_deductible(calculatedValue=100)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max",
                costShareCopay=150.0,
                isDeductibleBeforeCopay="N",
            ),
            matched_accumulators=[
                matched_accum,
                matched_accum2,
                matched_accum3,
                matched_accum4,
            ],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(
            service_amount, [benefit]
        )
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")
        print(
            f"Deductible Individual Calculated: ${result.deductible_individual_calculated}"
        )
        print(f"Deductible Family Calculated: ${result.deductible_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_member_pays_cost_share_amount was called (look for its trace message)
        _apply_member_pays_cost_share_amount = False
        for trace in result.trace_entries:
            if "_apply_member_pays_cost_share_amount" in trace.step:
                _apply_member_pays_cost_share_amount = True
                print(
                    f"_apply_member_pays_cost_share_amount trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_member_pays_cost_share_amount
        ), "Expected _apply_member_pays_cost_share_amount trace message not found"

        print(result)

    def test_deductible_benefit_copayappliesoopmax_cp_lesser_than_sa_copay_lesser_than_oopmax(
        self,
    ):
        """Test find_highest_member_pay with benefit that has deductible accum and OOP max accum copay does not applies out of pocket, copay lesser than service amount, deductible before copay"""
        # Create a benefit with OOP max accumulator
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=500)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=1000)
        matched_accum3 = mock_matched_accumulator_individual_deductible(
            calculatedValue=100
        )
        matched_accum4 = mock_matched_accumulator_family_deductible(calculatedValue=100)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max",
                costShareCopay=150.0,
                isDeductibleBeforeCopay="N",
            ),
            matched_accumulators=[
                matched_accum,
                matched_accum2,
                matched_accum3,
                matched_accum4,
            ],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(
            service_amount, [benefit]
        )
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")
        print(
            f"Deductible Individual Calculated: ${result.deductible_individual_calculated}"
        )
        print(f"Deductible Family Calculated: ${result.deductible_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_costshare_copay_deductible was called (look for its trace message)
        _apply_costshare_copay_deductible = False
        for trace in result.trace_entries:
            if "_apply_costshare_copay_deductible" in trace.step:
                _apply_costshare_copay_deductible = True
                print(
                    f"_apply_costshare_copay_deductible trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_costshare_copay_deductible
        ), "Expected _apply_costshare_copay_deductible trace message not found"

        print(result)

    def test_deductible_benefit_copayappliesoopmax_cp_greater_than_sa_sa_lesser_than_oopmax(
        self,
    ):
        """Test find_highest_member_pay with benefit that has deductible accum and OOP max accum copay greater than service amount and service amount lesser than min oopmax"""
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=500)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=1000)
        matched_accum3 = mock_matched_accumulator_individual_deductible(
            calculatedValue=100
        )
        matched_accum4 = mock_matched_accumulator_family_deductible(calculatedValue=100)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max",
                costShareCopay=300.0,
                isDeductibleBeforeCopay="N",
            ),
            matched_accumulators=[
                matched_accum,
                matched_accum2,
                matched_accum3,
                matched_accum4,
            ],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(
            service_amount, [benefit]
        )
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")
        print(
            f"Deductible Individual Calculated: ${result.deductible_individual_calculated}"
        )
        print(f"Deductible Family Calculated: ${result.deductible_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_member_pays_remaining_service_amount_and_oopmax_updated was called (look for its trace message)
        _apply_member_pays_remaining_service_amount_and_oopmax_updated = False
        for trace in result.trace_entries:
            if (
                "_apply_member_pays_remaining_service_amount_and_oopmax_updated"
                in trace.step
            ):
                _apply_member_pays_remaining_service_amount_and_oopmax_updated = True
                print(
                    f"_apply_member_pays_remaining_service_amount_and_oopmax_updated trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_member_pays_remaining_service_amount_and_oopmax_updated
        ), "Expected _apply_member_pays_remaining_service_amount_and_oopmax_updated trace message not found"

        print(result)

    def test_deductible_benefit_copayappliesoopmax_cp_greater_than_sa_sa_greater_than_oopmax(
        self,
    ):
        """Test find_highest_member_pay with benefit that has deductible accum and OOP max accum copay greater than service amount and service amount greater than min oopmax"""
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=100)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=50)
        matched_accum3 = mock_matched_accumulator_individual_deductible(
            calculatedValue=100
        )
        matched_accum4 = mock_matched_accumulator_family_deductible(calculatedValue=100)
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max",
                costShareCopay=300.0,
                isDeductibleBeforeCopay="N",
            ),
            matched_accumulators=[
                matched_accum,
                matched_accum2,
                matched_accum3,
                matched_accum4,
            ],
        )

        service_amount = 200
        result = self.calculation_service.find_highest_member_pay(
            service_amount, [benefit]
        )
        insurance_pays = service_amount - result.member_pays

        # Print key values for debugging
        print(f"Service Amount: ${result.service_amount}")
        print(f"Member Pays: ${result.member_pays}")
        print(f"Insurance Pays: ${insurance_pays}")
        print(f"Service Covered: {result.is_service_covered}")
        print(f"Cost Share Copay: ${result.cost_share_copay}")
        print(f"OOP Max Individual Calculated: ${result.oopmax_individual_calculated}")
        print(f"OOP Max Family Calculated: ${result.oopmax_family_calculated}")
        print(
            f"Deductible Individual Calculated: ${result.deductible_individual_calculated}"
        )
        print(f"Deductible Family Calculated: ${result.deductible_family_calculated}")

        # Print trace entries to see the flow
        for i, trace in enumerate(result.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

        # Assert that _apply_member_pays_full_amount was called (look for its trace message)
        _apply_member_pays_full_amount = False
        for trace in result.trace_entries:
            if "_apply_member_pays_full_amount" in trace.step:
                _apply_member_pays_full_amount = True
                print(
                    f"_apply_member_pays_full_amount trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            _apply_member_pays_full_amount
        ), "Expected _apply_member_pays_full_amount trace message not found"

        print(result)
