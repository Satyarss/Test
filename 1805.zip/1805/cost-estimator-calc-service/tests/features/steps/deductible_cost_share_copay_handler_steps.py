from unittest.mock import Mock
from behave import given, when, then  # type: ignore
from app.services.handlers.deductible_cost_share_co_pay import (
    DeductibleCostShareCoPayHandler,
)
from app.core.base import InsuranceContext


@given("a DeductibleCostShareCoPayHandler is created")
def step_impl(context):
    context.handler = DeductibleCostShareCoPayHandler()
    context.insurance_context = InsuranceContext()

    # Create a mock for the co-insurance handler
    mock_co_insurance_handler = Mock()
    mock_co_insurance_handler.return_value = context.insurance_context

    context.handler.set_deductible_co_insurance_handler(mock_co_insurance_handler)
    context.mock_co_insurance_handler = mock_co_insurance_handler

    # Create a mock for the co pay handler
    mock_cost_share_co_pay_handler = Mock()
    mock_cost_share_co_pay_handler.return_value = context.insurance_context

    context.handler.set_deductible_co_pay_handler(mock_cost_share_co_pay_handler)
    context.mock_cost_share_co_pay_handler = mock_cost_share_co_pay_handler
