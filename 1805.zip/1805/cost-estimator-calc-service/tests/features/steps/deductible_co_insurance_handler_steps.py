from behave import given, when, then  # type: ignore
from app.services.handlers.deductible_co_insurance_handler import (
    DeductibleCoInsuranceHandler,
)
from app.core.base import InsuranceContext


@given("an DeductibleCoInsuranceHandler is created")
def step_create_deductible_co_insurance_handler(context):
    context.handler = DeductibleCoInsuranceHandler()
    context.insurance_context = InsuranceContext()


@given("the co-insurance percent is {amount}")
def step_co_insurance_percent(context, amount):
    context.insurance_context.cost_share_coinsurance = float(amount)


@given("co-insurance applies to OOPMax {value}")
def step_co_insurance_applies_to_oopmax(context, value):
    context.insurance_context.coins_applies_oop = value.lower() == "true"
