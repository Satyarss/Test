from behave import given, when, then  # type: ignore
from unittest.mock import Mock, patch
from app.services.handlers.deductible_co_pay_handler import DeductibleCoPayHandler
from app.core.base import InsuranceContext


@given("an DeductibleCoPayHandler is created")
def step_create_deductible_co_pay_handler(context):
    context.handler = DeductibleCoPayHandler()
    context.insurance_context = InsuranceContext()

    # Create a mock for the deductible handler
    mock_co_insurance_handler = Mock()
    mock_co_insurance_handler.return_value = context.insurance_context

    context.handler.set_deductible_co_insurance_handler(mock_co_insurance_handler)
    context.mock_co_insurance_handler = mock_co_insurance_handler


@given("the co-pay applies out of pocket {value}")
def step_copay_applies_out_of_pocket(context, value):
    context.insurance_context.copay_applies_oop = value.lower() == "true"
