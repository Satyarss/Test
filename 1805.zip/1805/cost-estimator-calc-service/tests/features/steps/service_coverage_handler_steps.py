from behave import given, when, then  # type: ignore
from app.services.handlers.service_coverage_handler import ServiceCoverageHandler
from app.core.base import InsuranceContext


@given("a ServiceCoverageHandler is created")
def step_create_handler(context):
    context.handler = ServiceCoverageHandler()


@given("an insurance context with service covered")
def step_given_service_covered(context):
    context.insurance_context = InsuranceContext()
    context.insurance_context.is_service_covered = True


@given("an insurance context with service not covered")
def step_given_service_not_covered(context):
    context.insurance_context = InsuranceContext()
    context.insurance_context.is_service_covered = False
