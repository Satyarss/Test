SERVER_ROOT_PATH = "/costestimator"
API_VERSION_V1 = "/v1"


PAYMENT_METHOD_HIERARCHY_CACHE_KEY = "payment_method_hierarchy"

APP_NAME = "edmlprvdraaece"

INDEX_ROUTES_TAG = "Index route"