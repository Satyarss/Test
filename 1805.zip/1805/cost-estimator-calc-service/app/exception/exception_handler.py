from fastapi import FastAPI, Request
from fastapi.exception_handlers import request_validation_exception_handler
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from typing import Any

from app.exception.exception_responses import responses
from app.exception.exceptions import (
    RateNotFoundException,
    BenefitsNotFoundException,
    AccumulatorNotFoundException,
)


async def validation_exception_handler(request: Request, exc: Any) -> JSONResponse:
    """Handle validation errors and return standardized format."""

    # Build error message from validation errors
    error_messages = []
    for error in exc.errors():
        field_path = ".".join(
            str(loc) for loc in error["loc"][1:]
        )  # Skip 'body' from location
        error_type = error["type"]
        error_msg = error["msg"]

        if error_type == "missing":
            error_messages.append(f"Missing required field: {field_path}")
        elif error_type == "string_too_short":
            min_length = error.get("ctx", {}).get("min_length", 1)
            error_messages.append(
                f"Field '{field_path}' must have at least {min_length} character(s)"
            )
        else:
            error_messages.append(f"Field '{field_path}': {error_msg}")

    # Create standardized error response
    response_content = responses[400].copy()
    response_content["detail"] = "; ".join(error_messages)
    response_content["title"] = "Validation Error"
    response_content["message"] = "One or more validation errors occurred"
    response_content["status"] = 400

    # Remove the separate errors field if it exists
    if "errors" in response_content:
        del response_content["errors"]

    return JSONResponse(content=response_content, status_code=400)


async def rate_not_found_exception_handler(
    request: Request, exc: Exception
) -> JSONResponse:
    """Handle RateNotFoundException and return appropriate 500 response."""
    response_content = responses[500].copy()
    if isinstance(exc, RateNotFoundException):
        response_content["detail"] = exc.message
        response_content["title"] = "Rate not found"
        response_content["message"] = "Rate not found for the provided criteria"
        # Remove the separate errors field
        if "errors" in response_content:
            del response_content["errors"]
    return JSONResponse(content=response_content, status_code=500)


async def benefits_not_found_exception_handler(
    request: Request, exc: Exception
) -> JSONResponse:
    """Handle BenefitsNotFoundException and return appropriate response with status from message."""
    response_content = responses[500].copy()
    if isinstance(exc, BenefitsNotFoundException):
        # Extract status from message if it contains "Status X:"
        message = exc.message
        status_code = 500  # Default status

        if message.startswith("Status "):
            try:
                # Extract status code from "Status 400: message" format
                status_part = message.split(":")[0]
                status_code = int(status_part.replace("Status ", ""))
                # Clean up message to remove status prefix
                message = ":".join(message.split(":")[1:]).strip()
            except (ValueError, IndexError):
                # If parsing fails, keep original message and status
                pass

        response_content["detail"] = message
        response_content["title"] = "Benefits not found"
        response_content["message"] = "Benefits not found for the provided request"
        response_content["status"] = status_code
        # Remove the separate errors field
        if "errors" in response_content:
            del response_content["errors"]

        return JSONResponse(content=response_content, status_code=500)

    return JSONResponse(content=response_content, status_code=500)


async def accumulator_not_found_exception_handler(
    request: Request, exc: Exception
) -> JSONResponse:
    """Handle AccumulatorNotFoundException and return appropriate response with status from message."""
    response_content = responses[500].copy()
    if isinstance(exc, AccumulatorNotFoundException):
        # Extract status from message if it contains "Status X:"
        message = exc.message
        status_code = 500  # Default status

        if message.startswith("Status "):
            try:
                # Extract status code from "Status 400: message" format
                status_part = message.split(":")[0]
                status_code = int(status_part.replace("Status ", ""))
                # Clean up message to remove status prefix
                message = ":".join(message.split(":")[1:]).strip()
            except (ValueError, IndexError):
                # If parsing fails, keep original message and status
                pass

        response_content["detail"] = message
        response_content["title"] = "Accumulator not found"
        response_content["message"] = "Accumulator not found for the provided request"
        response_content["status"] = status_code
        # Remove the separate errors field
        if "errors" in response_content:
            del response_content["errors"]

        return JSONResponse(content=response_content, status_code=500)

    return JSONResponse(content=response_content, status_code=500)


def include_exceptions(app: FastAPI):
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
    app.add_exception_handler(RateNotFoundException, rate_not_found_exception_handler)
    app.add_exception_handler(
        BenefitsNotFoundException, benefits_not_found_exception_handler
    )
    app.add_exception_handler(
        AccumulatorNotFoundException, accumulator_not_found_exception_handler
    )
    return app
