class BadRequestException(Exception):
    pass


class RateNotFoundException(Exception):
    """Exception raised when a rate cannot be found for the given criteria."""

    def __init__(
        self,
        message: str = "Rate not found for the given criteria",
        rate_criteria: dict | None = None,
    ):
        self.message = message
        self.rate_criteria = rate_criteria or {}
        super().__init__(self.message)


class BenefitsNotFoundException(Exception):
    """Exception raised when benefits cannot be found for the given request."""

    def __init__(
        self,
        message: str = "Benefits not found for the given request",
        benefit_request: dict | None = None,
    ):
        self.message = message
        self.benefit_request = benefit_request or {}
        super().__init__(self.message)


class AccumulatorNotFoundException(Exception):
    """Exception raised when accumulator information cannot be found for the given request."""

    def __init__(
        self,
        message: str = "Accumulator not found for the given request",
        accumulator_request: dict | None = None,
    ):
        self.message = message
        self.accumulator_request = accumulator_request or {}
        super().__init__(self.message)
