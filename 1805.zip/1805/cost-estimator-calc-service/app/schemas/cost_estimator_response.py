from re import A
from typing import List, Optional, Union
from pydantic import BaseModel, Field
from app.schemas.cost_estimator_request import (
    Service,
    ProviderInfo,
    CostEstimatorRequest,
)
from app.models.selected_benefit import SelectedBenefit
from app.models.rate_criteria import NegotiatedRate
from app.core.base import InsuranceContext
from app.schemas.accumulator_response import Accumulator as AccumulatorResponse
from app.core.logger import logger


class Coverage(BaseModel):
    isServiceCovered: str
    maxCoverageAmount: float
    costShareCopay: float
    costShareCoinsurance: int


class Cost(BaseModel):
    inNetworkCosts: float
    outOfNetworkCosts: float
    inNetworkCostsType: str


class HealthClaimLine(BaseModel):
    amountCopay: float
    amountCoinsurance: float
    amountResponsibility: float
    percentResponsibility: str
    amountpayable: float


class Accumulator(BaseModel):
    code: str
    level: str
    limitValue: float
    calculatedValue: float


class AccumulatorWithLimitType(BaseModel):
    code: str
    level: str
    limitValue: float
    limitType: str
    calculatedValue: float


class AccumulatorCalculation(BaseModel):
    remainingValue: float
    appliedValue: float


class AccumulatorCalculationWithType(BaseModel):
    remainingValue: float
    appliedValue: float
    appliedValueType: str


class AccumulatorInfo(BaseModel):
    accumulator: Union[Accumulator, AccumulatorWithLimitType]
    accumulatorCalculation: Union[
        AccumulatorCalculation, AccumulatorCalculationWithType
    ]


class CostEstimateResponseInfo(BaseModel):
    providerInfo: ProviderInfo
    coverage: Coverage
    cost: Cost
    healthClaimLine: HealthClaimLine
    accumulators: List[AccumulatorInfo]


class CostEstimateResponse(BaseModel):
    service: Service
    costEstimateResponseInfo: List[CostEstimateResponseInfo]


class CostEstimatorResponse(BaseModel):
    costEstimateResponse: CostEstimateResponse

    @classmethod
    def build_cost_estimator_response(
        cls,
        cost_estimator_request: CostEstimatorRequest,
        selected_benefits: List[SelectedBenefit],
        insuranceContext: InsuranceContext,
        rate: NegotiatedRate,
    ) -> "CostEstimatorResponse":
        """
        Build a CostEstimatorResponse with the provided details.
        """
        # Extract data from the request and context
        selected_benefit_of_highest_member_pay = cls.select_benefit(
            selected_benefits, insuranceContext
        )

        service = cost_estimator_request.service
        provider_info = cost_estimator_request.providerInfo[
            0
        ]  # Assuming first provider

        # Create coverage from selected benefits
        coverage = Coverage(
            isServiceCovered="Y" if selected_benefits else "N",
            maxCoverageAmount=insuranceContext.limit_calculated or 0.0,
            costShareCopay=float(insuranceContext.cost_share_copay or 0.0),
            costShareCoinsurance=int(insuranceContext.cost_share_coinsurance or 0),
        )

        # Create cost information
        cost = Cost(
            inNetworkCosts=float(rate.rate),
            outOfNetworkCosts=float(0.0),
            inNetworkCostsType=rate.rateType,
        )

        # Create health claim line
        health_claim_line = HealthClaimLine(
            amountCopay=insuranceContext.amount_copay,
            amountCoinsurance=insuranceContext.amount_coinsurance,
            amountResponsibility=float(rate.rate),
            percentResponsibility=str(insuranceContext.cost_share_coinsurance),
            amountpayable=insuranceContext.member_pays,
        )

        logger.info(
            f"selected_benefit_of_highest_member_pay: {selected_benefit_of_highest_member_pay}"
        )

        if selected_benefit_of_highest_member_pay is not None:
            accumulators = []
            accumulators = cls.build_accumulator(
                selected_benefit_of_highest_member_pay.coverage.matchedAccumulators,
                insuranceContext,
            )
        else:
            accumulators = []

        cost_estimate_response_info = CostEstimateResponseInfo(
            providerInfo=provider_info,
            coverage=coverage,
            cost=cost,
            healthClaimLine=health_claim_line,
            accumulators=accumulators,
        )
        cost_estimate_response = CostEstimateResponse(
            service=service,
            costEstimateResponseInfo=[cost_estimate_response_info],
        )
        return CostEstimatorResponse(costEstimateResponse=cost_estimate_response)

    @classmethod
    def select_benefit(
        cls,
        selected_benefits: List[SelectedBenefit],
        insuranceContext: InsuranceContext,
    ) -> Optional[SelectedBenefit]:
        # Filter benefits by matching benefit code with insurance context
        matching_benefits = [
            benefit
            for benefit in selected_benefits
            if benefit.benefitCode == insuranceContext.benefit_id
        ]

        # If no matching benefits found, return the first benefit or None

        if not matching_benefits:
            return selected_benefits[0] if selected_benefits else None

        # For now, return the first matching benefit since we can't calculate member_pays here
        # The actual member_pays calculation happens in the calculation service
        return matching_benefits[0]

    @classmethod
    def build_accumulator(
        cls, accumulators: List, insuranceContext: InsuranceContext
    ) -> List[AccumulatorInfo]:

        result = []
        for acc in accumulators:
            code = acc.code.lower()
            level = acc.level.lower()
            limit_type = (acc.limitType or "").lower()

            if acc.code.lower() == "limit":
                accumulator = AccumulatorWithLimitType(
                    code=acc.code,
                    level=acc.level,
                    limitValue=acc.limitValue,
                    limitType=acc.limitType or "",
                    calculatedValue=acc.calculatedValue,
                )
            else:
                accumulator = Accumulator(
                    code=acc.code,
                    level=acc.level,
                    limitValue=acc.limitValue,
                    calculatedValue=acc.calculatedValue,
                )

            # Mapping for accumulator calculation logic
            remaining = 0.0
            applied = 0.0
            applied_type = None

            if code == "limit":
                # Note: "dollaer" typo is preserved for backward compatibility
                remaining = acc.calculatedValue
                applied = acc.calculatedValue - (insuranceContext.limit_calculated or 0)
                applied_type = limit_type if limit_type in ("dollar", "counter") else ""
            elif code == "deductible":
                if level == "individual":
                    remaining = insuranceContext.deductible_individual_calculated or 0.0
                    applied = acc.calculatedValue - remaining
                elif level == "family":
                    remaining = insuranceContext.deductible_family_calculated or 0.0
                    applied = acc.calculatedValue - remaining
                applied_type = None
            elif code == "oop max":
                if level == "individual":
                    remaining = insuranceContext.oopmax_individual_calculated or 0.0
                    applied = acc.calculatedValue - remaining

                elif level == "family":
                    remaining = insuranceContext.oopmax_family_calculated or 0.0
                    applied = acc.calculatedValue - remaining
                applied_type = None
            else:
                # Skip unknown accumulator types
                continue
            if code == "limit":
                accumulator_calc = AccumulatorCalculationWithType(
                    remainingValue=remaining,
                    appliedValue=applied,
                    appliedValueType=str(applied_type),
                )
            else:
                accumulator_calc = AccumulatorCalculation(
                    remainingValue=remaining,
                    appliedValue=applied,
                )
            result.append(
                AccumulatorInfo(
                    accumulator=accumulator,
                    accumulatorCalculation=accumulator_calc,
                )
            )
        return result
