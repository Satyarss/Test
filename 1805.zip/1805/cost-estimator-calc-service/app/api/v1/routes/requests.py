from fastapi import APIRouter, Depends, Header
from app.exception.exception_responses import responses
from app.schemas.cost_estimator_request import CostEstimatorRequest
from app.services.impl.cost_estimation_service_impl import CostEstimationServiceImpl
from app.core.logger import logger
from typing import Optional

router = APIRouter()


@router.post(
    "/rate",
    responses=responses,
    summary="Retrieve cost estimate for member",
    tags=["Cost Estimation"],
)
async def estimate_cost(
    request: CostEstimatorRequest,
    service: CostEstimationServiceImpl = Depends(),
    authorization: Optional[str] = Header(None, description="JWT token header"),
    x_api_key: Optional[str] = Header(
        None, alias="x-api-key", description="API key header"
    ),
    x_correlation_id: Optional[str] = Header(
        None, alias="x-correlation-id", description="Request correlation ID"
    ),
    x_client_ref_id: Optional[str] = Header(
        None, alias="x-client-ref-id", description="Client reference ID"
    ),
    content_type: Optional[str] = Header(
        None, alias="content-type", description="Content type"
    ),
    eie_header_action: Optional[str] = Header(
        None, alias="eieheaderaction", description="EIE header action"
    ),
    eie_header_application_identifier: Optional[str] = Header(
        None,
        alias="eieheaderapplicationidentifier",
        description="EIE application identifier",
    ),
    eie_header_orchestrating_application_identifier: Optional[str] = Header(
        None,
        alias="eieheaderorchestratingapplicationidentifier",
        description="EIE orchestrating application identifier",
    ),
    eie_header_user_context: Optional[str] = Header(
        None, alias="eieheaderusercontext", description="EIE user context"
    ),
    eie_header_version: Optional[str] = Header(
        None, alias="eieheaderversion", description="EIE header version"
    ),
    x_mock: Optional[str] = Header(None, alias="x-mock", description="Mock flag"),
):
    # Collect headers for logging in a concise way
    headers = {
        "X-API-Key": f"{x_api_key[:10] + '...' if x_api_key and len(x_api_key) > 10 else x_api_key}",
        "X-Correlation-ID": x_correlation_id,
        "X-Client-Ref-ID": x_client_ref_id,
        "Content-Type": content_type,
        "EIE-Header-Action": eie_header_action,
        "EIE-Header-Application-Identifier": eie_header_application_identifier,
        "EIE-Header-Orchestrating-Application-Identifier": eie_header_orchestrating_application_identifier,
        "EIE-Header-User-Context": eie_header_user_context,
        "EIE-Header-Version": eie_header_version,
        "X-Mock": x_mock,
    }
    logger.info(f"Request Headers: {headers}")

    # Call the service to get the cost estimation
    logger.info(f"Cost Estimation Request: {request}")
    response = await service.estimate_cost(request,headers=headers)
    logger.info(f"Cost Estimation Response: {response}")
    return response
