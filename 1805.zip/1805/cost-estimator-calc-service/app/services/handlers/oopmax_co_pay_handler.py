from app.core.base import Handler, InsuranceContext


class OOPMaxCopayHandler(Handler):
    """Determine copay for OOPMax"""

    def process(self, context):
        if not context.cost_share_copay > 0:
            context.trace_decision(
                "Process", "The cost share co-pay is not greater than zero", False
            )
            return self._apply_zero_copay(context)

        if not context.copay_continue_when_oop_met:
            context.trace_decision(
                "Process", "The co-pay continues when OOP is met", False
            )
            return self._apply_zero_copay(context)

        if context.cost_share_copay > context.service_amount:
            context.trace_decision(
                "Process",
                "The cost share co-pay is greater than the service amount",
                True,
            )
            return self._apply_member_pays_full_amount(context)
        else:
            context.trace_decision(
                "Process",
                "The cost share co-pay is less than the service amount",
                False,
            )
            return self._apply_member_pays_cost_share_amount(context)

    def _apply_zero_copay(self, context: InsuranceContext) -> InsuranceContext:
        """Plan has zero copay, insurance pays in full"""

        context.member_pays = context.member_pays
        context.calculation_complete = True

        context.trace("_apply_zero_copay", "Logic applied")

        return context

    def _apply_member_pays_full_amount(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """The cost of the service is less than the copay, member pays service amount"""
        # TODO: some of unused variables we need to remove later on
        context.member_pays = context.member_pays + context.service_amount
        context.amount_copay = context.amount_copay
        context.cost_share_copay = context.cost_share_copay
        context.service_amount = 0
        context.calculation_complete = True

        context.trace("_apply_member_pays_full_amount", "Logic applied")

        return context

    def _apply_member_pays_cost_share_amount(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays cost share, insurance pays remaining"""
        # TODO: some of unused variables we need to remove later on
        context.member_pays = context.member_pays + context.cost_share_copay
        context.amount_copay = context.amount_copay + context.cost_share_copay
        context.service_amount = context.service_amount - context.cost_share_copay
        context.cost_share_copay = 0
        context.calculation_complete = True

        context.trace("_apply_member_pays_cost_share_amount", "Logic applied")

        return context
