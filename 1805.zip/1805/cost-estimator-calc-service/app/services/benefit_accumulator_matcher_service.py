from abc import ABC, abstractmethod
from typing import Optional, List
from app.schemas.benefit_response import BenefitApiResponse, Benefit
from app.schemas.accumulator_response import AccumulatorResponse
from app.schemas.cost_estimator_request import CostEstimatorRequest


class BenefitAccumulatorMatcherServiceInterface(ABC):
    @abstractmethod
    def get_selected_benefits(
        self,
        benefit_response: BenefitApiResponse,
        accumulator_response: AccumulatorResponse,
        cost_estimator_request: CostEstimatorRequest,
        isOutofNetwork: bool,
    ) -> Optional[List[Benefit]]:
        """
        Get all data needed for member pay calculation by matching benefit tiers and accumulators.

        Args:
            benefit_response: Response from benefit service
            accumulator_response: Response from accumulator service
            cost_request: Original cost estimator request

        Returns:
            Dictionary containing benefit tier info and matching accumulators
        """
        pass
