import json
import asyncio
from typing import Optional, Dict
from re import S
from app.models.rate_criteria import NegotiatedRate
from app.models.selected_benefit import SelectedBenefit
from app.services.cost_estimation_service import CostEstimationServiceInterface
from app.services.impl.benefit_service_impl import BenefitServiceImpl
from app.services.impl.accumulator_service_impl import AccumulatorServiceImpl
from app.services.impl.benefit_accumulator_matcher_service_impl import (
    BenefitAccumulatorMatcherServiceImpl,
)
from app.schemas.cost_estimator_request import CostEstimatorRequest
from app.schemas.cost_estimator_response import (
    CostEstimatorResponse,
    CostEstimateResponse,
)
from app.schemas.cost_estimator_request import Service
from app.repository.impl.cost_estimator_repository_impl import (
    CostEstimatorRepositoryImpl,
)
from app.mappers.cost_estimator_mapper import CostEstimatorMapper
from app.core.logger import logger
from app.schemas.benefit_request import BenefitRequest
from app.services.impl.calculation_service_impl import CalculationServiceImpl
from app.services.token_service import TokenService
from app.core.session_manager import SessionManager
from app.core.base import InsuranceContext
from app.exception.exceptions import (
    RateNotFoundException,
    BenefitsNotFoundException,
    AccumulatorNotFoundException,
)


class CostEstimationServiceImpl(CostEstimationServiceInterface):
    def __init__(
        self,
        repository=None,
        matcher_service=None,
        benefit_service=None,
        accumulator_service=None,
        calculation_service=None,
    ):
        self.repository = repository or CostEstimatorRepositoryImpl()
        self.matcher_service = matcher_service or BenefitAccumulatorMatcherServiceImpl()
        self.benefit_service = benefit_service or BenefitServiceImpl()
        self.accumulator_service = accumulator_service or AccumulatorServiceImpl()
        self.calculation_service = calculation_service or CalculationServiceImpl()

    async def estimate_cost(
        self, request: CostEstimatorRequest, headers: Optional[Dict[str, str]] = None
    ):
        # Map the incoming request to a BenefitRequest using the mapper
        benefit_request = CostEstimatorMapper.to_benefit_request(request)
        rate_criteria = CostEstimatorMapper.to_rate_criteria(request)
        highest_member_pay_context = InsuranceContext()

        try:
            # Call all three operations in parallel
            # TODO: We are going to receive maximum 5 providers, so  we need to create thread for each provider
            benefit_response, accumulator_response, rate = await asyncio.gather(
                self.benefit_service.get_benefit(benefit_request),
                self.accumulator_service.get_accumulator(request, headers=headers),
                self.repository.get_rate(rate_criteria=rate_criteria),
            )

            # get selected benefits
            selected_benefits = self.matcher_service.get_selected_benefits(
                request.membershipId,
                benefit_response,
                accumulator_response,
                request,
                rate_criteria.isOutofNetwork,
            )

            # Initialize cost_estimator_response
            cost_estimator_response = None

            # get highest member pay context
            if (
                selected_benefits is not None
                and len(selected_benefits) > 0
                and rate.isRateFound
                and rate.rateType == "AMOUNT"
            ):

                highest_member_pay_context = (
                    self.calculation_service.find_highest_member_pay(
                        float(rate.rate), selected_benefits
                    )
                )

            cost_estimator_response = (
                CostEstimatorResponse.build_cost_estimator_response(
                    request,
                    selected_benefits or [],
                    highest_member_pay_context,
                    rate,
                )
            )

            return cost_estimator_response

        except BenefitsNotFoundException:
            # Re-raise BenefitsNotFoundException so it can be handled by FastAPI exception handler
            raise
        except AccumulatorNotFoundException:
            # Re-raise AccumulatorNotFoundException so it can be handled by FastAPI exception handler
            raise
        except RateNotFoundException:
            # Re-raise RateNotFoundException so it can be handled by FastAPI exception handler
            raise
        except Exception as e:
            logger.error(f"Error in estimate_cost: {str(e)}")
            raise
